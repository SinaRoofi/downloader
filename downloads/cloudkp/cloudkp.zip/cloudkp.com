<!DOCTYPE html>
<html class='ltr' dir='ltr' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
<meta content='BqdkErHC6' name='admaven-placement'/>
<meta content='d29b91fb48c847b1a0256f95c18596ff_eaacc1fea24b11dbeff0448a937e6970' name='netpub_d29b91fb48c847b1a0256f95c18596ff'/>
<meta content='9040d8afc35a2ce0e15780207af448ea' name='monetag'/>
<meta content='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1' name='viewport'/>
<title>cloudkp</title>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<!-- Chrome, Firefox OS and Opera -->
<meta content='#f8f8f8' name='theme-color'/>
<!-- Windows Phone -->
<meta content='#f8f8f8' name='msapplication-navbutton-color'/>
<meta content='blogger' name='generator'/>
<link href='https://www.cloudkp.com/favicon.ico' rel='icon' type='image/x-icon'/>
<link href='https://www.cloudkp.com/' rel='canonical'/>
<link rel="alternate" type="application/atom+xml" title="cloudkp - Atom" href="https://www.cloudkp.com/feeds/posts/default" />
<link rel="alternate" type="application/rss+xml" title="cloudkp - RSS" href="https://www.cloudkp.com/feeds/posts/default?alt=rss" />
<link rel="service.post" type="application/atom+xml" title="cloudkp - Atom" href="https://www.blogger.com/feeds/478511791075385702/posts/default" />
<!--Can't find substitution for tag [blog.ieCssRetrofitLinks]-->
<meta content='https://www.cloudkp.com/' property='og:url'/>
<meta content='cloudkp' property='og:title'/>
<meta content='' property='og:description'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjmsS1Zv4fhK007W4GtzGkdJ8lXOIne9dmLo0HXcGzKuMRGHuzxRFmiOXuYrvxjui4k-VbQtuSpvfQKkNlUGEwdO0cPXsiNPs6KYFRKTKGsopf2LoEObqgKvoQETbJ5uv6U4kQF46QOXs6D2h6f-PpkvSM1MwlYhEFau9lGXNp_c_h51k9MVi2MpnpgKuTt/w1200-h630-p-k-no-nu/bbbb.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhNTpzdD9BQx3OVL2kTTmoXyhLZXdtilYYoiW5GwbUGMJVm1bViDjFmln4bRGJOR0LZsdnugYtojnszqljnjEhUc_UePgAA7uiLJ2KBrsHMxiK38rFzlJfMKc_yS3IIj9yx3uSaw8FgqHsb-_Ih6eVgxKoVARiVQ7IzZesD73faXUamKxgFZim0sekYSuI2/w1200-h630-p-k-no-nu/maxresdefault.jpg' property='og:image'/>
<script type='application/ld+json'>{"@context":"http://schema.org","@type":"WebSite","name":"cloudkp","url":"https://www.cloudkp.com/","potentialAction":{"@type":"SearchAction","target":"https://www.cloudkp.com/search?q={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- Google Fonts -->
<link href='//fonts.googleapis.com/css?family=Quicksand:400,500,600,700|Poppins:400,400i,500,500i,700,700i' media='all' rel='stylesheet' type='text/css'/>
<link href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'/>
<link href='https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css' rel='stylesheet'/>
<!-- Template Style CSS -->
<style id='page-skin-1' type='text/css'><!--
/*
-----------------------------------------------
Blogger Template Style
Name:        Infinty
License:     Premium Version
Version:     1.0
Author:      Sora Templates
Shared by:  http://techyjeeshan.blogspot.com/
Author Url:  https://www.soratemplates.com/
----------------------------------------------- */
/*-- Reset CSS --*/
/* PRELOADER */
ul.no-posts {
text-align: center;
}
html .home {
overflow-x: hidden;
}
#loader {
position: fixed;
top: 0;
bottom: 0;
margin: auto;
background: #7981B2;
height: 100%;
width: 100%;
z-index: 99999;
}
#outline {
stroke-dasharray: 2.42777px, 242.77666px;
stroke-dashoffset: 0;
-webkit-animation: anim 1.6s linear infinite;
animation: anim 1.6s linear infinite;
}
@-webkit-keyframes anim {
12.5% {
stroke-dasharray: 33.98873px, 242.77666px;
stroke-dashoffset: -26.70543px;
}
43.75% {
stroke-dasharray: 84.97183px, 242.77666px;
stroke-dashoffset: -84.97183px;
}
100% {
stroke-dasharray: 2.42777px, 242.77666px;
stroke-dashoffset: -240.34889px;
}
}
@keyframes anim {
12.5% {
stroke-dasharray: 33.98873px, 242.77666px;
stroke-dashoffset: -26.70543px;
}
43.75% {
stroke-dasharray: 84.97183px, 242.77666px;
stroke-dashoffset: -84.97183px;
}
100% {
stroke-dasharray: 2.42777px, 242.77666px;
stroke-dashoffset: -240.34889px;
}
}
.check-out {
position: absolute;
bottom: 0.5rem;
left: 50%;
transform: translateX(-50%);
font-size: 2rem;
color: #fff;
}
a,abbr,acronym,address,applet,b,big,blockquote,body,caption,center,cite,code,dd,del,dfn,div,dl,dt,em,fieldset,font,form,h1,h2,h3,h4,h5,h6,html,i,iframe,img,ins,kbd,label,legend,li,object,p,pre,q,s,samp,small,span,strike,strong,sub,sup,table,tbody,td,tfoot,th,thead,tr,tt,u,ul,var{
padding:0;
border:0;
outline:0;
vertical-align:baseline;
background:0 0;
text-decoration:none
}
form,textarea,input,button{
-webkit-appearance:none;
-moz-appearance:none;
appearance:none;
border-radius:0
}
dl,ul{
list-style-position:inside;
font-weight:400;
list-style:none
}
ul li{
list-style:none
}
caption,th{
text-align:center
}
img{
border:none;
position:relative
}
a,a:visited{
text-decoration:none
}
.clearfix{
clear:both
}
.section,.widget,.widget ul{
margin:0;
padding:0
}
a{
color:#003ee6
}
a:hover{
color:#222222
}
a img{
border:0
}
abbr{
text-decoration:none
}
.CSS_LIGHTBOX{
z-index:999999!important
}
.separator a{
clear:none!important;
float:none!important;
margin-left:0!important;
margin-right:0!important
}
#navbar-iframe,.widget-item-control,a.quickedit,.home-link,.feed-links{
display:none!important
}
.center{
display:table;
margin:0 auto;
position:relative
}
.widget > h2,.widget > h3{
display:none
}
h1,h2,h3,h4,h5,h6 {font-family:'Quicksand', sans-serif;font-weight:700;}
/*-- Body Content CSS --*/
body{
background-color:#fff;
font-family:'Poppins',sans-serif;
font-size:14px;
font-weight:400;
color:#888888;
word-wrap:break-word;
margin:0;
padding:0
}
.row{
width:1140px
}
#content-wrapper{
float:left;
width:100%;
margin:68px 0
}
.home #content-wrapper {
margin:35px 0;
}
.item #content-wrapper{
margin:40px 0
}
#content-wrapper > .container{
position:relative;
margin:0 auto
}
#main-wrapper{
overflow:hidden;
padding:0;
margin:0 -7px
}
.item #main-wrapper{
margin:0;
float: left;
overflow: hidden;
width: 66.66666667%;
box-sizing: border-box;
word-wrap: break-word;
padding: 0 15px;
margin: 0;
}
#sidebar-wrapper{
display:none;
float: right;
overflow: hidden;
width: 33.33333333%;
box-sizing: border-box;
word-wrap: break-word;
padding: 0 15px;
}
.item #sidebar-wrapper {
display:block;
}
.sidebar .widget{
position:relative;
overflow:hidden;
background-color:#fff;
box-sizing:border-box;
padding:0;
margin:0 0 35px
}
.sidebar .widget-title{
position:relative;
float:left;
width:100%;
height:32px;
background-color:#f0f0f0;
display:block;
margin:0 0 20px
}
.sidebar .widget-title > h3{
position:relative;
display:block;
height:32px;
font-size:12px;
color:#333333;
font-weight:700;
line-height:32px;
text-align:center;
text-transform:uppercase;
padding:0 15px;
margin:0;
border-radius:2px 2px 0 0
}
.sidebar .widget-content{
float:left;
width:100%;
margin:0
}
.list-label li{
position:relative;
display:block;
padding:8px 0;
border-top:1px dotted #eaeaea
}
.list-label li:first-child{
padding:0 0 8px;
border-top:0
}
.list-label li:last-child{
padding-bottom:0;
border-bottom:0
}
.list-label li a{
display:block;
color:#222222;
font-size:13px;
font-weight:400;
text-transform:capitalize;
transition:color .17s
}
.list-label li a:before{
content:"\f105";
float:left;
color:#222222;
font-size:12px;
font-weight:400;
font-family:FontAwesome;
margin:0 3px 0 0;
transition:color .17s
}
.list-label li a:hover{
color:#003ee6
}
.list-label .label-count{
position:relative;
float:right;
font-weight:400
}
.cloud-label li{
position:relative;
float:left;
margin:0 5px 5px 0
}
.cloud-label li a{
display:block;
height:26px;
background-color:#fff;
color:#222222;
font-size:12px;
line-height:26px;
font-weight:400;
padding:0 10px;
border:1px solid #eaeaea;
border-radius:3px;
transition:all .17s ease
}
.cloud-label li a:hover{
color:#003ee6
}
.cloud-label .label-count{
display:none
}
.sidebar .FollowByEmail > .widget-title > h3{
margin:0
}
.FollowByEmail .widget-content{
position:relative;
overflow:hidden;
background-color:#003ee6;
font-weight:400;
text-align:center;
box-sizing:border-box;
padding:20px
}
.FollowByEmail .widget-content > h3{
font-size:18px;
color:#fff;
font-weight:700;
margin:0 0 13px
}
.FollowByEmail .before-text{
font-size:13px;
color:#fff;
line-height:1.4em;
margin:0 0 15px;
display:block;
padding:0 15px;
overflow:hidden
}
.FollowByEmail .follow-by-email-inner{
position:relative
}
.FollowByEmail .follow-by-email-inner .follow-by-email-address{
width:100%;
height:34px;
color:#888;
font-size:11px;
font-family:inherit;
text-align:center;
padding:0 10px;
margin:0 0 10px;
box-sizing:border-box;
border:1px solid #eaeaea;
transition:ease .17s
}
.FollowByEmail .follow-by-email-inner .follow-by-email-address:focus{
border-color:rgba(0,0,0,0.1)
}
.FollowByEmail .follow-by-email-inner .follow-by-email-submit{
width:100%;
height:34px;
font-family:inherit;
font-size:11px;
color:#fff;
background-color:#222222;
text-transform:uppercase;
text-align:center;
font-weight:700;
cursor:pointer;
margin:0;
border:0;
transition:opacity .17s
}
.FollowByEmail .follow-by-email-inner .follow-by-email-submit:hover{
opacity:.8
}
#ArchiveList ul.flat li{
color:#222222;
font-size:13px;
font-weight:400;
padding:8px 0;
border-bottom:1px dotted #eaeaea
}
#ArchiveList ul.flat li:first-child{
padding-top:0
}
#ArchiveList ul.flat li:last-child{
padding-bottom:0;
border-bottom:0
}
#ArchiveList .flat li > a{
display:block;
color:#222222;
transition:color .17s
}
#ArchiveList .flat li > a:hover{
color:#003ee6
}
#ArchiveList .flat li > a:before{
content:"\f105";
float:left;
color:#222222;
font-size:12px;
font-weight:400;
font-family:FontAwesome;
margin:0 3px 0 0;
display:inline-block;
transition:color .17s
}
#ArchiveList .flat li > a > span{
position:relative;
float:right;
font-weight:400
}
.PopularPosts .post{
overflow:hidden;
margin:20px 0 0
}
.PopularPosts .post:first-child{
margin:0
}
.PopularPosts .post-image-link{
position:relative;
width:80px;
height:65px;
float:left;
overflow:hidden;
display:block;
vertical-align:middle;
margin:0 12px 0 0
}
.PopularPosts .post-info{
overflow:hidden
}
.PopularPosts .post-title{
font-size:14px;
font-weight:500;
line-height:1.4em;
margin:0 0 5px
}
.PopularPosts .post-title a{
display:block;
color:#222222;
transition:color .17s
}
.PopularPosts .post-title a:hover{
color:#003ee6
}
.PopularPosts .post-meta{
font-size:11px
}
.PopularPosts .post-date:before{
font-size:10px
}
.FeaturedPost .post-image-link{
display:block;
position:relative;
overflow:hidden;
width:100%;
height:180px;
margin:0 0 13px
}
.FeaturedPost .post-title{
font-size:18px;
overflow:hidden;
font-weight:500;
line-height:1.4em;
margin:0 0 10px
}
.FeaturedPost .post-title a{
color:#222222;
display:block;
transition:color .17s ease
}
.FeaturedPost .post-title a:hover{
color:#003ee6
}
.Text{
font-size:13px
}
.contact-form-widget form{
font-weight:400
}
.contact-form-name{
float:left;
width:100%;
height:30px;
font-family:inherit;
font-size:13px;
line-height:30px;
box-sizing:border-box;
padding:5px 10px;
margin:0 0 10px;
border:1px solid #eaeaea
}
.contact-form-email{
float:left;
width:100%;
height:30px;
font-family:inherit;
font-size:13px;
line-height:30px;
box-sizing:border-box;
padding:5px 10px;
margin:0 0 10px;
border:1px solid #eaeaea
}
.contact-form-email-message{
float:left;
width:100%;
font-family:inherit;
font-size:13px;
box-sizing:border-box;
padding:5px 10px;
margin:0 0 10px;
border:1px solid #eaeaea
}
.contact-form-button-submit{
float:left;
width:100%;
height:30px;
background-color:#003ee6;
font-size:13px;
color:#fff;
line-height:30px;
cursor:pointer;
box-sizing:border-box;
padding:0 10px;
margin:0;
border:0;
transition:background .17s ease
}
.contact-form-button-submit:hover{
background-color:#222222
}
.contact-form-error-message-with-border{
float:left;
width:100%;
background-color:#fbe5e5;
font-size:11px;
text-align:center;
line-height:11px;
padding:3px 0;
margin:10px 0;
box-sizing:border-box;
border:1px solid #fc6262
}
.contact-form-success-message-with-border{
float:left;
width:100%;
background-color:#eaf6ff;
font-size:11px;
text-align:center;
line-height:11px;
padding:3px 0;
margin:10px 0;
box-sizing:border-box;
border:1px solid #5ab6f9
}
.contact-form-cross{
margin:0 0 0 3px
}
.contact-form-error-message,.contact-form-success-message{
margin:0
}
.BlogSearch .search-input{
float:left;
width:75%;
height:30px;
background-color:#fff;
font-weight:400;
font-size:13px;
line-height:30px;
box-sizing:border-box;
padding:5px 10px;
border:1px solid #eaeaea;
border-right-width:0
}
.BlogSearch .search-action{
float:right;
width:25%;
height:30px;
font-family:inherit;
font-size:13px;
line-height:30px;
cursor:pointer;
box-sizing:border-box;
background-color:#003ee6;
color:#fff;
padding:0 5px;
border:0;
transition:background .17s ease
}
.BlogSearch .search-action:hover{
background-color:#222222
}
.Profile .profile-img{
float:left;
width:80px;
height:80px;
margin:0 15px 0 0;
transition:all .17s ease
}
.Profile .profile-datablock{
margin:0
}
.Profile .profile-data .g-profile{
display:block;
font-size:14px;
color:#222222;
margin:0 0 5px;
transition:color .17s ease
}
.Profile .profile-data .g-profile:hover{
color:#003ee6
}
.Profile .profile-info > .profile-link{
color:#222222;
font-size:11px;
margin:5px 0 0;
transition:color .17s ease
}
.Profile .profile-info > .profile-link:hover{
color:#003ee6
}
.Profile .profile-datablock .profile-textblock{
display:none
}
.common-widget .LinkList ul li,.common-widget .PageList ul li{
width:calc(50% - 5px);
padding:7px 0 0
}
.common-widget .LinkList ul li:nth-child(odd),.common-widget .PageList ul li:nth-child(odd){
float:left
}
.common-widget .LinkList ul li:nth-child(even),.common-widget .PageList ul li:nth-child(even){
float:right
}
.common-widget .LinkList ul li a,.common-widget .PageList ul li a{
display:block;
color:#222222;
font-size:13px;
font-weight:400;
transition:color .17s ease
}
.common-widget .LinkList ul li a:hover,.common-widget .PageList ul li a:hover{
color:#003ee6
}
.common-widget .LinkList ul li:first-child,.common-widget .LinkList ul li:nth-child(2),.common-widget .PageList ul li:first-child,.common-widget .PageList ul li:nth-child(2){
padding:0
}
.post-image-wrap{
position:relative;
display:block
}
.post-image-link:hover:after,.post-image-wrap:hover .post-image-link:after{
opacity:1
}
.post-image-link,.comments .avatar-image-container{
background-color:#f9f9f9
}
.post-thumb{
display:block;
position:relative;
width:100%;
height:100%;
color:transparent;
object-fit:cover;
z-index:1;
opacity: 0;
transition:opacity .35s ease,transform .35s ease
}
.post-thumb.lazy-yard {
opacity: 1;
}
.widget-title > h3{
display:none
}
#brand-services-wrap .widget-title {
display:none;
}
#brand-services-wrap .widget-title > h3 {
display: block;
font-size: 42px;
color: #222222;
font-weight: 700;
}
.custom-widget li{
overflow:hidden;
margin:20px 0 0
}
.custom-widget li:first-child{
padding:0;
margin:0;
border:0
}
.custom-widget .post-image-link{
position:relative;
width:80px;
height:60px;
float:left;
overflow:hidden;
display:block;
vertical-align:middle;
margin:0 12px 0 0
}
.custom-widget .post-info{
overflow:hidden
}
.custom-widget .post-title{
overflow:hidden;
font-size:13px;
font-weight:400;
line-height:1.5em;
margin:0 0 3px
}
.custom-widget .post-title a{
display:block;
color:#222222;
transition:color .17s
}
.custom-widget li:hover .post-title a{
color:#003ee6
}
.custom-widget .post-meta{
font-size:12px
}
#editorial-wrap .container {
margin: 0 auto;
}
.editorial-authors {
display: flex;
flex-wrap: wrap;
margin: 0 -15px 0;
}
.editorial-authors .widget {
display: block;
width: 33.33333%;
padding:0 15px;
box-sizing: border-box;
border-radius: 12px;
text-align: center;
}
.editorial-authors .widget .editorial-avatar-wrap {
position: relative;
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-avatar {
display: block;
width: 100%;
height: 510px;
overflow: hidden;
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-avatar img {
display: block;
width: 100%;
height: 100%;
object-fit: cover;
margin: 0;
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-info {
position: absolute;
bottom: 0;
left: 0;
right: 0;
padding: 30px 30px 34px;
text-align: center;
background-image: -webkit-gradient(linear,left top,left bottom,from(#000),to(transparent));
background-image: -webkit-linear-gradient(bottom,#000,transparent);
background-image: -moz-linear-gradient(bottom,#000,transparent);
background-image: -ms-linear-gradient(bottom,#000,transparent);
background-image: -o-linear-gradient(bottom,#000,transparent);
background-image: linear-gradient(bottom,#000,transparent);
filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#000',endColorStr='rgba(0, 0, 0, 0)');
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-info .editorial-title {
font-size: 22px;
color: #fff;
font-weight: 700;
margin: 0 0 2px;
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-info .editorial-meta {
font-size: 14px;
color: #fff;
font-weight: 400;
margin: 0;
display: block;
}
#editorial-wrap .head-text {
margin: 15px 0 50px;
}
#editorial-wrap {
display: none;
margin-bottom: 50px;
}
#top-bar{
background-image: url(https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhiWeMqk1nDB2g_VH2Vev0tvcsGWLhodnbOsE8XVFuia9fQK3oRrDKgTY3H9Ytru-SK2zL1eS-Fm8_pFU5MQRUvOLb-tuRD6JwP0-AOVLc5Hc9ivYi0ibwTwThlSsujHu4pGnGSrgbpyk5o/s16000/email-bg.jpg);
background-size: cover;
background-position: 50%;
background-repeat: no-repeat;
background-attachment: fixed;
width:100%;
padding:20px 0 0;
overflow:hidden;
margin:0;
position:relative;
}
.top-bar-bg{
background-color: rgba(68,63,69,0.9);
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
box-sizing: border-box;
}
#top-bar .container{
margin:0 auto
}
.top-bar-nav{
position:relative;
float:right;
display:block
}
.top-bar-nav .widget > .widget-title{
display:none
}
.top-bar-nav ul li{
float:left
}
.top-bar-nav ul li > a{
height:30px;
display:block;
color:#fff;
font-size:12px;
font-weight:400;
line-height:30px;
margin:0 0 0 10px;
padding:0 5px;
transition:color .17s
}
.top-bar-nav ul li:first-child > a{
padding:0 5px 0 0
}
.top-bar-nav ul > li:hover > a{
color:#003ee6
}
.top-bar-social{
float:left;
width:66.66666667%;
position:relative;
display:block;
margin: 0;
padding:25px 0 0;
text-align:center;
}
#author-email-pic {
width: 33.33333333%;
float: right;
}
#author-email-pic img {
height: auto;
max-width: 100%;
vertical-align: top;
}
.top-bar-social .FollowByEmail {
max-width: 550px;
width: 100%;
margin: 0 auto;
}
.top-bar-social .FollowByEmail .widget-content {
background:transparent;
}
.top-bar-social .FollowByEmail .follow-by-email-inner .follow-by-email-address {
border-radius:10px;
height: 50px;
font-size: 15px;
}
.top-bar-social .FollowByEmail .follow-by-email-inner .follow-by-email-submit {
width:auto;
display: inline-block;
padding: 0 15px;
box-sizing: border-box;
border-radius: 30px;
background:#003ee6;
height: 45px;
font-size: 14px;
letter-spacing: 1px;
}
.top-bar-social .LinkList {
margin-top:15px;
}
.top-bar-social .widget-title > h3 {
display: block;
color: #f2f2f2;
font-size: 36px;
line-height: 42px;
font-weight: 700;
margin: 0 0 15px;
}
.top-bar-social .LinkList >  .widget-title{
display:none
}
.top-bar-social ul > li{
display:inline-block
}
.top-bar-social ul > li > a{
display:block;
width:30px;
height:30px;
border:1px solid rgba(158, 158, 158, 0.15);
color:#ffffff;
font-size:14px;
text-align:center;
line-height:30px;
padding:0;
margin:0 0 0 10px;
transition:all .17s ease;
border-radius:50%;
}
.top-bar-social ul > li:hover > a{
color:#003ee6
}
.social a:before{
display:inline-block;
font-family:FontAwesome;
font-style:normal;
font-weight:400
}
.social .facebook a:before{
content:"\f230"
}
.social .facebook-f a:before{
content:"\f09a"
}
.social .twitter a:before{
content:"\f099"
}
.social .gplus a:before{
content:"\f0d5"
}
.social .rss a:before{
content:"\f09e"
}
.social .youtube a:before{
content:"\f16a"
}
.social .skype a:before{
content:"\f17e"
}
.social .stumbleupon a:before{
content:"\f1a4"
}
.social .tumblr a:before{
content:"\f173"
}
.social .vk a:before{
content:"\f189"
}
.social .stack-overflow a:before{
content:"\f16c"
}
.social .github a:before{
content:"\f09b"
}
.social .linkedin a:before{
content:"\f0e1"
}
.social .dribbble a:before{
content:"\f17d"
}
.social .soundcloud a:before{
content:"\f1be"
}
.social .behance a:before{
content:"\f1b4"
}
.social .digg a:before{
content:"\f1a6"
}
.social .instagram a:before{
content:"\f16d"
}
.social .pinterest a:before{
content:"\f0d2"
}
.social .pinterest-p a:before{
content:"\f231"
}
.social .twitch a:before{
content:"\f1e8"
}
.social .delicious a:before{
content:"\f1a5"
}
.social .codepen a:before{
content:"\f1cb"
}
.social .reddit a:before{
content:"\f1a1"
}
.social .whatsapp a:before{
content:"\f232"
}
.social .snapchat a:before{
content:"\f2ac"
}
.social .email a:before{
content:"\f0e0"
}
.social .external-link a:before{
content:"\f14c"
}
.social-color .facebook a,.social-color .facebook-f a{
background-color:#3b5999
}
.social-color .twitter a{
background-color:#00acee
}
.social-color .gplus a{
background-color:#db4a39
}
.social-color .youtube a{
background-color:#db4a39
}
.social-color .instagram a{
background-color:#bc3490
}
.social-color .pinterest a,.social-color .pinterest-p a{
background-color:#ca2127
}
.social-color .dribbble a{
background-color:#ea4c89
}
.social-color .linkedin a{
background-color:#0077b5
}
.social-color .tumblr a{
background-color:#365069
}
.social-color .twitch a{
background-color:#6441a5
}
.social-color .rss a{
background-color:#ffc200
}
.social-color .skype a{
background-color:#00aff0
}
.social-color .stumbleupon a{
background-color:#eb4823
}
.social-color .vk a{
background-color:#4a76a8
}
.social-color .stack-overflow a{
background-color:#f48024
}
.social-color .github a{
background-color:#24292e
}
.social-color .soundcloud a{
background-color:#ff5400
}
.social-color .behance a{
background-color:#191919
}
.social-color .digg a{
background-color:#1b1a19
}
.social-color .delicious a{
background-color:#0076e8
}
.social-color .codepen a{
background-color:#000
}
.social-color .reddit a{
background-color:#ff4500
}
.social-color .whatsapp a{
background-color:#3fbb50
}
.social-color .snapchat a{
background-color:#ffe700
}
.social-color .email a{
background-color:#888
}
.social-color .external-link a{
background-color:#222222
}
.home #header-wrap {
position:fixed;
}
#header-wrap{
position: relative;
left: 0;
top: 0;
padding: 0;
width: 100%;
height: 68px;
z-index: 1010;
box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
background: #000000;
}
#header-wrap .container{
margin:0 auto;
position:relative
}
.header-logo{
position:relative;
float:left;
height:38px;
margin:15px 0 0
}
.header-logo .header-brand{
display:inline-block;
line-height:0
}
.header-logo img{
max-width:100%;
height:38px;
vertical-align:middle
}
.header-logo h1{
color:#ffffff;
font-size:20px;
line-height:38px;
margin:0
}
.header-logo p{
font-size:12px;
margin:5px 0 0
}
#parallax-menu {
display: none;
}
.home #parallax-menu {
display: block;
}
.scrolling-menu {
float: right;
position: relative;
height: 68px;
}
.scrolling-menu ul > li {
float: left;
position: relative;
margin: 0;
padding: 0;
transition: color .17s;
}
.scrolling-menu ul > li > a {
position: relative;
color: #ffffff;
font-size: 12px;
font-weight: 600;
text-transform: uppercase;
line-height: 68px;
display: inline-block;
text-decoration: none;
padding: 0 10px;
margin: 0 0 0 5px;
transition: color .17s;
}
.home #main-menu {
display:none;
}
#main-menu{
float:right
}
#main-menu .widget,#main-menu .widget > .widget-title{
display:none
}
#main-menu .show-menu{
display:block
}
#main-menu{
position:relative;
height:68px;
z-index:15
}
#main-menu ul > li{
float:left;
position:relative;
margin:0;
padding:0;
transition:color .17s
}
#main-menu ul > li > a{
position:relative;
color:#ffffff;
font-size:12px;
font-weight:600;
text-transform:uppercase;
line-height:68px;
display:inline-block;
text-decoration:none;
padding:0 10px;
margin:0 0 0 5px;
transition:color .17s
}
#main-menu #main-menu-nav > li:last-child > a{
padding:0 0 0 10px
}
#main-menu ul > li > a:hover{
color:#003ee6
}
#main-menu ul > li > ul{
position:absolute;
float:left;
left:0;
top:68px;
width:180px;
background-color:#222222;
z-index:99999;
margin-top:0;
padding:0;
visibility:hidden;
opacity:0
}
#main-menu ul > li > ul > li > ul{
position:absolute;
float:left;
top:0;
left:100%;
margin-left:0
}
#main-menu ul > li > ul > li{
display:block;
float:none;
position:relative;
transition:background .17s ease
}
#main-menu ul > li > ul > li a{
display:block;
height:34px;
font-size:11px;
color:#ffffff;
line-height:34px;
box-sizing:border-box;
padding:0 15px;
margin:0
}
#main-menu ul > li > ul > li:hover{
background-color:#003ee6
}
#main-menu ul > li > ul > li:hover > a{
color:#fff
}
#main-menu ul > li.has-sub > a:after{
content:'\f107';
float:right;
font-family:FontAwesome;
font-size:12px;
font-weight:400;
margin:0 0 0 6px
}
#main-menu ul > li > ul > li.has-sub > a:after{
content:'\f105';
float:right;
margin:0
}
#main-menu ul > li:hover > ul,#main-menu ul > li > ul > li:hover > ul{
visibility:visible;
opacity:1
}
#main-menu ul ul{
transition:all .17s ease
}
.mobile-menu-toggle, .scrolling-mobile-menu-toggle{
display:none;
position:absolute;
right:0;
top:0;
height:68px;
line-height:68px;
z-index:20;
color:#ffffff;
font-size:21px;
font-weight:400;
text-align:left;
cursor:pointer;
padding:0 0 0 20px;
transition:color .17s ease
}
.home .mobile-menu-toggle, .home .mobile-menu-wrap {
display:none;
}
.mobile-menu-toggle:before, .scrolling-mobile-menu-toggle:before{
content:"\f0c9";
font-family:FontAwesome
}
.nav-active .mobile-menu-toggle:before, .scrolling-active .scrolling-mobile-menu-toggle:before{
content:"\f00d";
font-family:FontAwesome
}
.mobile-menu-toggle:hover, .scrolling-mobile-menu-toggle:hover{
color:#003ee6
}
.overlay{
display:none;
position:fixed;
top:0;
left:0;
right:0;
bottom:0;
z-index:990;
background:rgba(0,0,0,0.8)
}
.mobile-menu-wrap, .scrolling-mobile-menu-wrap{
display:none
}
.mobile-menu, .scrolling-mobile-menu{
position:absolute;
top:68px;
left:0;
width:100%;
background-color:#222222;
box-sizing:border-box;
visibility:hidden;
z-index:1000;
opacity:0;
border-top:1px solid rgba(255,255,255,0.05);
transition:all .17s ease
}
.nav-active .mobile-menu, .scrolling-active .scrolling-mobile-menu{
visibility:visible;
opacity:1
}
.mobile-menu > ul, .scrolling-mobile-menu > ul{
margin:0
}
.mobile-menu .m-sub{
display:none;
padding:0
}
.mobile-menu ul li, .scrolling-mobile-menu ul li{
position:relative;
display:block;
overflow:hidden;
float:left;
width:100%;
font-size:11px;
font-weight:600;
text-transform:uppercase;
line-height:38px;
border-bottom:1px solid rgba(255,255,255,0.05)
}
.mobile-menu ul li:last-child, .scrolling-mobile-menu ul li:last-child{
border-bottom:0
}
.mobile-menu > ul li ul{
overflow:hidden
}
.mobile-menu ul li a, .scrolling-mobile-menu ul li a{
color:#ffffff;
padding:0 20px;
display:block;
transition:all .17s ease
}
.mobile-menu ul li a:hover, .scrolling-mobile-menu ul li a:hover{
color:#003ee6
}
.mobile-menu ul li.has-sub .submenu-toggle{
position:absolute;
top:0;
right:0;
color:#ffffff;
cursor:pointer;
border-left:1px solid rgba(255,255,255,0.05)
}
.mobile-menu ul li.has-sub .submenu-toggle:after{
content:'\f105';
font-family:FontAwesome;
font-weight:400;
float:right;
width:38px;
font-size:16px;
line-height:38px;
text-align:center;
transition:all .17s ease
}
.mobile-menu ul li.has-sub .submenu-toggle:hover{
color:#003ee6
}
.mobile-menu ul li.has-sub.show > .submenu-toggle:after{
transform:rotate(90deg)
}
.mobile-menu ul li ul li:first-child{
border-top:1px solid rgba(255,255,255,0.05)
}
.mobile-menu ul li ul li{
background-color:rgba(255,255,255,0.05)
}
#intro-wrap{
display:none;
position:relative;
float:left;
width:100%;
z-index:2;
margin:0
}
.slide-in {
font-size: 3.3rem;
position: absolute;
bottom: 7.2rem;
left: 0;
display: block;
width: 100%;
margin: 0;
padding: 0
}
.slide-in .pointer {
position: absolute;
top: 50%;
left: 50%;
width: 26px;
height: 42px;
-webkit-transform: translate(-50%, -50%);
-ms-transform: translate(-50%, -50%);
transform: translate(-50%, -50%);
border: 2px solid #fff;
border-radius: 26px;
-webkit-backface-visibility: hidden
}
.slide-in .pointer:after {
position: absolute;
top: 5px;
left: 50%;
width: 4px;
height: 4px;
margin-left: -2px;
content: '';
-webkit-transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
-webkit-animation: scroll 1.5s -1s cubic-bezier(.68, -.55, .265, 1.55) infinite;
animation: scroll 1.5s -1s cubic-bezier(.68, -.55, .265, 1.55) infinite;
opacity: 1;
border-radius: 100%;
background-color: #fff
}
@-webkit-keyframes scroll {
0%, 20% {
-webkit-transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
transform: translateY(0) scaleY(1) scaleX(1) translateZ(0)
}
10% {
-webkit-transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
opacity: 1
}
to {
-webkit-transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
opacity: .01
}
}
@keyframes scroll {
0%, 20% {
-webkit-transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
transform: translateY(0) scaleY(1) scaleX(1) translateZ(0)
}
10% {
-webkit-transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
opacity: 1
}
to {
-webkit-transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
opacity: .01
}
}
@-webkit-keyframes blink {
0%, to {
opacity: 1
}
50% {
opacity: 0
}
}
@keyframes blink {
0%, to {
opacity: 1
}
50% {
opacity: 0
}
}
.editorial-border {
display: block;
width: 100%;
height: 60px;
max-height: 60px;
margin: 0;
z-index:5;
bottom:0;
position:absolute;
left:0px;
float:left;
}
.parallax1 > use {
animation: move-forever1 10s linear infinite;
&:nth-child(1) {
animation-delay: -2s;
}
}
.parallax2 > use {
animation: move-forever2 8s linear infinite;
&:nth-child(1) {
animation-delay: -2s;
}
}
.parallax3 > use {
animation: move-forever3 6s linear infinite;
&:nth-child(1) {
animation-delay: -2s;
}
}
.parallax4 > use {
animation: move-forever4 4s linear infinite;
&:nth-child(1) {
animation-delay: -2s;
}
}
@keyframes move-forever1 {
0% {
transform: translate(85px, 0%);
}
100% {
transform: translate(-90px, 0%);
}
}
@keyframes move-forever2 {
0% {
transform: translate(-90px, 0%);
}
100% {
transform: translate(85px, 0%);
}
}
@keyframes move-forever3 {
0% {
transform: translate(85px, 0%);
}
100% {
transform: translate(-90px, 0%);
}
}
@keyframes move-forever4 {
0% {
transform: translate(-90px, 0%);
}
100% {
transform: translate(85px, 0%);
}
}
#main-intro{
position:relative;
float:left;
width:100%;
height:100%;
background: linear-gradient(125deg, #00FF57 0%, #010033 40%, #460043 70%, #F0FFC5 100%), linear-gradient(55deg, #0014C9 0%, #410060 100%), linear-gradient(300deg, #FFC700 0%, #001AFF 100%), radial-gradient(135% 215% at 115% 40%, #393939 0%, #393939 40%, #849561 calc(40% + 1px), #849561 60%, #EED690 calc(60% + 1px), #EED690 80%, #ECEFD8 calc(80% + 1px), #ECEFD8 100%), linear-gradient(125deg, #282D4F 0%, #282D4F 40%, #23103A calc(40% + 1px), #23103A 70%, #A0204C calc(70% + 1px), #A0204C 88%, #FF6C00 calc(88% + 1px), #FF6C00 100%);
background-blend-mode: overlay, screen, overlay, overlay, normal;
}
#main-intro .widget{
height:100%;
width:100%;
display:block;
overflow:hidden
}
#main-intro .widget.HTML, #main-intro #HTML100 {
display: none;
}
.intro-content{
position:absolute;
top:50%;
left:50%;
transform:translate(-50%,-50%);
width:520px;
text-align:center;
margin:0
}
.intro-title{
font-size:37px;
color:#ffffff;
font-weight:700;
margin:0 0 30px
}
.intro-snippet{
font-size:14px;
line-height:25px;
color:#f2f2f2;
margin:0
}
.intro-action a, .service-action a{
display:inline-block;
height:40px;
background-color:#003ee6;
font-size:14px;
color:#fff;
line-height:40px;
padding:0 25px;
margin:30px 0 0;
border-radius:3px;
transition:background .17s ease
}
.intro-action a:hover{
background-color:#222222
}
#brand-services-wrap{
display:none;
float:left;
width:100%;
background:#443f45;
padding:30px 0
}
#brand-services-wrap .container {
position: relative;
margin: 0 auto;
}
#brand-services-wrap ul {
padding:0;
margin:0;
list-style:none;
}
#brand-services-wrap li{
float: left;
width: calc(100% / 5);
box-sizing: border-box;
padding: 0 20px;
position:relative;
text-align:center;
}
.counter-box {
overflow: hidden;
margin: 0 auto;
padding: 60px 0;
position: relative;
background-color: #f5f5f5;
}
.counter-box .container {
margin:0 auto;
}
.counter-box-info {
float: left;
width: 65%;
padding-right:30px;
box-sizing: border-box;
}
.counter-box-info .head-text {
text-align: left;
margin: 0 0 30px;
}
.counter-box-image {
float: right;
width: 35%;
padding-left:30px;
box-sizing: border-box;
}
.counter-box-wrap {
float:left;
width:100%;
position:relative;
margin: 0 auto;
background-color: #ffffff;
-webkit-border-radius: 9px;
-khtml-border-radius: 9px;
-moz-border-radius: 9px;
-ms-border-radius: 9px;
-o-border-radius: 9px;
border-radius: 9px;
-webkit-box-shadow: 0 4px 5px rgb(0 0 0 / 11%);
-khtml-box-shadow: 0 4px 5px rgba(0,0,0,.11);
-moz-box-shadow: 0 4px 5px rgba(0,0,0,.11);
-ms-box-shadow: 0 4px 5px rgba(0,0,0,.11);
-o-box-shadow: 0 4px 5px rgba(0,0,0,.11);
box-shadow: 0 4px 5px rgb(0 0 0 / 11%);
}
.counter-box-wrap .widget {
width: 33.333%;
float: left;
padding: 30px 10px;
box-sizing: border-box;
color: #222222;
position: relative;
}
.counter-avatar {
float: left;
margin-right: 15px;
position: relative;
height: 45px;
width: 45px;
flex-shrink: 0;
text-align: center;
line-height: 45px;
}
.counter-avatar img {
width: 100%;
height: 100%;
}
.counter-avatar i {
display: block;
line-height: 45px;
font-size: 45px;
font-weight: 400;
font-style: normal;
margin: 0;
color: #b09991;
}
.counter-info {
overflow: hidden;
}
.counter-info .counter-title {
font-size: 30px;
line-height: .9;
font-weight: 700;
margin: 0;
padding: 0;
}
.counter-info .counter-meta {
font-weight: 400;
font-size: 12px;
color: #777;
margin: 0;
}
.counter-box-image .counter-content {
position: relative;
background-size: cover;
background-position: 50%;
background-repeat: no-repeat;
-webkit-border-radius: 9px;
-khtml-border-radius: 9px;
-moz-border-radius: 9px;
-ms-border-radius: 9px;
-o-border-radius: 9px;
border-radius: 9px;
}
.counter-content-box-color {
background-color: rgb(255 255 255 / 83%);
position: absolute;
top: 7.5px;
left: 7.55px;
width: calc(100% - 15px);
height: calc(100% - 15px);
-webkit-border-radius: 9px;
-khtml-border-radius: 9px;
-moz-border-radius: 9px;
-ms-border-radius: 9px;
-o-border-radius: 9px;
border-radius: 9px;
box-sizing: border-box;
}
.counter-image-wrap, .counter-image-wrap .widget, .counter-image-wrap .widget-content, .counter-image-wrap .counter-content {
height: 100%;
}
.counter-content-details {
position: absolute;
bottom: 20%;
left: 20%;
}
.counter-content-details span.counter-title {
display: block;
font-size: 20px;
margin: 0;
margin-bottom: 15px;
color: #000;
text-transform: uppercase;
font-weight: 700;
}
.counter-content-details span.counter-snippet {
display: block;
font-size: 50px;
margin: 0;
color: #000;
text-transform: uppercase;
font-weight: 700;
}
#intro-author-wrap{
background: -webkit-linear-gradient(right, #2a2a2a 50%, #b09991 50%);
display:none;
position:relative;
float:left;
width:100%;
padding:0;
margin:0;
}
#intro-author-wrap .container{
position:relative;
margin:0 auto
}
#intro-author-heading {
width: 100%;
float: left;
display:block;
position:relative;
padding: 30px 0;
text-align:center;
background: #003ee6;
}
#intro-author-heading .button {
margin: 10px 0 0;
padding: 8px 20px;
background: #222222;
display: inline-block;
float: none;
}
.author-intro-widgets {
}
.author-intro-widgets {
margin: 0;
display: flex;
flex-wrap: wrap;
}
.author-intro-widgets .left-side-widget, .author-intro-widgets .center-side-widget, .author-intro-widgets .right-side-widget {
display: block;
width: 33.3333%;
padding: 0;
box-sizing: border-box;
position:relative;
}
.author-intro-widgets .right-side-widget {
}
.author-intro-widgets .author-list .widget {
display: block;
list-style: none;
width:100%;
float: left;
margin:0;
box-sizing: border-box;
position:relative;
}
#intro-author-photo{
position:relative;
float:left;
width:100%;
height:400px;
box-sizing:border-box;
padding:0 10px
}
#intro-author-photo .author-image{
position:relative;
display:block;
width:100%;
height:100%;
background-repeat:no-repeat;
background-size:cover;
margin:0
}
.author-title{
display:block;
font-size:27px;
color:#ffffff;
font-weight:700;
margin:15px 0 20px
}
.author-snippet{
font-size:14px;
color:#f2f2f2;
line-height:24px;
margin:0
}
#intro-services-wrap{
display:none;
float:left;
width:100%;
background-color:#f8f8f8;
padding:80px 0
}
#intro-services-wrap .container{
position:relative;
margin:0 auto
}
#intro-services{
display:block;
margin:0 -20px
}
#intro-services .widget{
float:left;
width:calc(100% / 3);
box-sizing:border-box;
padding:0 20px
}
.service-content{
display:block;
text-align:center
}
#intro-services .service-icon{
display:inline-block;
width:70px;
height:70px;
text-align:center;
border-radius:100%;
overflow:hidden
}
#intro-services .service-icon img{
display:block;
width:100%;
height:100%;
object-fit:cover;
border-radius:100%;
color:transparent
}
#intro-services .service-icon i{
display:block;
background-color:#f2f2f2;
font-size:30px;
color:#003ee6;
line-height:70px;
font-weight:400;
font-style:normal;
margin:0
}
.author-intro-widgets .author-list .service-content-details {
z-index: 999;
position: relative;
}
.author-intro-widgets .author-list .service-content-details .service-snippet {
color: #ffffff;
font-size: 13px;
line-height: 22px;
}
.author-intro-widgets .left-side-widget .service-content {
text-align:right;
}
.author-intro-widgets .author-list .service-content {
text-align: left;
padding: 55px 45px;
overflow: hidden;
position: relative;
background-size: cover;
background-position: 50%;
background-repeat: no-repeat;
box-sizing: border-box;
}
.author-intro-widgets .service-content .service-content-box-color {
background-color: #b09991;
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
box-sizing: border-box;
-webkit-transition: all .4s cubic-bezier(.39,.575,.565,1)0s;
-khtml-transition: all .4s cubic-bezier(.39,.575,.565,1)0s;
-moz-transition: all .4s cubic-bezier(.39,.575,.565,1)0s;
-ms-transition: all .4s cubic-bezier(.39,.575,.565,1)0s;
-o-transition: all .4s cubic-bezier(.39,.575,.565,1)0s;
transition: all .4s cubic-bezier(.39,.575,.565,1)0s;
}
.author-intro-widgets #intro-services-left .service-content .service-content-box-color  {
background-color: #b09991;
}
.author-intro-widgets #intro-services-center .service-content .service-content-box-color  {
background-color: #443f45;
}
.author-intro-widgets #intro-services-right .service-content .service-content-box-color  {
background-color: #2a2a2a;
}
.author-intro-widgets .service-content:hover  .service-content-box-color {
opacity: .8;
}
.service-title{
font-size:14px;
color:#ffffff;
font-weight:700;
text-transform:capitalize;
margin:25px 0 15px
}
.author-intro-widgets .author-list  .service-title{
font-size: 28px;
line-height: 1.2;
margin:0 0 10px;
}
overflow:hidden;
}
.service-snippet{
font-size:14px;
line-height:24px;
margin:0
}
.featured-posts {
margin:0 auto;
}
.featured-posts > .widget{
display:none;
position:relative;
float:left;
width:100%;
margin:0 0 30px
}
.featured-posts > .show-widget{
display:block
}
ul.feat-big {
display: flex;
flex-wrap: wrap;
margin: 0 -10px;
}
.feat-big li{
display: block;
width: 25%;
box-sizing: border-box;
padding: 0 10px;
margin: 0 0 20px;
}
.feat-big .feat-inner{
position:relative;
float:left;
width:100%;
overflow:hidden
}
.feat-big .post-image-link{
position:relative;
float:left;
display:block;
overflow:hidden;
}
.feat-big .feat-inner .post-image-link{
width:100%;
height:180px;
margin:0
}
.feat-big .post-title{
overflow: hidden;
float:left;
width:100%;
font-size: 16px;
font-weight: 700;
line-height: 1.4em;
margin: 6px 0;
text-transform: uppercase;
}
.feat-big .item-big .post-info{
position: absolute;
bottom: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(68,63,69,0.9);
overflow: hidden;
z-index: 5;
box-sizing: border-box;
padding: 30px 20px 20px;
-webkit-transform: translateY(100%);
-moz-transform: translateY(100%);
-ms-transform: translateY(100%);
-o-transform: translateY(100%);
transform: translateY(100%);
-webkit-transition: 0.3s ease-in-out;
-moz-transition: 0.3s ease-in-out;
-o-transition: 0.3s ease-in-out;
transition: 0.3s ease-in-out;
}
.feat-big .item-big .post-info-inner {
position: relative;
margin: 0;
width: 100%;
top: 50%;
left: 50%;
transform: translate(-50%,-50%);
text-align: center;
box-sizing: border-box;
}
.feat-big .feat-inner:hover .post-info{
webkit-transform: translateY(0);
-moz-transform: translateY(0);
-ms-transform: translateY(0);
-o-transform: translateY(0);
transform: translateY(0);
}
.feat-big .post-title a{
color:#ffffff;
display: -webkit-box;
-webkit-line-clamp: 2;
-webkit-box-orient: vertical;
overflow: hidden;
transition:color .17s ease
}
.feat-big .post-title a:hover{
color:#003ee6
}
.feat-big .post-meta {
width:100%;
font-size: 12px;
font-weight: 400;
line-height: 18px;
padding: 0 1px;
}
.feat-big .post-meta .post-date {
width: 100%;
text-align: center;
margin: 0;
color: #fff;
}
.feat-big .post-tag {
width: 100%;
color: #fff;
font-size: 12px;
}
.head-text{
float:left;
width:100%;
text-align:center;
margin:50px 0 50px
}
.head-text .widget-title > h3{
display:block;
font-size:27px;
color:#222222;
font-weight:700;
margin:0 0 20px
}
.head-text .widget-content{
font-size:14px;
margin:0
}
.project-head {
margin:0 auto;
}
#serv-tile-wrap{
background:#ffffff;
display:none;
float:left;
width:100%;
margin:0;
padding: 40px 0;
}
#serv-tile-wrap .container{
position:relative;
margin:0 auto
}
#serv-tile{
display: flex;
flex-wrap: wrap;
margin:15px -15px 0
}
#serv-tile .widget{
display: block;
width: 25%;
padding: 15px;
box-sizing: border-box;
border-radius: 12px;
text-align:center;
}
#serv-tile .widget:first-child, #serv-tile .widget:nth-child(2), #serv-tile .widget:nth-child(3) {
}
.serv-tile-box-avatar {
display: inline-block;
position: relative;
width: 60px;
height: 60px;
-webkit-border-radius: 9px;
-khtml-border-radius: 9px;
-moz-border-radius: 9px;
-ms-border-radius: 9px;
-o-border-radius: 9px;
border-radius: 9px;
background-color: #b09991;
-webkit-box-shadow: 0 6px 7px rgb(176 153 145 / 67%);
-khtml-box-shadow: 0 6px 7px rgba(176,153,145,.67);
-moz-box-shadow: 0 6px 7px rgba(176,153,145,.67);
-ms-box-shadow: 0 6px 7px rgba(176,153,145,.67);
-o-box-shadow: 0 6px 7px rgba(176,153,145,.67);
box-shadow: 0 6px 7px rgb(176 153 145 / 67%);
text-align: center;
line-height: 60px;
margin: 0 auto 25px;
}
.serv-tile-box-avatar i {
display: block;
line-height: 60px;
font-size: 30px;
font-weight: 400;
font-style: normal;
margin: 0;
color: #ffffff;
}
.serv-tile-box-avatar img{
width: 60px;
height: 60px;
}
.serv-tile-box-info{
margin-top: 25px;
overflow:hidden
}
.serv-tile-box-title{
font-size: 24px;
color:#121158;
font-weight:700;
margin:0 0 7px
}
.serv-tile-box-meta{
font-size:16px;
line-height: 1.75;
color:#515184
}
.owl-carousel{
display:none;
width:100%;
-webkit-tap-highlight-color:transparent;
position:relative;
z-index:1
}
.owl-nav {
}
.owl-carousel .owl-stage{
position:relative;
-ms-touch-action:pan-Y
}
.owl-carousel .owl-stage:after{
content:".";
display:block;
clear:both;
visibility:hidden;
line-height:0;
height:0
}
.owl-carousel .owl-stage-outer{
position:relative;
overflow:hidden;
-webkit-transform:translate3d(0px,0px,0px)
}
.owl-carousel .owl-controls .owl-nav .owl-prev,.owl-carousel .owl-controls .owl-nav .owl-next,.owl-carousel .owl-controls .owl-dot{
cursor:pointer;
cursor:hand;
-webkit-user-select:none;
-khtml-user-select:none;
-moz-user-select:none;
-ms-user-select:none;
user-select:none
}
.owl-carousel.owl-hidden{
opacity:0
}
.owl-carousel .owl-refresh .owl-item{
display:none
}
.owl-carousel.owl-loading{
opacity:0;
display:block
}
.owl-carousel.owl-loaded{
display:block
}
.owl-carousel .owl-item{
position:relative;
min-height:1px;
float:left;
-webkit-backface-visibility:visible;
-webkit-tap-highlight-color:transparent;
-webkit-touch-callout:none;
-webkit-user-select:none;
-moz-user-select:none;
-ms-user-select:none;
user-select:none
}
.owl-carousel .owl-item img, ul.customer-logos img{
display:block;
}
.owl-carousel.owl-text-select-on .owl-item{
-webkit-user-select:auto;
-moz-user-select:auto;
-ms-user-select:auto;
user-select:auto
}
.owl-carousel .owl-grab{
cursor:move;
cursor:-webkit-grab;
cursor:-o-grab;
cursor:-ms-grab;
cursor:grab
}
.owl-carousel.owl-rtl{
direction:rtl
}
.owl-carousel.owl-rtl .owl-item{
float:right
}
.no-js .owl-carousel{
display:block
}
.owl-carousel .animated{
-webkit-animation-duration:1000ms;
animation-duration:1000ms;
-webkit-animation-fill-mode:both;
animation-fill-mode:both
}
.owl-carousel .owl-animated-in{
z-index:1
}
.owl-carousel .owl-animated-out{
z-index:0
}
.owl-carousel .owl-item li {
padding: 0;
}
.owl-height{
-webkit-transition:height 500ms ease-in-out;
-moz-transition:height 500ms ease-in-out;
-ms-transition:height 500ms ease-in-out;
-o-transition:height 500ms ease-in-out;
transition:height 500ms ease-in-out
}
.owl-carousel .owl-controls .owl-dots {
margin-top: 25px;
text-align: center;
}
.owl-carousel .owl-controls .owl-dot {
display: inline-block;
}
.owl-carousel .owl-controls .owl-dots span {
background: none repeat scroll 0 0 #869791;
border-radius: 20px;
display: block;
height: 12px;
margin: 5px 7px;
opacity: 0.5;
width: 12px;
}
.owl-carousel .owl-controls .owl-dot.active span {
background:none repeat scroll 0 0 #003ee6;
}
.owl-prev,.owl-next{
position:relative;
float:left;
width:24px;
height:24px;
background-color:#fff;
font-family: FontAwesome;
text-rendering: auto;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
font-size:11px;
line-height:23px;
font-weight:900;
color:#bdbdbd;
text-align:center;
cursor:pointer;
border:1px solid rgba(0,0,0,0.08);
box-sizing:border-box;
transition:all .25s ease
}
.owl-prev:before{
content:"\f053"
}
.owl-next:before{
content:"\f054"
}
.owl-prev:hover,.owl-next:hover{
background-color:#003ee6;
color:#fff;
border-color:#003ee6
}
@keyframes fadeInLeft {
from{
opacity:0;
transform:translate3d(-30px,0,0)
}
to{
opacity:1;
transform:none
}
}
@keyframes fadeOutLeft {
from{
opacity:1
}
to{
opacity:0;
transform:translate3d(-30px,0,0)
}
}
@keyframes fadeInRight {
from{
opacity:0;
transform:translate3d(30px,0,0)
}
to{
opacity:1;
transform:none
}
}
.fadeInRight{
animation-name:fadeInRight
}
@keyframes fadeOutRight {
from{
opacity:1
}
to{
opacity:0;
transform:translate3d(30px,0,0)
}
}
.fadeOutRight{
animation-name:fadeOutRight
}
#testimonial-wrap{
display:none;
float:left;
width:100%;
margin:0 0 75px
}
#testimonial-wrap .container{
position:relative;
margin:0 auto
}
#testimonial{
float:left;
width:100%;
margin:0
}
#testimonial .widget{
position: relative;
float: left;
width: 100%;
overflow: hidden;
padding: 15px;
box-sizing: border-box;
}
#testimonial .widget:nth-child(2), #testimonial .widget:nth-child(4){
}
.testi-avatar{
float:left;
width:45px;
height:45px;
overflow:hidden;
border-radius:50%;
margin:0 15px 0 0
}
.testi-avatar img{
display:block;
width:100%;
height:100%;
object-fit:cover;
color:transparent;
margin:0
}
.testi-info{
overflow:hidden
}
.testi-title{
font-size:20px;
color:#443f45;
font-weight:700;
margin:0 0 3px
}
.testi-meta{
font-size:12px;
color:#999999
}
.testi-info-quotes {
margin-bottom: 26px;
}
.testi-snippet{
font-size: 15px;
line-height: 1.5625;
color: #6a6a6a;
padding: 15px 0;
margin:0;
font-style: italic;
font-family: cursive;
letter-spacing: 0.5px;
}
.testi-snippet:before {
content: '\f10d';
display: inline-block;
font-family: FontAwesome;
font-style: normal;
font-weight: 400;
line-height: 1;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
margin-right: 10px;
color:#003ee6;
}
.testi-snippet:after {
content: '\f10e';
display: inline-block;
font-family: FontAwesome;
font-style: normal;
font-weight: 400;
line-height: 1;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
margin-left: 10px;
color:#003ee6;
}
#testimonial .widget:nth-child(2) .testi-snippet, #testimonial .widget:nth-child(4) .testi-snippet {
background-color: #e22310;
border-color: #d41f0d;
}
.main .widget{
position:relative
}
.queryMessage{
overflow:hidden;
color:#222222;
font-size:13px;
font-weight:400;
padding: 10px;
margin: 0 0 25px;
background-color: #eee;
border: 1px solid #ccc;
box-sizing: border-box;
}
.queryMessage .search-query,.queryMessage .search-label{
font-weight:600;
text-transform:uppercase
}
.queryMessage .search-query:before,.queryMessage .search-label:before{
content:"\201c"
}
.queryMessage .search-query:after,.queryMessage .search-label:after{
content:"\201d"
}
.queryMessage a.show-more{
float: right;
display:inline-block;
color:#003ee6;
text-decoration:underline;
margin:0 0 0 10px
}
.queryEmpty{
font-size:13px;
font-weight:400;
padding:10px 0;
margin:0 0 25px;
text-align:center
}
.blog-post{
display:block;
overflow:hidden;
word-wrap:break-word
}
.index-post-wrap {
position: relative;
float: left;
width: 100%;
}
.grid-posts {
display: flex;
flex-wrap: wrap;
margin: 0 -15px;
}
.index-post{
display: block;
width:33.333%;
box-sizing: border-box;
padding: 0 15px;
margin: 0 0 30px;
overflow: visible;
}
.index-post .post-image-wrap{
float: left;
width: 100%;
height: 200px;
margin: 0;
}
.index-post .post-image-wrap .post-image-link{
width:100%;
height:100%;
position:relative;
display:block;
z-index:1;
-webkit-border-radius: 4px 4px 0 0;
-khtml-border-radius: 4px 4px 0 0;
-moz-border-radius: 4px 4px 0 0;
-ms-border-radius: 4px 4px 0 0;
-o-border-radius: 4px 4px 0 0;
border-radius: 4px 4px 0 0;
overflow:hidden
}
.index-post .post-content{
margin:0;
float: left;
width: 100%;
}
.post-image-wrap:hover .post-content{
}
.index-post .post-info{
display: block;
float:left;
width:100%;
padding: 20px;
box-sizing: border-box;
min-height: 200px;
-webkit-border-radius: 0 0 4px 4px;
-khtml-border-radius: 0 0 4px 4px;
-moz-border-radius: 0 0 4px 4px;
-ms-border-radius: 0 0 4px 4px;
-o-border-radius: 0 0 4px 4px;
border-radius: 0 0 4px 4px;
border: 1px solid #e5e5e5;
border-top: 0;
}
.index-post .post-info > h2{
font-size:24px;
color:#222222;
font-weight:600;
line-height:1.5em;
margin:0 0 10px
}
.index-post .post-info > h2 a{
color:#222222;
}
.post-meta{
color:#989898;
font-weight:400;
font-size: 11px;
text-transform:  capitalize;
padding:0;
}
.index-post .post-meta .post-author{
}
.index-post .post-meta .post-author:before {
}
.post-meta .post-date{
display:inline-block;
margin:0 7px 0 0
}
.post-meta .post-author, .post-meta .post-date {
float: left;
display: inline-block;
margin: 0 10px 0 0;
}
.post-meta .post-author:before, .post-meta .post-date:before, .post-meta .post-tag:before {
font-family: FontAwesome;
font-weight: 400;
margin: 0 3px 0 0;
}
.post-meta .post-author:before {
content: '\f007';
}
.post-meta .post-date:before {
content: '\f017';
}
.post-meta .post-tag:before {
content: '\f022';
}
.post-meta a {
color: #989898;
transition: color .17s;
}
.post-snippet {
position: relative;
display: block;
overflow: hidden;
font-size: 14px;
line-height: 1.6em;
font-weight: 400;
margin: 7px 0 0;
color: #5a5a5a;
}
.widget iframe,.widget img{
max-width:100%
}
.item-post h1.post-title{
font-size:27px;
color:#222222;
line-height:1.5em;
font-weight:700;
position:relative;
display:block;
margin:0 0 15px
}
.static_page .item-post h1.post-title{
margin:0
}
.item-post .post-header .post-meta{
font-size:13px
}
.item-post .post-body{
display:block;
font-size:14px;
line-height:1.6em;
padding:35px 0 0
}
.static_page .item-post .post-body{
padding:35px 0
}
.item-post .post-outer{
padding:0
}
.item-post .post-body img{
max-width:100%
}
.post-footer{
position:relative;
float:left;
width:100%;
margin:35px 0 40px
}
.post-labels{
float:left;
height:auto;
position:relative
}
.post-labels a{
float:left;
height:26px;
background-color:#f9f9f9;
color:#aaa;
font-size:11px;
font-weight:600;
text-transform:uppercase;
line-height:26px;
padding:0 10px;
margin:0 10px 0 0;
border-radius:3px;
transition:all .17s ease
}
.post-labels a:hover{
background-color:#003ee6;
color:#fff
}
.post-share{
position:relative;
float:right;
overflow:hidden;
line-height:0
}
ul.share-links{
position:relative
}
.share-links li{
float:left;
box-sizing:border-box;
margin:0 0 0 5px
}
.share-links li.whatsapp-mobile{
display:none
}
.is-mobile li.whatsapp-desktop{
display:none
}
.is-mobile li.whatsapp-mobile{
display:inline-block
}
.share-links li a{
float:left;
display:inline-block;
width:35px;
height:26px;
color:#fff;
font-size:12px;
text-align:center;
line-height:26px;
border-radius:3px;
transition:all .17s ease
}
.share-links li a:before{
font-size:14px
}
.share-links li a:hover{
background-color:#003ee6;
color:#fff
}
#related-wrap{
margin: 20px 0 30px;
overflow: hidden;
float: left;
width: 100%;
}
#related-wrap .title-wrap {
position: relative;
float: left;
width: 100%;
height: 28px;
background-color: #003ee6;
display: block;
margin: 0 0 20px;
}
#related-wrap .title-wrap > h3 {
display: block;
font-size: 12px;
color: #ffffff;
font-weight: 600;
line-height: 28px;
text-transform: uppercase;
text-align: center;
padding: 0 15px;
margin: 0;
}
#related-wrap .related-tag{
display:none
}
.related-ready{
float:left;
width:100%
}
.related-ready .loader{
height:178px
}
ul.related-posts{
position:relative;
overflow:hidden;
margin:0 -10px;
padding:0
}
.related-posts .related-item{
width:33.33333333%;
position:relative;
overflow:hidden;
float:left;
display:block;
box-sizing:border-box;
padding:0 10px;
margin:0
}
.related-posts .post-image-link{
width:100%;
height:130px;
position:relative;
overflow:hidden;
display:block
}
.related-posts .post-title{
font-size:13px;
font-weight:600;
line-height:1.5em;
display:block;
margin:7px 0 5px
}
.related-posts .post-title a{
color:#222222;
transition:color .17s
}
.related-posts .related-item:hover .post-title a{
color:#003ee6
}
.related-posts .post-meta{
font-size:12px
}
.post-nav{
position:relative;
overflow:hidden;
display:block;
margin:0
}
.post-nav .nav-link{
display:block;
height:30px;
background-color:#f9f9f9;
font-size:11px;
color:#aaa;
line-height:30px;
text-transform:uppercase;
font-weight:600;
padding:0 25px;
border-radius:3px;
transition:all .17s ease
}
.post-nav .nav-link:hover{
background-color:#003ee6;
color:#fff
}
.post-nav span.nav-link:hover{
background-color:#f8f8f8;
color:#999
}
.next-post-link{
float:left
}
.prev-post-link{
float:right
}
.next-post-link:after{
content:"\f104";
float:left;
font-family:FontAwesome;
font-size:13px;
font-weight:400;
text-transform:none;
margin:0 3px 0 0
}
.prev-post-link:before{
content:"\f105";
float:right;
font-family:FontAwesome;
font-size:13px;
font-weight:400;
text-transform:none;
margin:0 0 0 3px
}
#blog-pager{
float:left;
width:100%;
text-align:center;
margin:16px 0 0
}
.blog-pager a{
display:inline-block;
height:32px;
background-color:#003ee6;
color:#fff;
font-size:14px;
font-weight:400;
line-height:32px;
text-transform:capitalize;
text-align:center;
padding:0 20px;
border-radius:3px;
transition:all .17s ease
}
.blog-pager a:hover{
background-color:#222222
}
.blog-post-comments{
display:none;
overflow:hidden;
background-color:#f8f8f8;
padding:10px 30px;
margin:0 0 40px
}
#comments{
margin:0
}
#gpluscomments{
float:left!important;
width:100%!important;
margin:0 0 25px!important
}
#gpluscomments iframe{
float:left!important;
width:100%
}
.comments{
display:block;
clear:both;
margin:0
}
.comments > h3{
float:left;
width:100%;
font-size:12px;
font-style:italic;
font-weight:400;
margin:0 0 20px
}
.no-comments > h3{
margin:10px 0 15px
}
.comments .comments-content{
float:left;
width:100%;
margin:0
}
#comments h4#comment-post-message{
display:none
}
.comments .comment-block{
position:relative;
background-color:#fdfdfd;
padding:15px;
margin:0 0 0 55px;
border:1px solid #f2f2f2
}
.comments .comment-block:before{
content:'';
position:absolute;
top:8px;
left:-5px;
width:0;
height:0;
border:5px solid #f2f2f2;
border-top-color:transparent;
border-right-color:transparent;
transform:rotate(45deg)
}
.comments .comment-content{
font-size:13px;
line-height:1.6em;
margin:10px 0
}
.comment-thread .comment{
position:relative;
padding:10px 0 0;
margin:10px 0 0;
list-style:none
}
.comment-thread ol{
padding:0;
margin:0 0 20px
}
.comment-thread ol > li:first-child{
padding:0;
margin:0
}
.comment-thread .avatar-image-container{
position:absolute;
top:10px;
left:0;
width:40px;
height:40px;
overflow:hidden
}
.comment-thread ol > li:first-child > .avatar-image-container{
top:0
}
.avatar-image-container img{
width:100%;
height:100%
}
.comments .comment-header .user{
font-size:14px;
color:#222222;
display:inline-block;
font-style:normal;
font-weight:700;
margin:0
}
.comments .comment-header .user a{
color:#222222;
transition:color .17s ease
}
.comments .comment-header .user a:hover{
color:#003ee6
}
.comments .comment-header .icon.user{
display:none
}
.comments .comment-header .icon.blog-author{
display:inline-block;
font-size:12px;
color:#003ee6;
font-weight:400;
vertical-align:top;
margin:0 0 0 5px
}
.comments .comment-header .icon.blog-author:before{
content:'\f058';
font-family:FontAwesome
}
.comments .comment-header .datetime{
float:right;
display:inline-block;
margin:0
}
.comment-header .datetime a{
font-size:12px;
color:#aaa;
font-style:italic
}
.comments .comment-actions{
display:block;
margin:0
}
.comments .comment-actions a{
color:#aaa;
font-size:11px;
font-style:italic;
margin:0 15px 0 0;
transition:color .17s ease
}
.comments .comment-actions a:hover{
color:#003ee6;
text-decoration:underline
}
.loadmore.loaded a{
display:inline-block;
border-bottom:1px solid rgba(0,0,0,0.1);
text-decoration:none;
margin-top:15px
}
.comments .continue{
display:none!important
}
.comments .comment-replies{
padding:0 0 0 55px
}
.thread-expanded .thread-count a,.loadmore{
display:none
}
.comments .footer,.comments .comment-footer{
font-size:13px
}
.comment-form{
margin:0 -7.5px
}
.comment-form > p{
font-size:13px;
padding:10px 0 5px
}
.comment-form > p > a{
color:#222222
}
.comment-form > p > a:hover{
text-decoration:underline
}
.post-body h1,.post-body h2,.post-body h3,.post-body h4,.post-body h5,.post-body h6{
color:#222222;
font-weight:700;
margin:0 0 15px
}
.post-body h1,.post-body h2{
font-size:24px
}
.post-body h3{
font-size:21px
}
.post-body h4{
font-size:18px
}
.post-body h5{
font-size:16px
}
.post-body h6{
font-size:13px
}
blockquote{
background-color:#f8f8f8;
font-style:italic;
padding:10px 15px;
margin:0;
border-left:3px solid #003ee6
}
blockquote:before,blockquote:after{
display:inline-block;
font-family:FontAwesome;
font-weight:400;
font-style:normal;
line-height:1
}
blockquote:before{
content:'\f10d';
margin:0 10px 0 0
}
blockquote:after{
content:'\f10e';
margin:0 0 0 10px
}
.widget .post-body ul,.widget .post-body ol{
line-height:1.5;
font-weight:400
}
.widget .post-body li{
margin:5px 0;
padding:0;
line-height:1.5
}
.post-body ul{
padding:0 0 0 20px
}
.post-body ul li:before{
content:"\f105";
font-family:FontAwesome;
font-size:13px;
font-weight:900;
margin:0 5px 0 0
}
.post-body u{
text-decoration:underline
}
.post-body a{
transition:color .17s ease
}
.post-body strike{
text-decoration:line-through
}
.contact-form-widget form{
font-weight:400
}
.contact-form-name,.contact-form-email{
float:left;
width:calc(50% - 5px);
height:34px;
background-color:rgba(255,255,255,0.01);
font-family:inherit;
font-size:13px;
color:#fff;
line-height:34px;
box-sizing:border-box;
padding:0 10px;
margin:0 0 10px;
border:1px solid rgba(255,255,255,0.05);
border-radius:3px
}
.contact-form-email{
float:right
}
.contact-form-email-message{
float:left;
width:100%;
background-color:rgba(255,255,255,0.01);
font-family:inherit;
font-size:13px;
color:#fff;
box-sizing:border-box;
padding:10px;
margin:0 0 10px;
border:1px solid rgba(255,255,255,0.05);
border-radius:3px
}
.contact-form-button-submit{
float:left;
width:100%;
height:34px;
background-color:#003ee6;
font-family:inherit;
font-size:12px;
color:#fff;
line-height:34px;
font-weight:600;
text-transform:uppercase;
cursor:pointer;
box-sizing:border-box;
padding:0 10px;
margin:0;
border:0;
border-radius:3px;
transition:background .17s ease
}
.contact-form-button-submit:hover{
background-color:rgba(0,0,0,0.5)
}
.contact-form-error-message-with-border,.contact-form-success-message-with-border{
float:left;
width:100%;
background-color:#e74c3c;
color:#f2f2f2;
font-size:11px;
text-align:center;
line-height:11px;
padding:4px 0;
margin:10px 0;
border-radius:3px
}
.contact-form-success-message-with-border{
background-color:#3498db
}
.contact-form-cross{
margin:0 0 0 3px
}
.contact-form-error-message,.contact-form-success-message{
margin:0
}
.map-me {
margin:0 0 -5px;
display: block;
max-width: 100%;
width: 100%;
box-sizing: border-box;
}
.map-me #map iframe {
width: 100%;
height: 378px;
}
#footer-wrapper{
position:relative;
overflow:hidden;
background:#20222d;
background-size: cover;
background-position: top;
margin:0
}
#contact-area{
display:none;
overflow:hidden;
padding:60px 0
}
#contact-area > .container{
margin:0 auto
}
#contact-left{
float:left;
width:calc(45% - 40px)
}
#contact-right{
float:right;
width:55%
}
#contact-area .widget-title > h3{
display:block;
color:#f2f2f2;
font-size:20px;
font-weight:700;
margin:0 0 15px
}
.contact-col .Text .widget-content{
font-size:14px;
color:#aaa;
line-height:24px;
margin:0 0 20px
}
.contact-col .LinkList .widget-title{
display:none
}
.contact-item{
display:block;
overflow:hidden;
font-size:14px;
line-height:30px;
margin:15px 0 0
}
.contact-item.item-0{
margin:0
}
.contact-icon{
float:left;
width:30px;
height:30px;
background-color:#003ee6;
font-size:18px;
color:#fff;
line-height:30px;
text-align:center;
margin:0 10px 0 0;
border-radius:3px
}
.item-desc{
color:#aaa
}
#footer-copyright{
background:#242634;
display:block;
overflow:hidden;
width:100%;
color:#aaa;
padding:20px 0
}
#footer-copyright > .container{
margin:0 auto
}
#social-footer{
float:right
}
#social-footer .widget{
line-height:30px
}
.social-footer ul{
text-align:center;
overflow:hidden;
display:block
}
.social-footer ul li{
display:inline-block;
margin:0 0 0 14px
}
.social-footer ul li a{
font-size:16px;
color:#aaa;
display:block;
padding:0 3px;
transition:color .17s ease
}
.social-footer ul li:last-child a{
padding-right:0
}
.social-footer ul li a:hover{
color:#003ee6
}
#footer-copyright .copyright-area{
float:left;
font-size:12px;
line-height:30px;
}
#footer-copyright .copyright-area a{
color:#003ee6
}
#footer-copyright .copyright-area a:hover{
text-decoration:underline
}
.hidden-widgets{
display:none;
visibility:hidden
}
.back-top{
display:none;
z-index:1010;
width:32px;
height:32px;
position:fixed;
bottom:25px;
right:25px;
background-color:#003ee6;
cursor:pointer;
overflow:hidden;
font-size:19px;
color:#fff;
text-align:center;
line-height:32px;
border-radius:3px
}
.back-top:after{
content:'\f106';
position:relative;
font-family:FontAwesome;
font-weight:400
}
.error404 #main-wrapper{
width:100%!important;
margin:0!important
}
.error404 #sidebar-wrapper{
display:none
}
.errorWrap{
color:#222222;
text-align:center;
padding:60px 0 100px
}
.errorWrap h3{
font-size:130px;
line-height:1;
margin:0 0 30px
}
.errorWrap h4{
font-size:25px;
margin:0 0 20px
}
.errorWrap p{
margin:0 0 10px
}
.errorWrap a{
display:block;
color:#003ee6;
padding:10px 0 0
}
.errorWrap a i{
font-size:14px
}
.errorWrap a:hover{
text-decoration:underline
}
@media (max-width: 1040px) {
.row{
width:100%
}
#header-wrap, .home #header-wrap, .item #header-wrap, #intro-author-wrap .container, #content-wrapper, #serv-tile-wrap .container, #contact-area > .container, #footer-copyright > .container, #top-bar .container, .counter-box .container, .featured-posts, #testimonial-wrap .container, #brand-services-wrap .container, #editorial-wrap .container, .project-head{
box-sizing:border-box;
padding:0 20px
}
#intro-services-wrap{
box-sizing:border-box;
padding:80px 20px
}
.counter-box {
padding: 40px 0;
}
.counter-box-wrap,.counter-title {
border-radius:0;
}
#serv-tile .widget {
width: 50%;
}
#serv-tile .widget:nth-child(4), #serv-tile .widget:nth-child(5) {
margin-bottom: 20px;
}
}
@media (max-width: 980px) {
#main-menu, #parallax-menu, .home #parallax-menu{
display:none
}
.mobile-menu-wrap,.scrolling-mobile-menu-wrap,.mobile-menu-toggle, .scrolling-mobile-menu-toggle{
display:block
}
.counter-box-item {
width: 50%;
}
.faq-toggle {
background-attachment: inherit;
}
#content-wrapper > .container{
margin:0
}
.item #main-wrapper,#sidebar-wrapper{
width:100%;
padding:0
}
#brand-services-wrap li {
width: calc(100% / 3);
margin-bottom: 30px;
}
.counter-box-info, .counter-box-image {
width: 100%;
padding: 0;
}
.counter-box-image {
margin-top:20px;
}
.counter-image-wrap, .counter-image-wrap .widget, .counter-image-wrap .widget-content, .counter-image-wrap .counter-content {
min-height: 307px;
max-height: 307px;
}
.feat-big li {
width: 50%;
}
.index-post {
width: 50%;
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-avatar {
height: 310px;
}
#author-email-pic {
display: block;
position: absolute;
right: 0;
z-index: 1;
bottom: 0;
opacity: 0.7;
}
.top-bar-social {
width: 100%;
z-index: 9;
padding: 25px 0;
}
}
@media (max-width: 780px) {
#main-intro{
height:380px
}
.author-intro-widgets .author-list, .author-intro-widgets .author-list .widget {
width: 100%;
}
#brand-services-wrap {
padding: 20px 0;
}
#intro-author-heading, .author-intro-widgets {
width: 100%;
}
#intro-author-photo{
display:none;
}
.post-snippet {
font-size: 13px;
margin: 0;
}
.index-post .post-info > h2 {
font-size: 22px;
}
#serv-tile .widget{
width: calc(100% / 2);
margin-bottom: 10px;
}
#serv-tile .widget:first-child, #serv-tile .widget:nth-child(2), #serv-tile .widget:nth-child(3), #serv-tile .widget:nth-child(4) {
margin-bottom:10px;
}
.author-intro-widgets {
margin: 0;
}
#social-footer{
width:100%;
margin:0 0 10px
}
.social-footer ul li{
margin:0 7px
}
#footer-copyright .copyright-area{
width:100%;
text-align:center;
overflow:hidden;
}
.top-bar-nav {
width: 100%;
text-align: center;
clear: both;
}
.top-bar-nav ul li {
float: none;
display: inline-block;
}
.errorWrap{
padding:60px 0 80px
}
}
@media (max-width:767px) {
.intro-snippet {
font-size: 13px;
}
.intro-title {
font-size: 30px;
margin: 0 0 10px;
}
.intro-action a {
margin: 10px 0 0;
}
.slide-in {
display:none;
}
}
@media (max-width: 680px) {
.intro-content{
width:100%;
box-sizing:border-box;
padding:0 40px
}
.intro-content {
top: 50%;
transform: translate(-50%,-50%);
}
#intro-services .widget{
width:100%;
margin:50px 0 0
}
#intro-services .widget:first-child{
margin:0
}
#contact-left,#contact-right{
width:100%
}
#contact-left .widget:last-child{
margin:0 0 35px
}
.post-labels{
width:100%;
margin:0 0 25px
}
.post-labels a{
margin:0 10px 5px 0
}
.post-share{
float:left
}
.share-links li{
margin:5px 5px 0 0
}
}
@media (max-width: 540px) {
#main-intro{
height:auto
}
.top-bar-social {
float: none;
text-align: center;
}
.top-bar-social ul > li {
float: none;
}
.author-intro-widgets .author-list {
width: 100%;
}
#brand-services-wrap {
padding: 10px 0;
}
.index-post {
width: 100%;
}
.feat-big li {
width: 100%;
padding: 0;
}
.editorial-authors .widget {
width: 100%;
margin-bottom: 15px;
padding: 0;
}
.editorial-authors .widget:last-child {
margin: 0;
}
.editorial-authors .widget .editorial-avatar-wrap .editorial-avatar img {
object-position: top;
}
.intro-title{
font-size:27px
}
#intro-author-wrap{
padding:0
}
#content-wrapper{
margin:50px 0
}
.item #content-wrapper{
margin:40px 0
}
.serv-tile-box-info {
text-align: center;
}
.email-folower .email-letter-text, .email-folower .follow-by-email-inner {
float: none;
width: 100%;
padding: 0;
}
ul.related-posts{
margin:0
}
.related-posts .related-item{
width:100%;
padding:0;
margin:20px 0 0
}
.related-posts .item-0{
margin:0
}
.related-posts .post-image-link{
width:75px;
height:60px;
float:left;
margin:0 12px 0 0
}
.related-posts .post-title{
font-size:15px;
overflow:hidden;
margin:0 0 5px
}
#brand-services-wrap li {
width: calc(100% / 2);
}
}
@media (max-width: 480px) {
.counter-box-wrap .widget {
width: 100%;
padding: 15px 10px;
}
}
@media (max-width: 440px) {
#serv-tile .widget {
width: 100%;
margin-bottom: 10px;
}
.counter-box-item {
width: 100%;
}
.item-post h1.post-title{
font-size:23px
}
.head-text .widget-content{
line-height:24px
}
}
@media (max-width: 360px) {
.intro-title,.author-title,.head-text .widget-title > h3{
font-size:25px
}
.index-post{
width:100%
}
.errorWrap h3{
font-size:120px
}
.errorWrap h4{
font-weight:600
}
}

--></style>
<style>
/*-------Typography and ShortCodes-------*/
.firstcharacter{float:left;color:#27ae60;font-size:75px;line-height:60px;padding-top:4px;padding-right:8px;padding-left:3px}.post-body h1,.post-body h2,.post-body h3,.post-body h4,.post-body h5,.post-body h6{margin-bottom:15px;color:#2c3e50}blockquote{font-style:italic;color:#888;border-left:5px solid #27ae60;margin-left:0;padding:10px 15px}blockquote:before{content:'\f10d';display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;margin-right:10px;color:#888}blockquote:after{content:'\f10e';display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;margin-left:10px;color:#888}.button{background-color:#2c3e50;float:left;padding:5px 12px;margin:5px;color:#fff;text-align:center;border:0;cursor:pointer;border-radius:3px;display:block;text-decoration:none;font-weight:400;transition:all .3s ease-out !important;-webkit-transition:all .3s ease-out !important}a.button{color:#fff}.button:hover{background-color:#27ae60;color:#fff}.button.small{font-size:12px;padding:5px 12px}.button.medium{font-size:16px;padding:6px 15px}.button.large{font-size:18px;padding:8px 18px}.small-button{width:100%;overflow:hidden;clear:both}.medium-button{width:100%;overflow:hidden;clear:both}.large-button{width:100%;overflow:hidden;clear:both}.demo:before{content:"\f06e";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.download:before{content:"\f019";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.buy:before{content:"\f09d";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.visit:before{content:"\f14c";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.widget .post-body ul,.widget .post-body ol{line-height:1.5;font-weight:400}.widget .post-body li{margin:5px 0;padding:0;line-height:1.5}.post-body ul li:before{content:"\f105";margin-right:5px;font-family:fontawesome}pre{font-family:Monaco, "Andale Mono", "Courier New", Courier, monospace;background-color:#2c3e50;background-image:-webkit-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:-moz-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:-ms-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:-o-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);-webkit-background-size:100% 50px;-moz-background-size:100% 50px;background-size:100% 50px;line-height:25px;color:#f1f1f1;position:relative;padding:0 7px;margin:15px 0 10px;overflow:hidden;word-wrap:normal;white-space:pre;position:relative}pre:before{content:'Code';display:block;background:#F7F7F7;margin-left:-7px;margin-right:-7px;color:#2c3e50;padding-left:7px;font-weight:400;font-size:14px}pre code,pre .line-number{display:block}pre .line-number a{color:#27ae60;opacity:0.6}pre .line-number span{display:block;float:left;clear:both;width:20px;text-align:center;margin-left:-7px;margin-right:7px}pre .line-number span:nth-child(odd){background-color:rgba(0, 0, 0, 0.11)}pre .line-number span:nth-child(even){background-color:rgba(255, 255, 255, 0.05)}pre .cl{display:block;clear:both}#contact{background-color:#fff;margin:30px 0 !important}#contact .contact-form-widget{max-width:100% !important}#contact .contact-form-name,#contact .contact-form-email,#contact .contact-form-email-message{background-color:#FFF;border:1px solid #eee;border-radius:3px;padding:10px;margin-bottom:10px !important;max-width:100% !important}#contact .contact-form-name{width:47.7%;height:50px}#contact .contact-form-email{width:49.7%;height:50px}#contact .contact-form-email-message{height:150px}#contact .contact-form-button-submit{max-width:100%;width:100%;z-index:0;margin:4px 0 0;padding:10px !important;text-align:center;cursor:pointer;background:#27ae60;border:0;height:auto;-webkit-border-radius:2px;-moz-border-radius:2px;-ms-border-radius:2px;-o-border-radius:2px;border-radius:2px;text-transform:uppercase;-webkit-transition:all .2s ease-out;-moz-transition:all .2s ease-out;-o-transition:all .2s ease-out;-ms-transition:all .2s ease-out;transition:all .2s ease-out;color:#FFF}#contact .contact-form-button-submit:hover{background:#2c3e50}#contact .contact-form-email:focus,#contact .contact-form-name:focus,#contact .contact-form-email-message:focus{box-shadow:none !important}.alert-message{position:relative;display:block;background-color:#FAFAFA;padding:20px;margin:20px 0;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;color:#2f3239;border:1px solid}.alert-message p{margin:0 !important;padding:0;line-height:22px;font-size:13px;color:#2f3239}.alert-message span{font-size:14px !important}.alert-message i{font-size:16px;line-height:20px}.alert-message.success{background-color:#f1f9f7;border-color:#e0f1e9;color:#1d9d74}.alert-message.success a,.alert-message.success span{color:#1d9d74}.alert-message.alert{background-color:#DAEFFF;border-color:#8ED2FF;color:#378FFF}.alert-message.alert a,.alert-message.alert span{color:#378FFF}.alert-message.warning{background-color:#fcf8e3;border-color:#faebcc;color:#8a6d3b}.alert-message.warning a,.alert-message.warning span{color:#8a6d3b}.alert-message.error{background-color:#FFD7D2;border-color:#FF9494;color:#F55D5D}.alert-message.error a,.alert-message.error span{color:#F55D5D}.fa-check-circle:before{content:"\f058"}.fa-info-circle:before{content:"\f05a"}.fa-exclamation-triangle:before{content:"\f071"}.fa-exclamation-circle:before{content:"\f06a"}.post-table table{border-collapse:collapse;width:100%}.post-table th{background-color:#eee;font-weight:bold}.post-table th,.post-table td{border:0.125em solid #333;line-height:1.5;padding:0.75em;text-align:left}@media (max-width: 30em){.post-table thead tr{position:absolute;top:-9999em;left:-9999em}.post-table tr{border:0.125em solid #333;border-bottom:0}.post-table tr + tr{margin-top:1.5em}.post-table tr,.post-table td{display:block}.post-table td{border:none;border-bottom:0.125em solid #333;padding-left:50%}.post-table td:before{content:attr(data-label);display:inline-block;font-weight:bold;line-height:1.5;margin-left:-100%;width:100%}}@media (max-width: 20em){.post-table td{padding-left:0.75em}.post-table td:before{display:block;margin-bottom:0.75em;margin-left:0}}
.FollowByEmail {
    clear: both;
}
.widget .post-body ol {
    padding: 0 0 0 15px;
}
.post-body ul li {
    list-style: none;
}
</style>
<style>
 
/*!
 * animate.css -http://daneden.me/animate
 * Version - 3.5.2
 * Licensed under the MIT license - http://opensource.org/licenses/MIT
 *
 * Copyright (c) 2017 Daniel Eden
 */

.animated{animation-duration:1s;animation-fill-mode:both}.animated.infinite{animation-iteration-count:infinite}.animated.hinge{animation-duration:2s}.animated.bounceIn,.animated.bounceOut,.animated.flipOutX,.animated.flipOutY{animation-duration:.75s}@keyframes bounce{0%,20%,53%,80%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1);transform:translateZ(0)}40%,43%{animation-timing-function:cubic-bezier(.755,.05,.855,.06);transform:translate3d(0,-30px,0)}70%{animation-timing-function:cubic-bezier(.755,.05,.855,.06);transform:translate3d(0,-15px,0)}90%{transform:translate3d(0,-4px,0)}}.bounce{animation-name:bounce;transform-origin:center bottom}@keyframes flash{0%,50%,to{opacity:1}25%,75%{opacity:0}}.flash{animation-name:flash}@keyframes pulse{0%{transform:scaleX(1)}50%{transform:scale3d(1.05,1.05,1.05)}to{transform:scaleX(1)}}.pulse{animation-name:pulse}@keyframes rubberBand{0%{transform:scaleX(1)}30%{transform:scale3d(1.25,.75,1)}40%{transform:scale3d(.75,1.25,1)}50%{transform:scale3d(1.15,.85,1)}65%{transform:scale3d(.95,1.05,1)}75%{transform:scale3d(1.05,.95,1)}to{transform:scaleX(1)}}.rubberBand{animation-name:rubberBand}@keyframes shake{0%,to{transform:translateZ(0)}10%,30%,50%,70%,90%{transform:translate3d(-10px,0,0)}20%,40%,60%,80%{transform:translate3d(10px,0,0)}}.shake{animation-name:shake}@keyframes headShake{0%{transform:translateX(0)}6.5%{transform:translateX(-6px) rotateY(-9deg)}18.5%{transform:translateX(5px) rotateY(7deg)}31.5%{transform:translateX(-3px) rotateY(-5deg)}43.5%{transform:translateX(2px) rotateY(3deg)}50%{transform:translateX(0)}}.headShake{animation-timing-function:ease-in-out;animation-name:headShake}@keyframes swing{20%{transform:rotate(15deg)}40%{transform:rotate(-10deg)}60%{transform:rotate(5deg)}80%{transform:rotate(-5deg)}to{transform:rotate(0deg)}}.swing{transform-origin:top center;animation-name:swing}@keyframes tada{0%{transform:scaleX(1)}10%,20%{transform:scale3d(.9,.9,.9) rotate(-3deg)}30%,50%,70%,90%{transform:scale3d(1.1,1.1,1.1) rotate(3deg)}40%,60%,80%{transform:scale3d(1.1,1.1,1.1) rotate(-3deg)}to{transform:scaleX(1)}}.tada{animation-name:tada}@keyframes wobble{0%{transform:none}15%{transform:translate3d(-25%,0,0) rotate(-5deg)}30%{transform:translate3d(20%,0,0) rotate(3deg)}45%{transform:translate3d(-15%,0,0) rotate(-3deg)}60%{transform:translate3d(10%,0,0) rotate(2deg)}75%{transform:translate3d(-5%,0,0) rotate(-1deg)}to{transform:none}}.wobble{animation-name:wobble}@keyframes jello{0%,11.1%,to{transform:none}22.2%{transform:skewX(-12.5deg) skewY(-12.5deg)}33.3%{transform:skewX(6.25deg) skewY(6.25deg)}44.4%{transform:skewX(-3.125deg) skewY(-3.125deg)}55.5%{transform:skewX(1.5625deg) skewY(1.5625deg)}66.6%{transform:skewX(-.78125deg) skewY(-.78125deg)}77.7%{transform:skewX(.390625deg) skewY(.390625deg)}88.8%{transform:skewX(-.1953125deg) skewY(-.1953125deg)}}.jello{animation-name:jello;transform-origin:center}@keyframes bounceIn{0%,20%,40%,60%,80%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:scale3d(.3,.3,.3)}20%{transform:scale3d(1.1,1.1,1.1)}40%{transform:scale3d(.9,.9,.9)}60%{opacity:1;transform:scale3d(1.03,1.03,1.03)}80%{transform:scale3d(.97,.97,.97)}to{opacity:1;transform:scaleX(1)}}.bounceIn{animation-name:bounceIn}@keyframes bounceInDown{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(0,-3000px,0)}60%{opacity:1;transform:translate3d(0,25px,0)}75%{transform:translate3d(0,-10px,0)}90%{transform:translate3d(0,5px,0)}to{transform:none}}.bounceInDown{animation-name:bounceInDown}@keyframes bounceInLeft{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(-3000px,0,0)}60%{opacity:1;transform:translate3d(25px,0,0)}75%{transform:translate3d(-10px,0,0)}90%{transform:translate3d(5px,0,0)}to{transform:none}}.bounceInLeft{animation-name:bounceInLeft}@keyframes bounceInRight{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(3000px,0,0)}60%{opacity:1;transform:translate3d(-25px,0,0)}75%{transform:translate3d(10px,0,0)}90%{transform:translate3d(-5px,0,0)}to{transform:none}}.bounceInRight{animation-name:bounceInRight}@keyframes bounceInUp{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(0,3000px,0)}60%{opacity:1;transform:translate3d(0,-20px,0)}75%{transform:translate3d(0,10px,0)}90%{transform:translate3d(0,-5px,0)}to{transform:translateZ(0)}}.bounceInUp{animation-name:bounceInUp}@keyframes bounceOut{20%{transform:scale3d(.9,.9,.9)}50%,55%{opacity:1;transform:scale3d(1.1,1.1,1.1)}to{opacity:0;transform:scale3d(.3,.3,.3)}}.bounceOut{animation-name:bounceOut}@keyframes bounceOutDown{20%{transform:translate3d(0,10px,0)}40%,45%{opacity:1;transform:translate3d(0,-20px,0)}to{opacity:0;transform:translate3d(0,2000px,0)}}.bounceOutDown{animation-name:bounceOutDown}@keyframes bounceOutLeft{20%{opacity:1;transform:translate3d(20px,0,0)}to{opacity:0;transform:translate3d(-2000px,0,0)}}.bounceOutLeft{animation-name:bounceOutLeft}@keyframes bounceOutRight{20%{opacity:1;transform:translate3d(-20px,0,0)}to{opacity:0;transform:translate3d(2000px,0,0)}}.bounceOutRight{animation-name:bounceOutRight}@keyframes bounceOutUp{20%{transform:translate3d(0,-10px,0)}40%,45%{opacity:1;transform:translate3d(0,20px,0)}to{opacity:0;transform:translate3d(0,-2000px,0)}}.bounceOutUp{animation-name:bounceOutUp}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fadeIn{animation-name:fadeIn}@keyframes fadeInDown{0%{opacity:0;transform:translate3d(0,-100%,0)}to{opacity:1;transform:none}}.fadeInDown{animation-name:fadeInDown}@keyframes fadeInDownBig{0%{opacity:0;transform:translate3d(0,-2000px,0)}to{opacity:1;transform:none}}.fadeInDownBig{animation-name:fadeInDownBig}@keyframes fadeInLeft{0%{opacity:0;transform:translate3d(-100%,0,0)}to{opacity:1;transform:none}}.fadeInLeft{animation-name:fadeInLeft}@keyframes fadeInLeftBig{0%{opacity:0;transform:translate3d(-2000px,0,0)}to{opacity:1;transform:none}}.fadeInLeftBig{animation-name:fadeInLeftBig}@keyframes fadeInRight{0%{opacity:0;transform:translate3d(100%,0,0)}to{opacity:1;transform:none}}.fadeInRight{animation-name:fadeInRight}@keyframes fadeInRightBig{0%{opacity:0;transform:translate3d(2000px,0,0)}to{opacity:1;transform:none}}.fadeInRightBig{animation-name:fadeInRightBig}@keyframes fadeInUp{0%{opacity:0;transform:translate3d(0,100%,0)}to{opacity:1;transform:none}}.fadeInUp{animation-name:fadeInUp}@keyframes fadeInUpBig{0%{opacity:0;transform:translate3d(0,2000px,0)}to{opacity:1;transform:none}}.fadeInUpBig{animation-name:fadeInUpBig}@keyframes fadeOut{0%{opacity:1}to{opacity:0}}.fadeOut{animation-name:fadeOut}@keyframes fadeOutDown{0%{opacity:1}to{opacity:0;transform:translate3d(0,100%,0)}}.fadeOutDown{animation-name:fadeOutDown}@keyframes fadeOutDownBig{0%{opacity:1}to{opacity:0;transform:translate3d(0,2000px,0)}}.fadeOutDownBig{animation-name:fadeOutDownBig}@keyframes fadeOutLeft{0%{opacity:1}to{opacity:0;transform:translate3d(-100%,0,0)}}.fadeOutLeft{animation-name:fadeOutLeft}@keyframes fadeOutLeftBig{0%{opacity:1}to{opacity:0;transform:translate3d(-2000px,0,0)}}.fadeOutLeftBig{animation-name:fadeOutLeftBig}@keyframes fadeOutRight{0%{opacity:1}to{opacity:0;transform:translate3d(100%,0,0)}}.fadeOutRight{animation-name:fadeOutRight}@keyframes fadeOutRightBig{0%{opacity:1}to{opacity:0;transform:translate3d(2000px,0,0)}}.fadeOutRightBig{animation-name:fadeOutRightBig}@keyframes fadeOutUp{0%{opacity:1}to{opacity:0;transform:translate3d(0,-100%,0)}}.fadeOutUp{animation-name:fadeOutUp}@keyframes fadeOutUpBig{0%{opacity:1}to{opacity:0;transform:translate3d(0,-2000px,0)}}.fadeOutUpBig{animation-name:fadeOutUpBig}@keyframes flip{0%{transform:perspective(400px) rotateY(-1turn);animation-timing-function:ease-out}40%{transform:perspective(400px) translateZ(150px) rotateY(-190deg);animation-timing-function:ease-out}50%{transform:perspective(400px) translateZ(150px) rotateY(-170deg);animation-timing-function:ease-in}80%{transform:perspective(400px) scale3d(.95,.95,.95);animation-timing-function:ease-in}to{transform:perspective(400px);animation-timing-function:ease-in}}.animated.flip{-webkit-backface-visibility:visible;backface-visibility:visible;animation-name:flip}@keyframes flipInX{0%{transform:perspective(400px) rotateX(90deg);animation-timing-function:ease-in;opacity:0}40%{transform:perspective(400px) rotateX(-20deg);animation-timing-function:ease-in}60%{transform:perspective(400px) rotateX(10deg);opacity:1}80%{transform:perspective(400px) rotateX(-5deg)}to{transform:perspective(400px)}}.flipInX{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipInX}@keyframes flipInY{0%{transform:perspective(400px) rotateY(90deg);animation-timing-function:ease-in;opacity:0}40%{transform:perspective(400px) rotateY(-20deg);animation-timing-function:ease-in}60%{transform:perspective(400px) rotateY(10deg);opacity:1}80%{transform:perspective(400px) rotateY(-5deg)}to{transform:perspective(400px)}}.flipInY{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipInY}@keyframes flipOutX{0%{transform:perspective(400px)}30%{transform:perspective(400px) rotateX(-20deg);opacity:1}to{transform:perspective(400px) rotateX(90deg);opacity:0}}.flipOutX{animation-name:flipOutX;-webkit-backface-visibility:visible!important;backface-visibility:visible!important}@keyframes flipOutY{0%{transform:perspective(400px)}30%{transform:perspective(400px) rotateY(-15deg);opacity:1}to{transform:perspective(400px) rotateY(90deg);opacity:0}}.flipOutY{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipOutY}@keyframes lightSpeedIn{0%{transform:translate3d(100%,0,0) skewX(-30deg);opacity:0}60%{transform:skewX(20deg);opacity:1}80%{transform:skewX(-5deg);opacity:1}to{transform:none;opacity:1}}.lightSpeedIn{animation-name:lightSpeedIn;animation-timing-function:ease-out}@keyframes lightSpeedOut{0%{opacity:1}to{transform:translate3d(100%,0,0) skewX(30deg);opacity:0}}.lightSpeedOut{animation-name:lightSpeedOut;animation-timing-function:ease-in}@keyframes rotateIn{0%{transform-origin:center;transform:rotate(-200deg);opacity:0}to{transform-origin:center;transform:none;opacity:1}}.rotateIn{animation-name:rotateIn}@keyframes rotateInDownLeft{0%{transform-origin:left bottom;transform:rotate(-45deg);opacity:0}to{transform-origin:left bottom;transform:none;opacity:1}}.rotateInDownLeft{animation-name:rotateInDownLeft}@keyframes rotateInDownRight{0%{transform-origin:right bottom;transform:rotate(45deg);opacity:0}to{transform-origin:right bottom;transform:none;opacity:1}}.rotateInDownRight{animation-name:rotateInDownRight}@keyframes rotateInUpLeft{0%{transform-origin:left bottom;transform:rotate(45deg);opacity:0}to{transform-origin:left bottom;transform:none;opacity:1}}.rotateInUpLeft{animation-name:rotateInUpLeft}@keyframes rotateInUpRight{0%{transform-origin:right bottom;transform:rotate(-90deg);opacity:0}to{transform-origin:right bottom;transform:none;opacity:1}}.rotateInUpRight{animation-name:rotateInUpRight}@keyframes rotateOut{0%{transform-origin:center;opacity:1}to{transform-origin:center;transform:rotate(200deg);opacity:0}}.rotateOut{animation-name:rotateOut}@keyframes rotateOutDownLeft{0%{transform-origin:left bottom;opacity:1}to{transform-origin:left bottom;transform:rotate(45deg);opacity:0}}.rotateOutDownLeft{animation-name:rotateOutDownLeft}@keyframes rotateOutDownRight{0%{transform-origin:right bottom;opacity:1}to{transform-origin:right bottom;transform:rotate(-45deg);opacity:0}}.rotateOutDownRight{animation-name:rotateOutDownRight}@keyframes rotateOutUpLeft{0%{transform-origin:left bottom;opacity:1}to{transform-origin:left bottom;transform:rotate(-45deg);opacity:0}}.rotateOutUpLeft{animation-name:rotateOutUpLeft}@keyframes rotateOutUpRight{0%{transform-origin:right bottom;opacity:1}to{transform-origin:right bottom;transform:rotate(90deg);opacity:0}}.rotateOutUpRight{animation-name:rotateOutUpRight}@keyframes hinge{0%{transform-origin:top left;animation-timing-function:ease-in-out}20%,60%{transform:rotate(80deg);transform-origin:top left;animation-timing-function:ease-in-out}40%,80%{transform:rotate(60deg);transform-origin:top left;animation-timing-function:ease-in-out;opacity:1}to{transform:translate3d(0,700px,0);opacity:0}}.hinge{animation-name:hinge}@keyframes jackInTheBox{0%{opacity:0;transform:scale(.1) rotate(30deg);transform-origin:center bottom}50%{transform:rotate(-10deg)}70%{transform:rotate(3deg)}to{opacity:1;transform:scale(1)}}.jackInTheBox{animation-name:jackInTheBox}@keyframes rollIn{0%{opacity:0;transform:translate3d(-100%,0,0) rotate(-120deg)}to{opacity:1;transform:none}}.rollIn{animation-name:rollIn}@keyframes rollOut{0%{opacity:1}to{opacity:0;transform:translate3d(100%,0,0) rotate(120deg)}}.rollOut{animation-name:rollOut}@keyframes zoomIn{0%{opacity:0;transform:scale3d(.3,.3,.3)}50%{opacity:1}}.zoomIn{animation-name:zoomIn}@keyframes zoomInDown{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,-1000px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,60px,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInDown{animation-name:zoomInDown}@keyframes zoomInLeft{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(-1000px,0,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(10px,0,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInLeft{animation-name:zoomInLeft}@keyframes zoomInRight{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(1000px,0,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(-10px,0,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInRight{animation-name:zoomInRight}@keyframes zoomInUp{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,1000px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,-60px,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInUp{animation-name:zoomInUp}@keyframes zoomOut{0%{opacity:1}50%{opacity:0;transform:scale3d(.3,.3,.3)}to{opacity:0}}.zoomOut{animation-name:zoomOut}@keyframes zoomOutDown{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,-60px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}to{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,2000px,0);transform-origin:center bottom;animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomOutDown{animation-name:zoomOutDown}@keyframes zoomOutLeft{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(42px,0,0)}to{opacity:0;transform:scale(.1) translate3d(-2000px,0,0);transform-origin:left center}}.zoomOutLeft{animation-name:zoomOutLeft}@keyframes zoomOutRight{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(-42px,0,0)}to{opacity:0;transform:scale(.1) translate3d(2000px,0,0);transform-origin:right center}}.zoomOutRight{animation-name:zoomOutRight}@keyframes zoomOutUp{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,60px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}to{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,-2000px,0);transform-origin:center bottom;animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomOutUp{animation-name:zoomOutUp}@keyframes slideInDown{0%{transform:translate3d(0,-100%,0);visibility:visible}to{transform:translateZ(0)}}.slideInDown{animation-name:slideInDown}@keyframes slideInLeft{0%{transform:translate3d(-100%,0,0);visibility:visible}to{transform:translateZ(0)}}.slideInLeft{animation-name:slideInLeft}@keyframes slideInRight{0%{transform:translate3d(100%,0,0);visibility:visible}to{transform:translateZ(0)}}.slideInRight{animation-name:slideInRight}@keyframes slideInUp{0%{transform:translate3d(0,100%,0);visibility:visible}to{transform:translateZ(0)}}.slideInUp{animation-name:slideInUp}@keyframes slideOutDown{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(0,100%,0)}}.slideOutDown{animation-name:slideOutDown}@keyframes slideOutLeft{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(-100%,0,0)}}.slideOutLeft{animation-name:slideOutLeft}@keyframes slideOutRight{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(100%,0,0)}}.slideOutRight{animation-name:slideOutRight}@keyframes slideOutUp{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(0,-100%,0)}}.slideOutUp{animation-name:slideOutUp}
    </style>
<!-- Global Variables -->
<script type='text/javascript'>
//<![CDATA[
// Global variables with content. "Available for Edit"
var monthFormat = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    noThumbnail = "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjb2vqQGkBiV03nM-yB88fVQMQ-hWLsYV5kuLLdIZpVTGYoY_rNk-Fdk8LIl_YqcN0f6a9NfqmFzojbSNa7GLaI73nUjmrhAmkyaSPfrMV7byuG9Q5T-hLu9HKxcsUtbhn5jvD9Ok0JBXA/s1600/nth.png",
    postPerPage = 8,
    commentsSystem = "blogger",
    disqusShortname = "soratemplates";
//]]>
</script>
<!-- Google Analytics -->
<!-- Google tag (gtag.js) -->
<script async='true' src='https://www.googletagmanager.com/gtag/js?id=G-Z7PVQ2FX0Y'></script>
<script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-Z7PVQ2FX0Y');
      </script>
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9000960003750726&host=ca-host-pub-1556223355139109" crossorigin="anonymous"></script>

<!-- data-ad-client=ca-pub-9000960003750726 -->

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?display=swap&family=Montserrat&family=Patua+One&family=Inconsolata"></head>
<body class='index home'>
<div id='loader'>
<svg height='200px' preserveAspectRatio='xMidYMid meet' style='left: 50%; top: 50%; position: absolute; transform: translate(-50%, -50%) matrix(1, 0, 0, 1, 0, 0);' viewBox='0 0 187.3 93.7' width='300px'>
<path d='M93.9,46.4c9.3,9.5,13.8,17.9,23.5,17.9s17.5-7.8,17.5-17.5s-7.8-17.6-17.5-17.5c-9.7,0.1-13.3,7.2-22.1,17.1     c-8.9,8.8-15.7,17.9-25.4,17.9s-17.5-7.8-17.5-17.5s7.8-17.5,17.5-17.5S86.2,38.6,93.9,46.4z' fill='none' id='outline' stroke='#ededed' stroke-linecap='round' stroke-linejoin='round' stroke-miterlimit='10' stroke-width='4'></path>
<path d='    M93.9,46.4c9.3,9.5,13.8,17.9,23.5,17.9s17.5-7.8,17.5-17.5s-7.8-17.6-17.5-17.5c-9.7,0.1-13.3,7.2-22.1,17.1     c-8.9,8.8-15.7,17.9-25.4,17.9s-17.5-7.8-17.5-17.5s7.8-17.5,17.5-17.5S86.2,38.6,93.9,46.4z' fill='none' id='outline-bg' opacity='0.05' stroke='#ededed' stroke-linecap='round' stroke-linejoin='round' stroke-miterlimit='10' stroke-width='4'></path>
</svg>
</div>
<!-- Theme Options -->
<div class='theme-options' style='display:none'>
<div class='sora-panel section' id='sora-panel' name='Theme Options'><div class='widget LinkList' data-version='2' id='LinkList71'>

          <script type='text/javascript'>
          //<![CDATA[
          

              var disqusShortname = "info-lk";
            

              var commentsSystem = "blogger";
            

              var postPerPage = 8;
            

              var postPerPage = 5;
            

              var postPerPage = 5;
            

          //]]>
          </script>
        
</div></div>
</div>
<!-- Outer Wrapper -->
<div id='outer-wrapper'>
<!-- Header Wrapper -->
<div id='header-wrap'>
<div class='container row'>
<div class='header-logo section' id='header-logo' name='Header Logo'><div class='widget Header' data-version='2' id='Header1'>
<div class='header-widget'>
<a class='header-brand' href='https://www.cloudkp.com/'>
<img alt='cloudkp' data-height='257' data-width='257' src='https://blogger.googleusercontent.com/img/a/AVvXsEj-gMWabszKyMwI8BtoicE7Wrn1eRc0lktt14tWFjBZKa5hXBhPWC7s9fq_1Ofp1jZu4lyc5LZzB4GOfyWHlXQpTZrxiIqL_OExO6LuKBfNR5GUOE5CqAkMktuEDSySXUIVcIkalNHblnCney1_zb1mrAesmUiWCwSWkW1PDbMwiBkB_bTXcxItilYu7w=s257'/>
</a>
</div>
</div></div>
<div class='scrolling-menu section' id='parallax-menu' name='Scrolling Menu'><div class='widget LinkList' data-version='2' id='LinkList1'>
<div class='widget-title'>
<h3 class='title'>
Menu
</h3>
</div>
<div class='widget-content'>
<ul>
<li><a href='#header-wrap'>Home</a></li>
<li><a href='#serv-tile-wrap'>Tools</a></li>
<li><a href='#main-wrapper'>Blog</a></li>
<li><a href='/p/contact-us.html'>Contact Us</a></li>
<li><a href='/p/private-policy.html'>Private Policy</a></li>
<li><a href='/p/terms-and-conditions.html'>Terms and Conditions</a></li>
</ul>
</div>
</div></div>
<span class='scrolling-mobile-menu-toggle'></span>
<div class='main-menu section' id='main-menu' name='Main Menu'><div class='widget LinkList' data-version='2' id='LinkList74'>
<ul id='main-menu-nav' role='menubar'>
<li><a href='/' role='menuitem'>Home</a></li>
<li><a href='/#serv-tile-wrap' role='menuitem'>Tools</a></li>
<li><a href='/p/upload.html' role='menuitem'>_kp cloud</a></li>
<li><a href='/p/short.html' role='menuitem'>_kp short</a></li>
<li><a href='/p/kpbin.html' role='menuitem'>_kp bin</a></li>
<li><a href='/2024/12/fashion-swaper.html' role='menuitem'>_Fashion swaper</a></li>
<li><a href='/2024/12/background-remover.html' role='menuitem'>_Background Remover</a></li>
<li><a href='/#main-wrapper' role='menuitem'>Blog</a></li>
<li><a href='/p/contact-us.html' role='menuitem'>Contact Us</a></li>
<li><a href='/p/private-policy.html' role='menuitem'>Private Policy</a></li>
<li><a href='http://status.cloudkp.com/' role='menuitem'>Server status</a></li>
</ul>
</div></div>
<span class='mobile-menu-toggle'></span>
</div>
<div class='scrolling-mobile-menu-wrap'>
<div class='scrolling-mobile-menu'></div>
</div>
<div class='mobile-menu-wrap'>
<div class='mobile-menu'></div>
</div>
</div>
<div class='clearfix'></div>
<!-- Featured Slider -->
<div id='intro-wrap'>
<div class='full-height section' id='main-intro' name='Main Intro'><div class='widget Image' data-version='2' id='Image1'>
<div class='widget-content'>
              <style type='text/css'>
              #intro-wrap{display:block}
              #main-intro{background:url(https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JM52vJbeuUbZPk8EBopKLu1c0LJVI0eWamTaqQJh4oC2-5CacLXlJjp4hEv1eWPwt0Mmz8Pyh3f0GkAa3sfVyPdWkx161Xw6L6AdsP_6UMCBBPbgBupl1DKhlICfc_eKLMEp63cDQrM6/s1600/home_page_header-2.jpg); background-repeat:no-repeat;
    background-size:cover;
    background-position:center;}
              </style>
              <div class='intro-content'>
<h3 class='intro-title'>A free cloud service</h3>
<p class='intro-snippet'>The only way to do great work is to love what you do - Steve Jobs</p>
</div>
</div>
</div><div class='widget HTML' data-version='2' id='HTML100'>

<style type='text/css'>
                #main-intro{
background: linear-gradient(125deg, #00FF57 0%, #010033 40%, #460043 70%, #F0FFC5 100%), linear-gradient(55deg, #0014C9 0%, #410060 100%), linear-gradient(300deg, #FFC700 0%, #001AFF 100%), radial-gradient(135% 215% at 115% 40%, #393939 0%, #393939 40%, #849561 calc(40% + 1px), #849561 60%, #EED690 calc(60% + 1px), #EED690 80%, #ECEFD8 calc(80% + 1px), #ECEFD8 100%), linear-gradient(125deg, #282D4F 0%, #282D4F 40%, #23103A calc(40% + 1px), #23103A 70%, #A0204C calc(70% + 1px), #A0204C 88%, #FF6C00 calc(88% + 1px), #FF6C00 100%);
background-blend-mode: overlay, screen, overlay, overlay, normal;
}
                </style>
            
</div></div>
<div class='slide-in wow bounceInUp' data-wow-delay='1s' data-wow-duration='1s'>
<a class='pointer' href='#main-wrapper'></a>
</div>
<svg class='editorial-border' preserveAspectRatio='none' viewBox='0 24 150 28 ' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'>
<defs>
<path d='M-160 44c30 0      58-18 88-18s     58 18 88 18      58-18 88-18      58 18 88 18     v44h-352z' id='gentle-wave'></path>
</defs>
<g class='parallax1'>
<use fill='#f461c1' x='50' xlink:href='#gentle-wave' y='3'></use>
</g>
<g class='parallax2'>
<use fill='#4579e2' x='50' xlink:href='#gentle-wave' y='0'></use>
</g>
<g class='parallax3'>
<use fill='#3461c1' x='50' xlink:href='#gentle-wave' y='9'></use>
</g>
<g class='parallax4'>
<use fill='#ffffff' x='50' xlink:href='#gentle-wave' y='6'></use>
</g>
</svg>
</div>
<div class='clearfix'></div>
<div class='wow slideInUp' data-wow-delay='1s' data-wow-duration='1s' id='serv-tile-wrap'>
<div class='container row'>
<div class='section' id='serv-tile' name='Service List'><div class='widget Image' data-version='2' id='Image6'>
<div class='widget-content'>
                <style type='text/css'>
                #serv-tile-wrap{display:block}
                </style>
               
<div class='serv-tile-box-avatar'><i class='fa ri-cloud-line'></i></div>
<div class='serv-tile-box-info'>
<h3 class='serv-tile-box-title'><a href="/p/upload.html">Kp Cloud</a></h3>
<p class='serv-tile-box-meta'>Store your files to cloud</p>
</div>
</div>
</div><div class='widget Image' data-version='2' id='Image7'>
<div class='widget-content'>
                <style type='text/css'>
                #serv-tile-wrap{display:block}
                </style>
               
<div class='serv-tile-box-avatar'><i class='fa ri-links-line'></i></div>
<div class='serv-tile-box-info'>
<h3 class='serv-tile-box-title'><a href="/p/short.html">Kp Short</a></h3>
<p class='serv-tile-box-meta'>Short url with custom limits</p>
</div>
</div>
</div><div class='widget Image' data-version='2' id='Image8'>
<div class='widget-content'>
                <style type='text/css'>
                #serv-tile-wrap{display:block}
                </style>
               
<div class='serv-tile-box-avatar'><i class='fa ri-links-line'></i></div>
<div class='serv-tile-box-info'>
<h3 class='serv-tile-box-title'><a href="/p/kpbin.html">Kp Bin</a></h3>
<p class='serv-tile-box-meta'>free text cloud</p>
</div>
</div>
</div><div class='widget Image' data-version='2' id='Image9'>
<div class='widget-content'>
                <style type='text/css'>
                #serv-tile-wrap{display:block}
                </style>
                 
<div class='serv-tile-box-avatar'><i class='fa ri-t-shirt-line'></i></div>
<div class='serv-tile-box-info'>
<h3 class='serv-tile-box-title'><a href="/2024/12/fashion-swaper.html">Fashion swaper</a></h3>
<p class='serv-tile-box-meta'>Ai outfit swaper</p>
</div>
</div>
</div><div class='widget Image' data-version='2' id='Image181'>
<div class='widget-content'>
                <style type='text/css'>
                #serv-tile-wrap{display:block}
                </style>
                 
<div class='serv-tile-box-avatar'><i class='fa ri-image-line'></i></div>
<div class='serv-tile-box-info'>
<h3 class='serv-tile-box-title'><a href="/2024/12/background-remover.html">Background Remover</a></h3>
<p class='serv-tile-box-meta'>Remove Image background using Ai</p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class='clearfix'></div>
<div class='counter-box'>
<div class='container row'>
<div class='counter-box-info wow fadeInLeftBig'>
<div class='head-text section' id='head-text4' name='Headline Text 01'><div class='widget Text' data-version='2' id='Text4'>
<div class='widget-title'>
<h3 class='title'>
Seamless File Sharing and Storage Solutions
</h3>
</div>
<p class='widget-content'>Welcome to your ultimate platform for efficient file storage and sharing! Our website offers a secure and intuitive space to store your files, share them with others, and simplify accessibility. With an integrated URL shortening service, sharing links has never been easier. Additionally, we provide a dedicated space for text storage and sharing, much like Pastebin, empowering you to collaborate and communicate effectively.</p>
</div></div>
<div class='counter-box-wrap section' id='counter-bar-nav' name='Achievements'><div class='widget Image' data-version='2' id='Image10'>
<div class='widget-content'>
<div class='counter-avatar'><i class='fa ri-pages-line'></i></div>
<div class='counter-info'>
<h3 class='counter-title'>10</h3>
<p class='counter-meta'>Projects Completed</p>
</div>
</div>
</div>
<div class='widget Image' data-version='2' id='Image12'>
<div class='widget-content'>
<div class='counter-avatar'><i class='fa ri-earth-line'></i></div>
<div class='counter-info'>
<h3 class='counter-title'>10098</h3>
<p class='counter-meta'>Worldwide Clients</p>
</div>
</div>
</div></div>
</div>
<div class='counter-box-image wow fadeInRightBig'>
<div class='counter-image-wrap section' id='counter-image-nav' name='Featured Image'><div class='widget Image' data-version='2' id='Image13'>
<div class='widget-content'>
<div class='counter-content'>
<div class='counter-content-box-color'></div>
                   <style type='text/css'>
               .counter-box-image .counter-content{background-image: url(https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgd2cYclw1Y3JV9X4_nKvnPxe2EkWViam2guDePaIBVmo-89iGhqnhswJzvSzQuLluolvj43NJRPuKGpAmWDg_BYEo4bBWYCASLXILggt4LgXChicIO0a655bMeUVu1cJUsq0v-IliMFBwG/s1200/t3+%25281%2529.jpg);}
                </style>
                 <div class='counter-content-details'>
<span class='counter-title'>Since</span>
<span class='counter-snippet'>2023</span>
</div>
</div>
</div>
</div></div>
</div>
<div class='clearfix'></div>
</div>
</div>
<div id='intro-author-wrap'>
<div class='wow jackInTheBox no-items section' id='intro-author-heading' name='Headline Text 02'>
</div>
<div class='clearfix'></div>
<div class='container row'>
<div class='author-intro-widgets'>
<div class='author-list wow fadeInLeftBig left-side-widget no-items section' id='intro-services-left' name='Info Box 1'>
</div>
<div class='author-list wow fadeInUpBig center-side-widget no-items section' id='intro-services-center' name='Info Box 2'>
</div>
<div class='author-list wow fadeInRightBig right-side-widget no-items section' id='intro-services-right' name='Info Box 3'>
</div>
</div>
</div>
</div>
<div class='clearfix'></div>
<div class='container row project-head'>
<div class='wow zoomIn head-text no-items section' id='head-text2' name='Headline Text 03'>
</div>
</div>
<div class='clearfix'></div>
<div class='container row featured-posts no-items section' id='featured-posts-1' name='Featured Posts'>
</div>
<div class='clearfix'></div>
<div id='testimonial-wrap'>
<div class='container row'>
<div class='wow fadeInDownBig head-text no-items section' id='head-text5' name='Headline Text 04'>
</div>
<div class='wow fadeInUpBig no-items section' id='testimonial' name='Main Testimonials'>
</div>
</div>
</div>
<div class='clearfix'></div>
<div class='wow tada' id='brand-services-wrap'>
<div class='container row'>
<div class='no-items section' id='intro-brand' name='Brand Logos'>
</div>
</div>
</div>
<div class='clearfix'></div>
<!-- Content Wrapper -->
<div id='content-wrapper'>
<div class='container row'>
<!-- Main Wrapper -->
<div id='main-wrapper'>
<div class='wow bounceInUp head-text section' id='head-text1' name='Headline Text 05'><div class='widget Text' data-version='2' id='Text1'>
<div class='widget-title'>
<h3 class='title'>
Recent Blog Posts
</h3>
</div>
<p class='widget-content'>Check our recent blogs here</p>
</div></div>
<div class='clearfix'></div>
<div class='main section' id='main' name='Main Posts'><div class='widget Blog' data-version='2' id='Blog1'>
<div class='blog-posts hfeed index-post-wrap'>
<div class='grid-posts'>
<div class='blog-post hentry index-post wow zoomIn post-0'>
<div class='post-image-wrap'>
<a class='post-image-link' href='https://www.cloudkp.com/2024/12/background-remover.html'>
<img alt='Background Remover' class='post-thumb' src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjmsS1Zv4fhK007W4GtzGkdJ8lXOIne9dmLo0HXcGzKuMRGHuzxRFmiOXuYrvxjui4k-VbQtuSpvfQKkNlUGEwdO0cPXsiNPs6KYFRKTKGsopf2LoEObqgKvoQETbJ5uv6U4kQF46QOXs6D2h6f-PpkvSM1MwlYhEFau9lGXNp_c_h51k9MVi2MpnpgKuTt/w72-h72-p-k-no-nu/bbbb.jpg'/>
</a>
</div>
<div class='post-content'>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2024/12/background-remover.html'>Background Remover</a>
</h2>
<div class='clearfix'></div>
<div class='post-meta'>
<span class='post-author'><a href='' target='_blank' title='rk'>rk</a></span>
<span class='post-date published' datetime='2024-12-22T09:33:00+05:30'><abbr class='published timeago' itemprop='datePublished' title='2024-12-22T09:33:00+05:30'>22 December</abbr></span>
<span class='post-tag index-post-tag'>
Ai
</span>
</div>
<div class='clearfix'></div>
<p class='post-snippet'>Fashion Swaper                                                                            Upload your image here               &#8230;</p>
</div>
</div>
</div>
<div class='blog-post hentry index-post wow zoomIn post-1'>
<div class='post-image-wrap'>
<a class='post-image-link' href='https://www.cloudkp.com/2024/12/fashion-swaper.html'>
<img alt='Fashion swaper' class='post-thumb' src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhNTpzdD9BQx3OVL2kTTmoXyhLZXdtilYYoiW5GwbUGMJVm1bViDjFmln4bRGJOR0LZsdnugYtojnszqljnjEhUc_UePgAA7uiLJ2KBrsHMxiK38rFzlJfMKc_yS3IIj9yx3uSaw8FgqHsb-_Ih6eVgxKoVARiVQ7IzZesD73faXUamKxgFZim0sekYSuI2/w72-h72-p-k-no-nu/maxresdefault.jpg'/>
</a>
</div>
<div class='post-content'>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2024/12/fashion-swaper.html'>Fashion swaper</a>
</h2>
<div class='clearfix'></div>
<div class='post-meta'>
<span class='post-author'><a href='' target='_blank' title='rk'>rk</a></span>
<span class='post-date published' datetime='2024-12-18T09:23:00+05:30'><abbr class='published timeago' itemprop='datePublished' title='2024-12-18T09:23:00+05:30'>18 December</abbr></span>
<span class='post-tag index-post-tag'>
Ai
</span>
</div>
<div class='clearfix'></div>
<p class='post-snippet'>Fashion Swaper                                                                            First upload the original image, then yo&#8230;</p>
</div>
</div>
</div>
</div>
</div>
<div class='blog-pager' id='blog-pager'>
<a class='blog-pager-older-link' href='https://www.cloudkp.com/search?updated-max=2024-12-18T09:23:00%2B05:30&max-results=2' id='Blog1_blog-pager-older-link' title='Older Posts'>
Show more
</a>
</div>
</div></div>
</div>
<!-- Sidebar Wrapper -->
<div id='sidebar-wrapper'>
<div class='sidebar common-widget section' id='sidebar' name='Sidebar Right'>
<div class='widget Stats' data-version='2' id='Stats1'>
<div class='widget-title'>
<h3 class='title'>
Total Pageviews
</h3>
</div>
<div class='widget-content'>
<div id='Stats1_content' style='display: none;'>
<script src='https://www.gstatic.com/charts/loader.js' type='text/javascript'></script>
<span id='Stats1_sparklinespan' style='display:inline-block; width:75px; height:30px'></span>
<span class='counter-wrapper graph-counter-wrapper' id='Stats1_totalCount'>
</span>
</div>
</div>
</div>
<div class='widget Label' data-version='2' id='Label2'>
<div class='widget-title'>
<h3 class='title'>
Tags
</h3>
</div>
<div class='widget-content cloud-label'>
<ul>
<li>
<a class='label-name' href='https://www.cloudkp.com/search/label/Ai'>
Ai
</a>
</li>
<li>
<a class='label-name' href='https://www.cloudkp.com/search/label/linux'>
linux
</a>
</li>
<li>
<a class='label-name' href='https://www.cloudkp.com/search/label/programming'>
programming
</a>
</li>
<li>
<a class='label-name' href='https://www.cloudkp.com/search/label/software%20engineering'>
software engineering
</a>
</li>
<li>
<a class='label-name' href='https://www.cloudkp.com/search/label/telegram'>
telegram
</a>
</li>
</ul>
</div>
</div>
<div class='widget HTML' data-version='2' id='HTML4'>
<div class='widget-content'>
<style>
#timer1 {
  position: fixed;
  top: 20%;
  left: 0%;
  width: 100%;
}



</style>




     <div id=aa3> </div>

      <center><h1><a style="display: none; background-color:red;" id="timer1">Please Wait 00:00:08 for your file </a></h1></center>


    <script>


  function base64Decode(base64) {
    try{
  // Use the browser's built-in base64 decoding function to decode the string
  var bytes = new Uint8Array(atob(base64).split('').map(function(c) {
    return c.charCodeAt(0);
  }));
  }

 catch(err) {
        return "GE4TAMZY"
      }

  // Convert the byte array to a UTF-8 string
  var str = new TextDecoder().decode(bytes);

  return str;
}


var uk = window.location.href;
    if (uk.includes(".html")){

      //var urlParams = new URLSearchParams(window.location.search);
      //var showTimer = urlParams.get('a1');
      
    const referer = document.referrer;
const match = referer.match(/[\?&]a1=([^&#%]*)/);
const a1Value = match ? match[1] : null;

if (a1Value) {
        var decods = base64Decode( a1Value);
        //document.getElementById('aa3').scrollIntoView();

        document.getElementById("timer1").style.display = "inline";

        var duration = 8; // duration of the timer in seconds
        var timer = document.getElementById("timer1");
        
        var interval = setInterval(function() {
          var minutes = Math.floor(duration / 60);
          var seconds = duration % 60;
          var hours = Math.floor(minutes / 60);
          minutes = minutes % 60;
          var timeString = hours.toString().padStart(2, '0') + ":" +
                           minutes.toString().padStart(2, '0') + ":" +
                           seconds.toString().padStart(2, '0');
          timer.innerHTML = " Please Wait "+timeString+" for your file";
          duration--;
          if (duration < 0) {
            clearInterval(interval);
            

            
            var urll = "https://www.cloudkp.com/p/cloud1.html?f="+decods
            
            //window.location.href = urll;
            timer.innerHTML = 'Click here for your file';

            timer.setAttribute ("href", urll);

                  
                // Create the text node for anchor element.
              var a = document.getElementById('timer1'); //or grab it by tagname etc
a.href = urll;
          }
        }, 1000);
      }

    }
    </script>
</div>
</div><div class='widget PopularPosts' data-version='2' id='PopularPosts1'>
<div class='widget-title'>
<h3 class='title'>
Popular Posts
</h3>
</div>
<div class='widget-content'>
<div class='post'>
<div class='post-content'>
<a class='post-image-link' href='https://www.cloudkp.com/2023/08/file-to-link-telegram-bot.html'>
<img alt='File to link telegram bot' class='post-thumb' src='https://blogger.googleusercontent.com/img/a/AVvXsEiyclz2TD1_8W6b6EuS9sGsMkdfHGlmoXy-zVYYLcLNmedaC9xYOhmdVtKOrpmbLG1b9ugCcAYL1bpUBcLQoVWnqhSq-a_yGmieqW5_TPxxvvExwxLxCf0OkvHeNgKQTW-QFcQ0ITlw8d8NJY9l6FZcGva8BHSOxoHVX8Cca3BIfD3DOky6jj2irt6gwzLq=w72-h72-p-k-no-nu'/>
</a>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2023/08/file-to-link-telegram-bot.html'>File to link telegram bot</a>
</h2>
<div class='post-meta'>
<span class='post-date published' datetime='2024-02-02T08:07:00+05:30'>02 February</span>
</div>
</div>
</div>
</div>
<div class='post'>
<div class='post-content'>
<a class='post-image-link' href='https://www.cloudkp.com/2023/02/upload-files-to-cloud-with-python.html'>
<img alt='Upload files to kpcloud using api' class='post-thumb' src='https://blogger.googleusercontent.com/img/a/AVvXsEgx_aEa2xrbR2EdjISWSjVLgfLayQ3-GAu3O8OTsZI-muSFv-xInzQPH9Yqpp9BJ4O9N2tEPVIy0XtmLKnRKoIeExW9oWAh38KG4FerXAs2CrvQKIkkOE9Cj0wlhjdKpfH-Ma5xuudbcMv0GtuC7UCAASJF4YEj198c3luosh9na7RbpEvw0PZ7hqjsnw=w72-h72-p-k-no-nu'/>
</a>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2023/02/upload-files-to-cloud-with-python.html'>Upload files to kpcloud using api</a>
</h2>
<div class='post-meta'>
<span class='post-date published' datetime='2023-02-13T12:25:00+05:30'>13 February</span>
</div>
</div>
</div>
</div>
<div class='post'>
<div class='post-content'>
<a class='post-image-link' href='https://www.cloudkp.com/2023/02/upload-youtube-video-using-telegram-bot.html'>
<img alt='Upload youtube video using telegram bot ' class='post-thumb' src='https://lh3.googleusercontent.com/blogger_img_proxy/AEn0k_tamxfKWauFcp2Lcalr8Y8onX2m9ZY3PNfoOdB2VcIsgkI4zeB9nKLwEIIU3ahp5W-31ZqxFdp1w404qzq2QCUmZrqeP3r-xtVoYkAw0XE4QbfrqQ=w72-h72-n-k-no-nu'/>
</a>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2023/02/upload-youtube-video-using-telegram-bot.html'>Upload youtube video using telegram bot </a>
</h2>
<div class='post-meta'>
<span class='post-date published' datetime='2023-02-09T17:37:00+05:30'>09 February</span>
</div>
</div>
</div>
</div>
<div class='post'>
<div class='post-content'>
<a class='post-image-link' href='https://www.cloudkp.com/2023/04/upload-files-to-google-drive-using.html'>
<img alt='Upload Files to Google Drive Using a Telegram Bot' class='post-thumb' src='https://lh3.googleusercontent.com/blogger_img_proxy/AEn0k_vH3aFrx17Q2Bv5nAHmLWyFRBNGXtnKu2MbJt7fW3hCpG-9D04PrDN4P1hcpiQFBN0XcFxj2lTjvbguIPRV8MpZbvhBzIWNxi0arpvJ_BjyR0NKrg=w72-h72-n-k-no-nu'/>
</a>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2023/04/upload-files-to-google-drive-using.html'>Upload Files to Google Drive Using a Telegram Bot</a>
</h2>
<div class='post-meta'>
<span class='post-date published' datetime='2023-04-28T09:12:00+05:30'>28 April</span>
</div>
</div>
</div>
</div>
<div class='post'>
<div class='post-content'>
<a class='post-image-link' href='https://www.cloudkp.com/2023/05/google-bard-telegram-bot.html'>
<img alt='Google Bard Telegram BOT' class='post-thumb' src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjoG9Lt0cqZ9YXYCKjyCuem17JFdmBe3ifxi-mBi4cDq1Lh6sJFkxA0xzyJ7jAKKO7AbjJIm7uyZVEZtqigvIewRPD8FDCnZDTib0Cz_y-L9gKRFapLUt2137-MK9KhxJ4cuyGX6WmdLQcvPRtelMFdgiOzFXQLgccsvcOlBVz38UhGKUUrxUa0TqMttw/w72-h72-p-k-no-nu/Screenshot%20from%202023-05-02%2007-43-10.png'/>
</a>
<div class='post-info'>
<h2 class='post-title'>
<a href='https://www.cloudkp.com/2023/05/google-bard-telegram-bot.html'>Google Bard Telegram BOT</a>
</h2>
<div class='post-meta'>
<span class='post-date published' datetime='2023-05-02T08:09:00+05:30'>02 May</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class='clearfix'></div>
<div id='editorial-wrap'>
<div class='container row'>
<div class='wow slideInLeft head-text no-items section' id='head-text6' name='Headline Text 06'>
</div>
<div class='wow slideInRight editorial-authors no-items section' id='editorial-box' name='Author Info'>
</div>
</div>
</div>
<div class='clearfix'></div>
<!-- Main Top Bar -->
<div class='wow slideInRight' id='top-bar'>
<div class='top-bar-bg'></div>
<div class='container row'>
<!-- Top Social -->
<div class='top-bar-social social section' id='top-bar-social' name='Social & Subscribe'><div class='widget HTML' data-version='2' id='HTML14'>
<div class='widget-content'>
<script type='text/javascript'>



    var uu = window.location.href;
    if (! uu.includes(".html")){
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);

        var txth= urlParams.get('c');
        if (txth){
            window.location.href = "/p/pk.html?f="+txth;
        }

        var tfgxth= urlParams.get('p');
        if (tfgxth){
            window.location.href = "/p/f.html?f="+tfgxth;
        }

        var ttfgxth= urlParams.get('t');
        if (ttfgxth){
            window.location.href = "/p/f.html?f="+ttfgxth;
        }


        var txt= urlParams.get('s');
        if (txt){
            window.location.href = "/p/short.html?s="+txt;
        }



        var txt2= urlParams.get('f');
        if (txt2){
            window.location.href = "/p/archive-cloud.html?f="+txt2;
        }


        var txtc1 = urlParams.get('c1');
        if (txtc1) {
           //var randomCloud = Math.random() < 0.5 ? "cloud1" : "cloud1";
            //window.location.href = "/p/" + randomCloud + ".html?f=" + txtc1;
            window.location.href = "/p/archive-cloud.html?f="+txtc1;
        }

        var txt3= urlParams.get('b');
        if (txt3){
            window.location.href = "/p/kpbin.html?b="+txt3;
        }

        var txt4= urlParams.get('u');
        if (txt4){
            window.location.href = "/p/short.html?u="+txt4;
        }


    }
    

</script>
</div>
</div>
</div>
<div class='no-items section' id='author-email-pic' name='Author Image'>
</div>
<div class='clearfix'></div>
</div>
</div>
<div class='wow slideInLeft map-me'>
</div>
<div class='clearfix'></div>
<!-- Footer Wrapper -->
<div id='footer-wrapper'>
<div id='contact-area'>
<div class='container row'>
<div class='wow slideInRight contact-col section' id='contact-left' name='Contact Left'><div class='widget Text' data-version='2' id='Text3'>

              <style type='text/css'>
              #contact-area{display:block}
              </style>
              <p class='widget-content'><p>Copyright <b>Pavi</b> All Rights Reserved. | <a href="/p/private-policy.html">Privacy Policy</a> | <a href="/p/contact-us.html">Contact us</a></p></p>
</div>
</div>
<div class='wow slideInLeft contact-col no-items section' id='contact-right' name='Contact Right'>
</div>
</div>
</div>
<div class='clearfix'></div>
<div class='wow bounceInUp' id='footer-copyright'>
<div class='container row'>
<div class='copyright-area'>
</div>
<div class='top-bar-nav section' id='top-bar-nav' name='Footer Navigation'><div class='widget LinkList' data-version='2' id='LinkList72'>
<div class='widget-content'>
<ul>
<li><a href='/'>Home</a></li>
<li><a href='https://pavi.is-a.dev/'>About</a></li>
<li><a href='https://github.com/rekcah-pavi'>Github</a></li>
</ul>
</div>
</div></div>
<div class='clearfix'></div>
</div>
</div>
</div>
</div>
<!-- Main Scripts -->
<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js' type='text/javascript'></script>
<!-- Theme Functions JS -->
<script type='text/javascript'>
//<![CDATA[
/*! WOW wow.js - v1.3.0 - 2016-10-04
* https://wowjs.uk
* Copyright (c) 2016 Thomas Grainger; Licensed MIT */!function(a,b){if("function"==typeof define&&define.amd)define(["module","exports"],b);else if("undefined"!=typeof exports)b(module,exports);else{var c={exports:{}};b(c,c.exports),a.WOW=c.exports}}(this,function(a,b){"use strict";function c(a,b){if(!(a instanceof b))throw new TypeError("Cannot call a class as a function")}function d(a,b){return b.indexOf(a)>=0}function e(a,b){for(var c in b)if(null==a[c]){var d=b[c];a[c]=d}return a}function f(a){return/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(a)}function g(a){var b=arguments.length<=1||void 0===arguments[1]?!1:arguments[1],c=arguments.length<=2||void 0===arguments[2]?!1:arguments[2],d=arguments.length<=3||void 0===arguments[3]?null:arguments[3],e=void 0;return null!=document.createEvent?(e=document.createEvent("CustomEvent"),e.initCustomEvent(a,b,c,d)):null!=document.createEventObject?(e=document.createEventObject(),e.eventType=a):e.eventName=a,e}function h(a,b){null!=a.dispatchEvent?a.dispatchEvent(b):b in(null!=a)?a[b]():"on"+b in(null!=a)&&a["on"+b]()}function i(a,b,c){null!=a.addEventListener?a.addEventListener(b,c,!1):null!=a.attachEvent?a.attachEvent("on"+b,c):a[b]=c}function j(a,b,c){null!=a.removeEventListener?a.removeEventListener(b,c,!1):null!=a.detachEvent?a.detachEvent("on"+b,c):delete a[b]}function k(){return"innerHeight"in window?window.innerHeight:document.documentElement.clientHeight}Object.defineProperty(b,"__esModule",{value:!0});var l,m,n=function(){function a(a,b){for(var c=0;c<b.length;c++){var d=b[c];d.enumerable=d.enumerable||!1,d.configurable=!0,"value"in d&&(d.writable=!0),Object.defineProperty(a,d.key,d)}}return function(b,c,d){return c&&a(b.prototype,c),d&&a(b,d),b}}(),o=window.WeakMap||window.MozWeakMap||function(){function a(){c(this,a),this.keys=[],this.values=[]}return n(a,[{key:"get",value:function(a){for(var b=0;b<this.keys.length;b++){var c=this.keys[b];if(c===a)return this.values[b]}}},{key:"set",value:function(a,b){for(var c=0;c<this.keys.length;c++){var d=this.keys[c];if(d===a)return this.values[c]=b,this}return this.keys.push(a),this.values.push(b),this}}]),a}(),p=window.MutationObserver||window.WebkitMutationObserver||window.MozMutationObserver||(m=l=function(){function a(){c(this,a),"undefined"!=typeof console&&null!==console&&(console.warn("MutationObserver is not supported by your browser."),console.warn("WOW.js cannot detect dom mutations, please call .sync() after loading new content."))}return n(a,[{key:"observe",value:function(){}}]),a}(),l.notSupported=!0,m),q=window.getComputedStyle||function(a){var b=/(\-([a-z]){1})/g;return{getPropertyValue:function(c){"float"===c&&(c="styleFloat"),b.test(c)&&c.replace(b,function(a,b){return b.toUpperCase()});var d=a.currentStyle;return(null!=d?d[c]:void 0)||null}}},r=function(){function a(){var b=arguments.length<=0||void 0===arguments[0]?{}:arguments[0];c(this,a),this.defaults={boxClass:"wow",animateClass:"animated",offset:0,mobile:!0,live:!0,callback:null,scrollContainer:null,resetAnimation:!0},this.animate=function(){return"requestAnimationFrame"in window?function(a){return window.requestAnimationFrame(a)}:function(a){return a()}}(),this.vendors=["moz","webkit"],this.start=this.start.bind(this),this.resetAnimation=this.resetAnimation.bind(this),this.scrollHandler=this.scrollHandler.bind(this),this.scrollCallback=this.scrollCallback.bind(this),this.scrolled=!0,this.config=e(b,this.defaults),null!=b.scrollContainer&&(this.config.scrollContainer=document.querySelector(b.scrollContainer)),this.animationNameCache=new o,this.wowEvent=g(this.config.boxClass)}return n(a,[{key:"init",value:function(){this.element=window.document.documentElement,d(document.readyState,["interactive","complete"])?this.start():i(document,"DOMContentLoaded",this.start),this.finished=[]}},{key:"start",value:function(){var a=this;if(this.stopped=!1,this.boxes=[].slice.call(this.element.querySelectorAll("."+this.config.boxClass)),this.all=this.boxes.slice(0),this.boxes.length)if(this.disabled())this.resetStyle();else for(var b=0;b<this.boxes.length;b++){var c=this.boxes[b];this.applyStyle(c,!0)}if(this.disabled()||(i(this.config.scrollContainer||window,"scroll",this.scrollHandler),i(window,"resize",this.scrollHandler),this.interval=setInterval(this.scrollCallback,50)),this.config.live){var d=new p(function(b){for(var c=0;c<b.length;c++)for(var d=b[c],e=0;e<d.addedNodes.length;e++){var f=d.addedNodes[e];a.doSync(f)}});d.observe(document.body,{childList:!0,subtree:!0})}}},{key:"stop",value:function(){this.stopped=!0,j(this.config.scrollContainer||window,"scroll",this.scrollHandler),j(window,"resize",this.scrollHandler),null!=this.interval&&clearInterval(this.interval)}},{key:"sync",value:function(){p.notSupported&&this.doSync(this.element)}},{key:"doSync",value:function(a){if("undefined"!=typeof a&&null!==a||(a=this.element),1===a.nodeType){a=a.parentNode||a;for(var b=a.querySelectorAll("."+this.config.boxClass),c=0;c<b.length;c++){var e=b[c];d(e,this.all)||(this.boxes.push(e),this.all.push(e),this.stopped||this.disabled()?this.resetStyle():this.applyStyle(e,!0),this.scrolled=!0)}}}},{key:"show",value:function(a){return this.applyStyle(a),a.className=a.className+" "+this.config.animateClass,null!=this.config.callback&&this.config.callback(a),h(a,this.wowEvent),this.config.resetAnimation&&(i(a,"animationend",this.resetAnimation),i(a,"oanimationend",this.resetAnimation),i(a,"webkitAnimationEnd",this.resetAnimation),i(a,"MSAnimationEnd",this.resetAnimation)),a}},{key:"applyStyle",value:function(a,b){var c=this,d=a.getAttribute("data-wow-duration"),e=a.getAttribute("data-wow-delay"),f=a.getAttribute("data-wow-iteration");return this.animate(function(){return c.customStyle(a,b,d,e,f)})}},{key:"resetStyle",value:function(){for(var a=0;a<this.boxes.length;a++){var b=this.boxes[a];b.style.visibility="visible"}}},{key:"resetAnimation",value:function(a){if(a.type.toLowerCase().indexOf("animationend")>=0){var b=a.target||a.srcElement;b.className=b.className.replace(this.config.animateClass,"").trim()}}},{key:"customStyle",value:function(a,b,c,d,e){return b&&this.cacheAnimationName(a),a.style.visibility=b?"hidden":"visible",c&&this.vendorSet(a.style,{animationDuration:c}),d&&this.vendorSet(a.style,{animationDelay:d}),e&&this.vendorSet(a.style,{animationIterationCount:e}),this.vendorSet(a.style,{animationName:b?"none":this.cachedAnimationName(a)}),a}},{key:"vendorSet",value:function(a,b){for(var c in b)if(b.hasOwnProperty(c)){var d=b[c];a[""+c]=d;for(var e=0;e<this.vendors.length;e++){var f=this.vendors[e];a[""+f+c.charAt(0).toUpperCase()+c.substr(1)]=d}}}},{key:"vendorCSS",value:function(a,b){for(var c=q(a),d=c.getPropertyCSSValue(b),e=0;e<this.vendors.length;e++){var f=this.vendors[e];d=d||c.getPropertyCSSValue("-"+f+"-"+b)}return d}},{key:"animationName",value:function(a){var b=void 0;try{b=this.vendorCSS(a,"animation-name").cssText}catch(c){b=q(a).getPropertyValue("animation-name")}return"none"===b?"":b}},{key:"cacheAnimationName",value:function(a){return this.animationNameCache.set(a,this.animationName(a))}},{key:"cachedAnimationName",value:function(a){return this.animationNameCache.get(a)}},{key:"scrollHandler",value:function(){this.scrolled=!0}},{key:"scrollCallback",value:function(){if(this.scrolled){this.scrolled=!1;for(var a=[],b=0;b<this.boxes.length;b++){var c=this.boxes[b];if(c){if(this.isVisible(c)){this.show(c);continue}a.push(c)}}this.boxes=a,this.boxes.length||this.config.live||this.stop()}}},{key:"offsetTop",value:function(a){for(;void 0===a.offsetTop;)a=a.parentNode;for(var b=a.offsetTop;a.offsetParent;)a=a.offsetParent,b+=a.offsetTop;return b}},{key:"isVisible",value:function(a){var b=a.getAttribute("data-wow-offset")||this.config.offset,c=this.config.scrollContainer&&this.config.scrollContainer.scrollTop||window.pageYOffset,d=c+Math.min(this.element.clientHeight,k())-b,e=this.offsetTop(a),f=e+a.clientHeight;return d>=e&&f>=c}},{key:"disabled",value:function(){return!this.config.mobile&&f(navigator.userAgent)}}]),a}();b["default"]=r,a.exports=b["default"]});
 
  new WOW().init();
/*
 * jQuery One Page Nav Plugin
 * http://github.com/davist11/jQuery-One-Page-Nav
 * Copyright (c) 2010 Trevor Davis (http://trevordavis.net)
 * Dual licensed under the MIT and GPL licenses.
 * Uses the same license as jQuery, see:
 * http://jquery.org/license
 * @version 3.0.0
 */
;(function($,window,document,undefined){var OnePageNav=function(elem,options){this.elem=elem;this.$elem=$(elem);this.options=options;this.metadata=this.$elem.data('plugin-options');this.$win=$(window);this.sections={};this.didScroll=false;this.$doc=$(document);this.docHeight=this.$doc.height();};OnePageNav.prototype={defaults:{navItems:'a',currentClass:'current',changeHash:false,easing:'swing',filter:'',scrollSpeed:750,scrollThreshold:0.5,begin:false,end:false,scrollChange:false},init:function(){this.config=$.extend({},this.defaults,this.options,this.metadata);this.$nav=this.$elem.find(this.config.navItems);if(this.config.filter!==''){this.$nav=this.$nav.filter(this.config.filter);}
this.$nav.on('click.onePageNav',$.proxy(this.handleClick,this));this.getPositions();this.bindInterval();this.$win.on('resize.onePageNav',$.proxy(this.getPositions,this));return this;},adjustNav:function(self,$parent){self.$elem.find('.'+self.config.currentClass).removeClass(self.config.currentClass);$parent.addClass(self.config.currentClass);},bindInterval:function(){var self=this;var docHeight;self.$win.on('scroll.onePageNav',function(){self.didScroll=true;});self.t=setInterval(function(){docHeight=self.$doc.height();if(self.didScroll){self.didScroll=false;self.scrollChange();}
if(docHeight!==self.docHeight){self.docHeight=docHeight;self.getPositions();}},250);},getHash:function($link){return $link.attr('href').split('#')[1];},getPositions:function(){var self=this;var linkHref;var topPos;var $target;self.$nav.each(function(){linkHref=self.getHash($(this));$target=$('#'+linkHref);if($target.length){topPos=$target.offset().top;self.sections[linkHref]=Math.round(topPos);}});},getSection:function(windowPos){var returnValue=null;var windowHeight=Math.round(this.$win.height()*this.config.scrollThreshold);for(var section in this.sections){if((this.sections[section]-windowHeight)<windowPos){returnValue=section;}}
return returnValue;},handleClick:function(e){var self=this;var $link=$(e.currentTarget);var $parent=$link.parent();var newLoc='#'+self.getHash($link);if(!$parent.hasClass(self.config.currentClass)){if(self.config.begin){self.config.begin();}
self.adjustNav(self,$parent);self.unbindInterval();self.scrollTo(newLoc,function(){if(self.config.changeHash){window.location.hash=newLoc;}
self.bindInterval();if(self.config.end){self.config.end();}});}
e.preventDefault();},scrollChange:function(){var windowTop=this.$win.scrollTop();var position=this.getSection(windowTop);var $parent;if(position!==null){$parent=this.$elem.find('a[href$="#'+position+'"]').parent();if(!$parent.hasClass(this.config.currentClass)){this.adjustNav(this,$parent);if(this.config.scrollChange){this.config.scrollChange($parent);}}}},scrollTo:function(target,callback){var offset=$(target).offset().top;$('html, body').animate({scrollTop:offset},this.config.scrollSpeed,this.config.easing,callback);},unbindInterval:function(){clearInterval(this.t);this.$win.unbind('scroll.onePageNav');}};OnePageNav.defaults=OnePageNav.prototype.defaults;$.fn.onePageNav=function(options){return this.each(function(){new OnePageNav(this,options).init();});};})(jQuery,window,document);

/*
* jquery-match-height 0.7.0 by @liabru
* http://brm.io/jquery-match-height/
* License MIT
*/
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery"],t):"undefined"!=typeof module&&module.exports?module.exports=t(require("jquery")):t(jQuery)}(function(t){var e=-1,o=-1,i=function(t){return parseFloat(t)||0},a=function(e){var o=1,a=t(e),n=null,r=[];return a.each(function(){var e=t(this),a=e.offset().top-i(e.css("margin-top")),s=r.length>0?r[r.length-1]:null;null===s?r.push(e):Math.floor(Math.abs(n-a))<=o?r[r.length-1]=s.add(e):r.push(e),n=a}),r},n=function(e){var o={
byRow:!0,property:"height",target:null,remove:!1};return"object"==typeof e?t.extend(o,e):("boolean"==typeof e?o.byRow=e:"remove"===e&&(o.remove=!0),o)},r=t.fn.matchHeight=function(e){var o=n(e);if(o.remove){var i=this;return this.css(o.property,""),t.each(r._groups,function(t,e){e.elements=e.elements.not(i)}),this}return this.length<=1&&!o.target?this:(r._groups.push({elements:this,options:o}),r._apply(this,o),this)};r.version="0.7.0",r._groups=[],r._throttle=80,r._maintainScroll=!1,r._beforeUpdate=null,
r._afterUpdate=null,r._rows=a,r._parse=i,r._parseOptions=n,r._apply=function(e,o){var s=n(o),h=t(e),l=[h],c=t(window).scrollTop(),p=t("html").outerHeight(!0),d=h.parents().filter(":hidden");return d.each(function(){var e=t(this);e.data("style-cache",e.attr("style"))}),d.css("display","block"),s.byRow&&!s.target&&(h.each(function(){var e=t(this),o=e.css("display");"inline-block"!==o&&"flex"!==o&&"inline-flex"!==o&&(o="block"),e.data("style-cache",e.attr("style")),e.css({display:o,"padding-top":"0",
"padding-bottom":"0","margin-top":"0","margin-bottom":"0","border-top-width":"0","border-bottom-width":"0",height:"100px",overflow:"hidden"})}),l=a(h),h.each(function(){var e=t(this);e.attr("style",e.data("style-cache")||"")})),t.each(l,function(e,o){var a=t(o),n=0;if(s.target)n=s.target.outerHeight(!1);else{if(s.byRow&&a.length<=1)return void a.css(s.property,"");a.each(function(){var e=t(this),o=e.attr("style"),i=e.css("display");"inline-block"!==i&&"flex"!==i&&"inline-flex"!==i&&(i="block");var a={
display:i};a[s.property]="",e.css(a),e.outerHeight(!1)>n&&(n=e.outerHeight(!1)),o?e.attr("style",o):e.css("display","")})}a.each(function(){var e=t(this),o=0;s.target&&e.is(s.target)||("border-box"!==e.css("box-sizing")&&(o+=i(e.css("border-top-width"))+i(e.css("border-bottom-width")),o+=i(e.css("padding-top"))+i(e.css("padding-bottom"))),e.css(s.property,n-o+"px"))})}),d.each(function(){var e=t(this);e.attr("style",e.data("style-cache")||null)}),r._maintainScroll&&t(window).scrollTop(c/p*t("html").outerHeight(!0)),
this},r._applyDataApi=function(){var e={};t("[data-match-height], [data-mh]").each(function(){var o=t(this),i=o.attr("data-mh")||o.attr("data-match-height");i in e?e[i]=e[i].add(o):e[i]=o}),t.each(e,function(){this.matchHeight(!0)})};var s=function(e){r._beforeUpdate&&r._beforeUpdate(e,r._groups),t.each(r._groups,function(){r._apply(this.elements,this.options)}),r._afterUpdate&&r._afterUpdate(e,r._groups)};r._update=function(i,a){if(a&&"resize"===a.type){var n=t(window).width();if(n===e)return;e=n;
}i?-1===o&&(o=setTimeout(function(){s(a),o=-1},r._throttle)):s(a)},t(r._applyDataApi),t(window).bind("load",function(t){r._update(!1,t)}),t(window).bind("resize orientationchange",function(t){r._update(!0,t)})});

/*! Owl carousel by Bartosz Wojciechowski/David Deutsch | v2.0.0 - http://owlcarousel2.github.io/OwlCarousel2 */
!function(a,b,c,d){function e(b,c){this.settings=null,this.options=a.extend({},e.Defaults,c),this.$element=a(b),this.drag=a.extend({},m),this.state=a.extend({},n),this.e=a.extend({},o),this._plugins={},this._supress={},this._current=null,this._speed=null,this._coordinates=[],this._breakpoint=null,this._width=null,this._items=[],this._clones=[],this._mergers=[],this._invalidated={},this._pipe=[],a.each(e.Plugins,a.proxy(function(a,b){this._plugins[a[0].toLowerCase()+a.slice(1)]=new b(this)},this)),a.each(e.Pipe,a.proxy(function(b,c){this._pipe.push({filter:c.filter,run:a.proxy(c.run,this)})},this)),this.setup(),this.initialize()}function f(a){if(a.touches!==d)return{x:a.touches[0].pageX,y:a.touches[0].pageY};if(a.touches===d){if(a.pageX!==d)return{x:a.pageX,y:a.pageY};if(a.pageX===d)return{x:a.clientX,y:a.clientY}}}function g(a){var b,d,e=c.createElement("div"),f=a;for(b in f)if(d=f[b],"undefined"!=typeof e.style[d])return e=null,[d,b];return[!1]}function h(){return g(["transition","WebkitTransition","MozTransition","OTransition"])[1]}function i(){return g(["transform","WebkitTransform","MozTransform","OTransform","msTransform"])[0]}function j(){return g(["perspective","webkitPerspective","MozPerspective","OPerspective","MsPerspective"])[0]}function k(){return"ontouchstart"in b||!!navigator.msMaxTouchPoints}function l(){return b.navigator.msPointerEnabled}var m,n,o;m={start:0,startX:0,startY:0,current:0,currentX:0,currentY:0,offsetX:0,offsetY:0,distance:null,startTime:0,endTime:0,updatedX:0,targetEl:null},n={isTouch:!1,isScrolling:!1,isSwiping:!1,direction:!1,inMotion:!1},o={_onDragStart:null,_onDragMove:null,_onDragEnd:null,_transitionEnd:null,_resizer:null,_responsiveCall:null,_goToLoop:null,_checkVisibile:null},e.Defaults={items:3,loop:!1,center:!1,mouseDrag:!0,touchDrag:!0,pullDrag:!0,freeDrag:!1,margin:0,stagePadding:0,merge:!1,mergeFit:!0,autoWidth:!1,startPosition:0,rtl:!1,smartSpeed:250,fluidSpeed:!1,dragEndSpeed:!1,responsive:{},responsiveRefreshRate:200,responsiveBaseElement:b,responsiveClass:!1,fallbackEasing:"swing",info:!1,nestedItemSelector:!1,itemElement:"div",stageElement:"div",themeClass:"owl-theme",baseClass:"owl-carousel",itemClass:"owl-item",centerClass:"center",activeClass:"active"},e.Width={Default:"default",Inner:"inner",Outer:"outer"},e.Plugins={},e.Pipe=[{filter:["width","items","settings"],run:function(a){a.current=this._items&&this._items[this.relative(this._current)]}},{filter:["items","settings"],run:function(){var a=this._clones,b=this.$stage.children(".cloned");(b.length!==a.length||!this.settings.loop&&a.length>0)&&(this.$stage.children(".cloned").remove(),this._clones=[])}},{filter:["items","settings"],run:function(){var a,b,c=this._clones,d=this._items,e=this.settings.loop?c.length-Math.max(2*this.settings.items,4):0;for(a=0,b=Math.abs(e/2);b>a;a++)e>0?(this.$stage.children().eq(d.length+c.length-1).remove(),c.pop(),this.$stage.children().eq(0).remove(),c.pop()):(c.push(c.length/2),this.$stage.append(d[c[c.length-1]].clone().addClass("cloned")),c.push(d.length-1-(c.length-1)/2),this.$stage.prepend(d[c[c.length-1]].clone().addClass("cloned")))}},{filter:["width","items","settings"],run:function(){var a,b,c,d=this.settings.rtl?1:-1,e=(this.width()/this.settings.items).toFixed(3),f=0;for(this._coordinates=[],b=0,c=this._clones.length+this._items.length;c>b;b++)a=this._mergers[this.relative(b)],a=this.settings.mergeFit&&Math.min(a,this.settings.items)||a,f+=(this.settings.autoWidth?this._items[this.relative(b)].width()+this.settings.margin:e*a)*d,this._coordinates.push(f)}},{filter:["width","items","settings"],run:function(){var b,c,d=(this.width()/this.settings.items).toFixed(3),e={width:Math.abs(this._coordinates[this._coordinates.length-1])+2*this.settings.stagePadding,"padding-left":this.settings.stagePadding||"","padding-right":this.settings.stagePadding||""};if(this.$stage.css(e),e={width:this.settings.autoWidth?"auto":d-this.settings.margin},e[this.settings.rtl?"margin-left":"margin-right"]=this.settings.margin,!this.settings.autoWidth&&a.grep(this._mergers,function(a){return a>1}).length>0)for(b=0,c=this._coordinates.length;c>b;b++)e.width=Math.abs(this._coordinates[b])-Math.abs(this._coordinates[b-1]||0)-this.settings.margin,this.$stage.children().eq(b).css(e);else this.$stage.children().css(e)}},{filter:["width","items","settings"],run:function(a){a.current&&this.reset(this.$stage.children().index(a.current))}},{filter:["position"],run:function(){this.animate(this.coordinates(this._current))}},{filter:["width","position","items","settings"],run:function(){var a,b,c,d,e=this.settings.rtl?1:-1,f=2*this.settings.stagePadding,g=this.coordinates(this.current())+f,h=g+this.width()*e,i=[];for(c=0,d=this._coordinates.length;d>c;c++)a=this._coordinates[c-1]||0,b=Math.abs(this._coordinates[c])+f*e,(this.op(a,"<=",g)&&this.op(a,">",h)||this.op(b,"<",g)&&this.op(b,">",h))&&i.push(c);this.$stage.children("."+this.settings.activeClass).removeClass(this.settings.activeClass),this.$stage.children(":eq("+i.join("), :eq(")+")").addClass(this.settings.activeClass),this.settings.center&&(this.$stage.children("."+this.settings.centerClass).removeClass(this.settings.centerClass),this.$stage.children().eq(this.current()).addClass(this.settings.centerClass))}}],e.prototype.initialize=function(){if(this.trigger("initialize"),this.$element.addClass(this.settings.baseClass).addClass(this.settings.themeClass).toggleClass("owl-rtl",this.settings.rtl),this.browserSupport(),this.settings.autoWidth&&this.state.imagesLoaded!==!0){var b,c,e;if(b=this.$element.find("img"),c=this.settings.nestedItemSelector?"."+this.settings.nestedItemSelector:d,e=this.$element.children(c).width(),b.length&&0>=e)return this.preloadAutoWidthImages(b),!1}this.$element.addClass("owl-loading"),this.$stage=a("<"+this.settings.stageElement+' class="owl-stage"/>').wrap('<div class="owl-stage-outer">'),this.$element.append(this.$stage.parent()),this.replace(this.$element.children().not(this.$stage.parent())),this._width=this.$element.width(),this.refresh(),this.$element.removeClass("owl-loading").addClass("owl-loaded"),this.eventsCall(),this.internalEvents(),this.addTriggerableEvents(),this.trigger("initialized")},e.prototype.setup=function(){var b=this.viewport(),c=this.options.responsive,d=-1,e=null;c?(a.each(c,function(a){b>=a&&a>d&&(d=Number(a))}),e=a.extend({},this.options,c[d]),delete e.responsive,e.responsiveClass&&this.$element.attr("class",function(a,b){return b.replace(/\b owl-responsive-\S+/g,"")}).addClass("owl-responsive-"+d)):e=a.extend({},this.options),(null===this.settings||this._breakpoint!==d)&&(this.trigger("change",{property:{name:"settings",value:e}}),this._breakpoint=d,this.settings=e,this.invalidate("settings"),this.trigger("changed",{property:{name:"settings",value:this.settings}}))},e.prototype.optionsLogic=function(){this.$element.toggleClass("owl-center",this.settings.center),this.settings.loop&&this._items.length<this.settings.items&&(this.settings.loop=!1),this.settings.autoWidth&&(this.settings.stagePadding=!1,this.settings.merge=!1)},e.prototype.prepare=function(b){var c=this.trigger("prepare",{content:b});return c.data||(c.data=a("<"+this.settings.itemElement+"/>").addClass(this.settings.itemClass).append(b)),this.trigger("prepared",{content:c.data}),c.data},e.prototype.update=function(){for(var b=0,c=this._pipe.length,d=a.proxy(function(a){return this[a]},this._invalidated),e={};c>b;)(this._invalidated.all||a.grep(this._pipe[b].filter,d).length>0)&&this._pipe[b].run(e),b++;this._invalidated={}},e.prototype.width=function(a){switch(a=a||e.Width.Default){case e.Width.Inner:case e.Width.Outer:return this._width;default:return this._width-2*this.settings.stagePadding+this.settings.margin}},e.prototype.refresh=function(){if(0===this._items.length)return!1;(new Date).getTime();this.trigger("refresh"),this.setup(),this.optionsLogic(),this.$stage.addClass("owl-refresh"),this.update(),this.$stage.removeClass("owl-refresh"),this.state.orientation=b.orientation,this.watchVisibility(),this.trigger("refreshed")},e.prototype.eventsCall=function(){this.e._onDragStart=a.proxy(function(a){this.onDragStart(a)},this),this.e._onDragMove=a.proxy(function(a){this.onDragMove(a)},this),this.e._onDragEnd=a.proxy(function(a){this.onDragEnd(a)},this),this.e._onResize=a.proxy(function(a){this.onResize(a)},this),this.e._transitionEnd=a.proxy(function(a){this.transitionEnd(a)},this),this.e._preventClick=a.proxy(function(a){this.preventClick(a)},this)},e.prototype.onThrottledResize=function(){b.clearTimeout(this.resizeTimer),this.resizeTimer=b.setTimeout(this.e._onResize,this.settings.responsiveRefreshRate)},e.prototype.onResize=function(){return this._items.length?this._width===this.$element.width()?!1:this.trigger("resize").isDefaultPrevented()?!1:(this._width=this.$element.width(),this.invalidate("width"),this.refresh(),void this.trigger("resized")):!1},e.prototype.eventsRouter=function(a){var b=a.type;"mousedown"===b||"touchstart"===b?this.onDragStart(a):"mousemove"===b||"touchmove"===b?this.onDragMove(a):"mouseup"===b||"touchend"===b?this.onDragEnd(a):"touchcancel"===b&&this.onDragEnd(a)},e.prototype.internalEvents=function(){var c=(k(),l());this.settings.mouseDrag?(this.$stage.on("mousedown",a.proxy(function(a){this.eventsRouter(a)},this)),this.$stage.on("dragstart",function(){return!1}),this.$stage.get(0).onselectstart=function(){return!1}):this.$element.addClass("owl-text-select-on"),this.settings.touchDrag&&!c&&this.$stage.on("touchstart touchcancel",a.proxy(function(a){this.eventsRouter(a)},this)),this.transitionEndVendor&&this.on(this.$stage.get(0),this.transitionEndVendor,this.e._transitionEnd,!1),this.settings.responsive!==!1&&this.on(b,"resize",a.proxy(this.onThrottledResize,this))},e.prototype.onDragStart=function(d){var e,g,h,i;if(e=d.originalEvent||d||b.event,3===e.which||this.state.isTouch)return!1;if("mousedown"===e.type&&this.$stage.addClass("owl-grab"),this.trigger("drag"),this.drag.startTime=(new Date).getTime(),this.speed(0),this.state.isTouch=!0,this.state.isScrolling=!1,this.state.isSwiping=!1,this.drag.distance=0,g=f(e).x,h=f(e).y,this.drag.offsetX=this.$stage.position().left,this.drag.offsetY=this.$stage.position().top,this.settings.rtl&&(this.drag.offsetX=this.$stage.position().left+this.$stage.width()-this.width()+this.settings.margin),this.state.inMotion&&this.support3d)i=this.getTransformProperty(),this.drag.offsetX=i,this.animate(i),this.state.inMotion=!0;else if(this.state.inMotion&&!this.support3d)return this.state.inMotion=!1,!1;this.drag.startX=g-this.drag.offsetX,this.drag.startY=h-this.drag.offsetY,this.drag.start=g-this.drag.startX,this.drag.targetEl=e.target||e.srcElement,this.drag.updatedX=this.drag.start,("IMG"===this.drag.targetEl.tagName||"A"===this.drag.targetEl.tagName)&&(this.drag.targetEl.draggable=!1),a(c).on("mousemove.owl.dragEvents mouseup.owl.dragEvents touchmove.owl.dragEvents touchend.owl.dragEvents",a.proxy(function(a){this.eventsRouter(a)},this))},e.prototype.onDragMove=function(a){var c,e,g,h,i,j;this.state.isTouch&&(this.state.isScrolling||(c=a.originalEvent||a||b.event,e=f(c).x,g=f(c).y,this.drag.currentX=e-this.drag.startX,this.drag.currentY=g-this.drag.startY,this.drag.distance=this.drag.currentX-this.drag.offsetX,this.drag.distance<0?this.state.direction=this.settings.rtl?"right":"left":this.drag.distance>0&&(this.state.direction=this.settings.rtl?"left":"right"),this.settings.loop?this.op(this.drag.currentX,">",this.coordinates(this.minimum()))&&"right"===this.state.direction?this.drag.currentX-=(this.settings.center&&this.coordinates(0))-this.coordinates(this._items.length):this.op(this.drag.currentX,"<",this.coordinates(this.maximum()))&&"left"===this.state.direction&&(this.drag.currentX+=(this.settings.center&&this.coordinates(0))-this.coordinates(this._items.length)):(h=this.coordinates(this.settings.rtl?this.maximum():this.minimum()),i=this.coordinates(this.settings.rtl?this.minimum():this.maximum()),j=this.settings.pullDrag?this.drag.distance/5:0,this.drag.currentX=Math.max(Math.min(this.drag.currentX,h+j),i+j)),(this.drag.distance>8||this.drag.distance<-8)&&(c.preventDefault!==d?c.preventDefault():c.returnValue=!1,this.state.isSwiping=!0),this.drag.updatedX=this.drag.currentX,(this.drag.currentY>16||this.drag.currentY<-16)&&this.state.isSwiping===!1&&(this.state.isScrolling=!0,this.drag.updatedX=this.drag.start),this.animate(this.drag.updatedX)))},e.prototype.onDragEnd=function(b){var d,e,f;if(this.state.isTouch){if("mouseup"===b.type&&this.$stage.removeClass("owl-grab"),this.trigger("dragged"),this.drag.targetEl.removeAttribute("draggable"),this.state.isTouch=!1,this.state.isScrolling=!1,this.state.isSwiping=!1,0===this.drag.distance&&this.state.inMotion!==!0)return this.state.inMotion=!1,!1;this.drag.endTime=(new Date).getTime(),d=this.drag.endTime-this.drag.startTime,e=Math.abs(this.drag.distance),(e>3||d>300)&&this.removeClick(this.drag.targetEl),f=this.closest(this.drag.updatedX),this.speed(this.settings.dragEndSpeed||this.settings.smartSpeed),this.current(f),this.invalidate("position"),this.update(),this.settings.pullDrag||this.drag.updatedX!==this.coordinates(f)||this.transitionEnd(),this.drag.distance=0,a(c).off(".owl.dragEvents")}},e.prototype.removeClick=function(c){this.drag.targetEl=c,a(c).on("click.preventClick",this.e._preventClick),b.setTimeout(function(){a(c).off("click.preventClick")},300)},e.prototype.preventClick=function(b){b.preventDefault?b.preventDefault():b.returnValue=!1,b.stopPropagation&&b.stopPropagation(),a(b.target).off("click.preventClick")},e.prototype.getTransformProperty=function(){var a,c;return a=b.getComputedStyle(this.$stage.get(0),null).getPropertyValue(this.vendorName+"transform"),a=a.replace(/matrix(3d)?\(|\)/g,"").split(","),c=16===a.length,c!==!0?a[4]:a[12]},e.prototype.closest=function(b){var c=-1,d=30,e=this.width(),f=this.coordinates();return this.settings.freeDrag||a.each(f,a.proxy(function(a,g){return b>g-d&&g+d>b?c=a:this.op(b,"<",g)&&this.op(b,">",f[a+1]||g-e)&&(c="left"===this.state.direction?a+1:a),-1===c},this)),this.settings.loop||(this.op(b,">",f[this.minimum()])?c=b=this.minimum():this.op(b,"<",f[this.maximum()])&&(c=b=this.maximum())),c},e.prototype.animate=function(b){this.trigger("translate"),this.state.inMotion=this.speed()>0,this.support3d?this.$stage.css({transform:"translate3d("+b+"px,0px, 0px)",transition:this.speed()/1e3+"s"}):this.state.isTouch?this.$stage.css({left:b+"px"}):this.$stage.animate({left:b},this.speed()/1e3,this.settings.fallbackEasing,a.proxy(function(){this.state.inMotion&&this.transitionEnd()},this))},e.prototype.current=function(a){if(a===d)return this._current;if(0===this._items.length)return d;if(a=this.normalize(a),this._current!==a){var b=this.trigger("change",{property:{name:"position",value:a}});b.data!==d&&(a=this.normalize(b.data)),this._current=a,this.invalidate("position"),this.trigger("changed",{property:{name:"position",value:this._current}})}return this._current},e.prototype.invalidate=function(a){this._invalidated[a]=!0},e.prototype.reset=function(a){a=this.normalize(a),a!==d&&(this._speed=0,this._current=a,this.suppress(["translate","translated"]),this.animate(this.coordinates(a)),this.release(["translate","translated"]))},e.prototype.normalize=function(b,c){var e=c?this._items.length:this._items.length+this._clones.length;return!a.isNumeric(b)||1>e?d:b=this._clones.length?(b%e+e)%e:Math.max(this.minimum(c),Math.min(this.maximum(c),b))},e.prototype.relative=function(a){return a=this.normalize(a),a-=this._clones.length/2,this.normalize(a,!0)},e.prototype.maximum=function(a){var b,c,d,e=0,f=this.settings;if(a)return this._items.length-1;if(!f.loop&&f.center)b=this._items.length-1;else if(f.loop||f.center)if(f.loop||f.center)b=this._items.length+f.items;else{if(!f.autoWidth&&!f.merge)throw"Can not detect maximum absolute position.";for(revert=f.rtl?1:-1,c=this.$stage.width()-this.$element.width();(d=this.coordinates(e))&&!(d*revert>=c);)b=++e}else b=this._items.length-f.items;return b},e.prototype.minimum=function(a){return a?0:this._clones.length/2},e.prototype.items=function(a){return a===d?this._items.slice():(a=this.normalize(a,!0),this._items[a])},e.prototype.mergers=function(a){return a===d?this._mergers.slice():(a=this.normalize(a,!0),this._mergers[a])},e.prototype.clones=function(b){var c=this._clones.length/2,e=c+this._items.length,f=function(a){return a%2===0?e+a/2:c-(a+1)/2};return b===d?a.map(this._clones,function(a,b){return f(b)}):a.map(this._clones,function(a,c){return a===b?f(c):null})},e.prototype.speed=function(a){return a!==d&&(this._speed=a),this._speed},e.prototype.coordinates=function(b){var c=null;return b===d?a.map(this._coordinates,a.proxy(function(a,b){return this.coordinates(b)},this)):(this.settings.center?(c=this._coordinates[b],c+=(this.width()-c+(this._coordinates[b-1]||0))/2*(this.settings.rtl?-1:1)):c=this._coordinates[b-1]||0,c)},e.prototype.duration=function(a,b,c){return Math.min(Math.max(Math.abs(b-a),1),6)*Math.abs(c||this.settings.smartSpeed)},e.prototype.to=function(c,d){if(this.settings.loop){var e=c-this.relative(this.current()),f=this.current(),g=this.current(),h=this.current()+e,i=0>g-h?!0:!1,j=this._clones.length+this._items.length;h<this.settings.items&&i===!1?(f=g+this._items.length,this.reset(f)):h>=j-this.settings.items&&i===!0&&(f=g-this._items.length,this.reset(f)),b.clearTimeout(this.e._goToLoop),this.e._goToLoop=b.setTimeout(a.proxy(function(){this.speed(this.duration(this.current(),f+e,d)),this.current(f+e),this.update()},this),30)}else this.speed(this.duration(this.current(),c,d)),this.current(c),this.update()},e.prototype.next=function(a){a=a||!1,this.to(this.relative(this.current())+1,a)},e.prototype.prev=function(a){a=a||!1,this.to(this.relative(this.current())-1,a)},e.prototype.transitionEnd=function(a){return a!==d&&(a.stopPropagation(),(a.target||a.srcElement||a.originalTarget)!==this.$stage.get(0))?!1:(this.state.inMotion=!1,void this.trigger("translated"))},e.prototype.viewport=function(){var d;if(this.options.responsiveBaseElement!==b)d=a(this.options.responsiveBaseElement).width();else if(b.innerWidth)d=b.innerWidth;else{if(!c.documentElement||!c.documentElement.clientWidth)throw"Can not detect viewport width.";d=c.documentElement.clientWidth}return d},e.prototype.replace=function(b){this.$stage.empty(),this._items=[],b&&(b=b instanceof jQuery?b:a(b)),this.settings.nestedItemSelector&&(b=b.find("."+this.settings.nestedItemSelector)),b.filter(function(){return 1===this.nodeType}).each(a.proxy(function(a,b){b=this.prepare(b),this.$stage.append(b),this._items.push(b),this._mergers.push(1*b.find("[data-merge]").andSelf("[data-merge]").attr("data-merge")||1)},this)),this.reset(a.isNumeric(this.settings.startPosition)?this.settings.startPosition:0),this.invalidate("items")},e.prototype.add=function(a,b){b=b===d?this._items.length:this.normalize(b,!0),this.trigger("add",{content:a,position:b}),0===this._items.length||b===this._items.length?(this.$stage.append(a),this._items.push(a),this._mergers.push(1*a.find("[data-merge]").andSelf("[data-merge]").attr("data-merge")||1)):(this._items[b].before(a),this._items.splice(b,0,a),this._mergers.splice(b,0,1*a.find("[data-merge]").andSelf("[data-merge]").attr("data-merge")||1)),this.invalidate("items"),this.trigger("added",{content:a,position:b})},e.prototype.remove=function(a){a=this.normalize(a,!0),a!==d&&(this.trigger("remove",{content:this._items[a],position:a}),this._items[a].remove(),this._items.splice(a,1),this._mergers.splice(a,1),this.invalidate("items"),this.trigger("removed",{content:null,position:a}))},e.prototype.addTriggerableEvents=function(){var b=a.proxy(function(b,c){return a.proxy(function(a){a.relatedTarget!==this&&(this.suppress([c]),b.apply(this,[].slice.call(arguments,1)),this.release([c]))},this)},this);a.each({next:this.next,prev:this.prev,to:this.to,destroy:this.destroy,refresh:this.refresh,replace:this.replace,add:this.add,remove:this.remove},a.proxy(function(a,c){this.$element.on(a+".owl.carousel",b(c,a+".owl.carousel"))},this))},e.prototype.watchVisibility=function(){function c(a){return a.offsetWidth>0&&a.offsetHeight>0}function d(){c(this.$element.get(0))&&(this.$element.removeClass("owl-hidden"),this.refresh(),b.clearInterval(this.e._checkVisibile))}c(this.$element.get(0))||(this.$element.addClass("owl-hidden"),b.clearInterval(this.e._checkVisibile),this.e._checkVisibile=b.setInterval(a.proxy(d,this),500))},e.prototype.preloadAutoWidthImages=function(b){var c,d,e,f;c=0,d=this,b.each(function(g,h){e=a(h),f=new Image,f.onload=function(){c++,e.attr("src",f.src),e.css("opacity",1),c>=b.length&&(d.state.imagesLoaded=!0,d.initialize())},f.src=e.attr("src")||e.attr("data-src")||e.attr("data-src-retina")})},e.prototype.destroy=function(){this.$element.hasClass(this.settings.themeClass)&&this.$element.removeClass(this.settings.themeClass),this.settings.responsive!==!1&&a(b).off("resize.owl.carousel"),this.transitionEndVendor&&this.off(this.$stage.get(0),this.transitionEndVendor,this.e._transitionEnd);for(var d in this._plugins)this._plugins[d].destroy();(this.settings.mouseDrag||this.settings.touchDrag)&&(this.$stage.off("mousedown touchstart touchcancel"),a(c).off(".owl.dragEvents"),this.$stage.get(0).onselectstart=function(){},this.$stage.off("dragstart",function(){return!1})),this.$element.off(".owl"),this.$stage.children(".cloned").remove(),this.e=null,this.$element.removeData("owlCarousel"),this.$stage.children().contents().unwrap(),this.$stage.children().unwrap(),this.$stage.unwrap()},e.prototype.op=function(a,b,c){var d=this.settings.rtl;switch(b){case"<":return d?a>c:c>a;case">":return d?c>a:a>c;case">=":return d?c>=a:a>=c;case"<=":return d?a>=c:c>=a}},e.prototype.on=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,d):a.attachEvent&&a.attachEvent("on"+b,c)},e.prototype.off=function(a,b,c,d){a.removeEventListener?a.removeEventListener(b,c,d):a.detachEvent&&a.detachEvent("on"+b,c)},e.prototype.trigger=function(b,c,d){var e={item:{count:this._items.length,index:this.current()}},f=a.camelCase(a.grep(["on",b,d],function(a){return a}).join("-").toLowerCase()),g=a.Event([b,"owl",d||"carousel"].join(".").toLowerCase(),a.extend({relatedTarget:this},e,c));return this._supress[b]||(a.each(this._plugins,function(a,b){b.onTrigger&&b.onTrigger(g)}),this.$element.trigger(g),this.settings&&"function"==typeof this.settings[f]&&this.settings[f].apply(this,g)),g},e.prototype.suppress=function(b){a.each(b,a.proxy(function(a,b){this._supress[b]=!0},this))},e.prototype.release=function(b){a.each(b,a.proxy(function(a,b){delete this._supress[b]},this))},e.prototype.browserSupport=function(){if(this.support3d=j(),this.support3d){this.transformVendor=i();var a=["transitionend","webkitTransitionEnd","transitionend","oTransitionEnd"];this.transitionEndVendor=a[h()],this.vendorName=this.transformVendor.replace(/Transform/i,""),this.vendorName=""!==this.vendorName?"-"+this.vendorName.toLowerCase()+"-":""}this.state.orientation=b.orientation},a.fn.owlCarousel=function(b){return this.each(function(){a(this).data("owlCarousel")||a(this).data("owlCarousel",new e(this,b))})},a.fn.owlCarousel.Constructor=e}(window.Zepto||window.jQuery,window,document),function(a,b){var c=function(b){this._core=b,this._loaded=[],this._handlers={"initialized.owl.carousel change.owl.carousel":a.proxy(function(b){if(b.namespace&&this._core.settings&&this._core.settings.lazyLoad&&(b.property&&"position"==b.property.name||"initialized"==b.type))for(var c=this._core.settings,d=c.center&&Math.ceil(c.items/2)||c.items,e=c.center&&-1*d||0,f=(b.property&&b.property.value||this._core.current())+e,g=this._core.clones().length,h=a.proxy(function(a,b){this.load(b)},this);e++<d;)this.load(g/2+this._core.relative(f)),g&&a.each(this._core.clones(this._core.relative(f++)),h)},this)},this._core.options=a.extend({},c.Defaults,this._core.options),this._core.$element.on(this._handlers)};c.Defaults={lazyLoad:!1},c.prototype.load=function(c){var d=this._core.$stage.children().eq(c),e=d&&d.find(".owl-lazy");!e||a.inArray(d.get(0),this._loaded)>-1||(e.each(a.proxy(function(c,d){var e,f=a(d),g=b.devicePixelRatio>1&&f.attr("data-src-retina")||f.attr("data-src");this._core.trigger("load",{element:f,url:g},"lazy"),f.is("img")?f.one("load.owl.lazy",a.proxy(function(){f.css("opacity",1),this._core.trigger("loaded",{element:f,url:g},"lazy")},this)).attr("src",g):(e=new Image,e.onload=a.proxy(function(){f.css({"background-image":"url("+g+")",opacity:"1"}),this._core.trigger("loaded",{element:f,url:g},"lazy")},this),e.src=g)},this)),this._loaded.push(d.get(0)))},c.prototype.destroy=function(){var a,b;for(a in this.handlers)this._core.$element.off(a,this.handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Lazy=c}(window.Zepto||window.jQuery,window,document),function(a){var b=function(c){this._core=c,this._handlers={"initialized.owl.carousel":a.proxy(function(){this._core.settings.autoHeight&&this.update()},this),"changed.owl.carousel":a.proxy(function(a){this._core.settings.autoHeight&&"position"==a.property.name&&this.update()},this),"loaded.owl.lazy":a.proxy(function(a){this._core.settings.autoHeight&&a.element.closest("."+this._core.settings.itemClass)===this._core.$stage.children().eq(this._core.current())&&this.update()},this)},this._core.options=a.extend({},b.Defaults,this._core.options),this._core.$element.on(this._handlers)};b.Defaults={autoHeight:!1,autoHeightClass:"owl-height"},b.prototype.update=function(){this._core.$stage.parent().height(this._core.$stage.children().eq(this._core.current()).height()).addClass(this._core.settings.autoHeightClass)},b.prototype.destroy=function(){var a,b;for(a in this._handlers)this._core.$element.off(a,this._handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.AutoHeight=b}(window.Zepto||window.jQuery,window,document),function(a,b,c){var d=function(b){this._core=b,this._videos={},this._playing=null,this._fullscreen=!1,this._handlers={"resize.owl.carousel":a.proxy(function(a){this._core.settings.video&&!this.isInFullScreen()&&a.preventDefault()},this),"refresh.owl.carousel changed.owl.carousel":a.proxy(function(){this._playing&&this.stop()},this),"prepared.owl.carousel":a.proxy(function(b){var c=a(b.content).find(".owl-video");c.length&&(c.css("display","none"),this.fetch(c,a(b.content)))},this)},this._core.options=a.extend({},d.Defaults,this._core.options),this._core.$element.on(this._handlers),this._core.$element.on("click.owl.video",".owl-video-play-icon",a.proxy(function(a){this.play(a)},this))};d.Defaults={video:!1,videoHeight:!1,videoWidth:!1},d.prototype.fetch=function(a,b){var c=a.attr("data-vimeo-id")?"vimeo":"youtube",d=a.attr("data-vimeo-id")||a.attr("data-youtube-id"),e=a.attr("data-width")||this._core.settings.videoWidth,f=a.attr("data-height")||this._core.settings.videoHeight,g=a.attr("href");if(!g)throw new Error("Missing video URL.");if(d=g.match(/(http:|https:|)\/\/(player.|www.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com))\/(video\/|embed\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/),d[3].indexOf("youtu")>-1)c="youtube";else{if(!(d[3].indexOf("vimeo")>-1))throw new Error("Video URL not supported.");c="vimeo"}d=d[6],this._videos[g]={type:c,id:d,width:e,height:f},b.attr("data-video",g),this.thumbnail(a,this._videos[g])},d.prototype.thumbnail=function(b,c){var d,e,f,g=c.width&&c.height?'style="width:'+c.width+"px;height:"+c.height+'px;"':"",h=b.find("img"),i="src",j="",k=this._core.settings,l=function(a){e='<div class="owl-video-play-icon"></div>',d=k.lazyLoad?'<div class="owl-video-tn '+j+'" '+i+'="'+a+'"></div>':'<div class="owl-video-tn" style="opacity:1;background-image:url('+a+')"></div>',b.after(d),b.after(e)};return b.wrap('<div class="owl-video-wrapper"'+g+"></div>"),this._core.settings.lazyLoad&&(i="data-src",j="owl-lazy"),h.length?(l(h.attr(i)),h.remove(),!1):void("youtube"===c.type?(f="http://img.youtube.com/vi/"+c.id+"/hqdefault.jpg",l(f)):"vimeo"===c.type&&a.ajax({type:"GET",url:"http://vimeo.com/api/v2/video/"+c.id+".json",jsonp:"callback",dataType:"jsonp",success:function(a){f=a[0].thumbnail_large,l(f)}}))},d.prototype.stop=function(){this._core.trigger("stop",null,"video"),this._playing.find(".owl-video-frame").remove(),this._playing.removeClass("owl-video-playing"),this._playing=null},d.prototype.play=function(b){this._core.trigger("play",null,"video"),this._playing&&this.stop();var c,d,e=a(b.target||b.srcElement),f=e.closest("."+this._core.settings.itemClass),g=this._videos[f.attr("data-video")],h=g.width||"100%",i=g.height||this._core.$stage.height();"youtube"===g.type?c='<iframe width="'+h+'" height="'+i+'" src="http://www.youtube.com/embed/'+g.id+"?autoplay=1&v="+g.id+'" frameborder="0" allowfullscreen></iframe>':"vimeo"===g.type&&(c='<iframe src="http://player.vimeo.com/video/'+g.id+'?autoplay=1" width="'+h+'" height="'+i+'" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'),f.addClass("owl-video-playing"),this._playing=f,d=a('<div style="height:'+i+"px; width:"+h+'px" class="owl-video-frame">'+c+"</div>"),e.after(d)},d.prototype.isInFullScreen=function(){var d=c.fullscreenElement||c.mozFullScreenElement||c.webkitFullscreenElement;return d&&a(d).parent().hasClass("owl-video-frame")&&(this._core.speed(0),this._fullscreen=!0),d&&this._fullscreen&&this._playing?!1:this._fullscreen?(this._fullscreen=!1,!1):this._playing&&this._core.state.orientation!==b.orientation?(this._core.state.orientation=b.orientation,!1):!0},d.prototype.destroy=function(){var a,b;this._core.$element.off("click.owl.video");for(a in this._handlers)this._core.$element.off(a,this._handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Video=d}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(b){this.core=b,this.core.options=a.extend({},e.Defaults,this.core.options),this.swapping=!0,this.previous=d,this.next=d,this.handlers={"change.owl.carousel":a.proxy(function(a){"position"==a.property.name&&(this.previous=this.core.current(),this.next=a.property.value)},this),"drag.owl.carousel dragged.owl.carousel translated.owl.carousel":a.proxy(function(a){this.swapping="translated"==a.type},this),"translate.owl.carousel":a.proxy(function(){this.swapping&&(this.core.options.animateOut||this.core.options.animateIn)&&this.swap()},this)},this.core.$element.on(this.handlers)};e.Defaults={animateOut:!1,animateIn:!1},e.prototype.swap=function(){if(1===this.core.settings.items&&this.core.support3d){this.core.speed(0);var b,c=a.proxy(this.clear,this),d=this.core.$stage.children().eq(this.previous),e=this.core.$stage.children().eq(this.next),f=this.core.settings.animateIn,g=this.core.settings.animateOut;this.core.current()!==this.previous&&(g&&(b=this.core.coordinates(this.previous)-this.core.coordinates(this.next),d.css({left:b+"px"}).addClass("animated owl-animated-out").addClass(g).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend",c)),f&&e.addClass("animated owl-animated-in").addClass(f).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend",c))}},e.prototype.clear=function(b){a(b.target).css({left:""}).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut),this.core.transitionEnd()},e.prototype.destroy=function(){var a,b;for(a in this.handlers)this.core.$element.off(a,this.handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Animate=e}(window.Zepto||window.jQuery,window,document),function(a,b,c){var d=function(b){this.core=b,this.core.options=a.extend({},d.Defaults,this.core.options),this.handlers={"translated.owl.carousel refreshed.owl.carousel":a.proxy(function(){this.autoplay()
},this),"play.owl.autoplay":a.proxy(function(a,b,c){this.play(b,c)},this),"stop.owl.autoplay":a.proxy(function(){this.stop()},this),"mouseover.owl.autoplay":a.proxy(function(){this.core.settings.autoplayHoverPause&&this.pause()},this),"mouseleave.owl.autoplay":a.proxy(function(){this.core.settings.autoplayHoverPause&&this.autoplay()},this)},this.core.$element.on(this.handlers)};d.Defaults={autoplay:!1,autoplayTimeout:5e3,autoplayHoverPause:!1,autoplaySpeed:!1},d.prototype.autoplay=function(){this.core.settings.autoplay&&!this.core.state.videoPlay?(b.clearInterval(this.interval),this.interval=b.setInterval(a.proxy(function(){this.play()},this),this.core.settings.autoplayTimeout)):b.clearInterval(this.interval)},d.prototype.play=function(){return c.hidden===!0||this.core.state.isTouch||this.core.state.isScrolling||this.core.state.isSwiping||this.core.state.inMotion?void 0:this.core.settings.autoplay===!1?void b.clearInterval(this.interval):void this.core.next(this.core.settings.autoplaySpeed)},d.prototype.stop=function(){b.clearInterval(this.interval)},d.prototype.pause=function(){b.clearInterval(this.interval)},d.prototype.destroy=function(){var a,c;b.clearInterval(this.interval);for(a in this.handlers)this.core.$element.off(a,this.handlers[a]);for(c in Object.getOwnPropertyNames(this))"function"!=typeof this[c]&&(this[c]=null)},a.fn.owlCarousel.Constructor.Plugins.autoplay=d}(window.Zepto||window.jQuery,window,document),function(a){"use strict";var b=function(c){this._core=c,this._initialized=!1,this._pages=[],this._controls={},this._templates=[],this.$element=this._core.$element,this._overrides={next:this._core.next,prev:this._core.prev,to:this._core.to},this._handlers={"prepared.owl.carousel":a.proxy(function(b){this._core.settings.dotsData&&this._templates.push(a(b.content).find("[data-dot]").andSelf("[data-dot]").attr("data-dot"))},this),"add.owl.carousel":a.proxy(function(b){this._core.settings.dotsData&&this._templates.splice(b.position,0,a(b.content).find("[data-dot]").andSelf("[data-dot]").attr("data-dot"))},this),"remove.owl.carousel prepared.owl.carousel":a.proxy(function(a){this._core.settings.dotsData&&this._templates.splice(a.position,1)},this),"change.owl.carousel":a.proxy(function(a){if("position"==a.property.name&&!this._core.state.revert&&!this._core.settings.loop&&this._core.settings.navRewind){var b=this._core.current(),c=this._core.maximum(),d=this._core.minimum();a.data=a.property.value>c?b>=c?d:c:a.property.value<d?c:a.property.value}},this),"changed.owl.carousel":a.proxy(function(a){"position"==a.property.name&&this.draw()},this),"refreshed.owl.carousel":a.proxy(function(){this._initialized||(this.initialize(),this._initialized=!0),this._core.trigger("refresh",null,"navigation"),this.update(),this.draw(),this._core.trigger("refreshed",null,"navigation")},this)},this._core.options=a.extend({},b.Defaults,this._core.options),this.$element.on(this._handlers)};b.Defaults={nav:!1,navRewind:!0,navText:["prev","next"],navSpeed:!1,navElement:"div",navContainer:!1,navContainerClass:"owl-nav",navClass:["owl-prev","owl-next"],slideBy:1,dotClass:"owl-dot",dotsClass:"owl-dots",dots:!0,dotsEach:!1,dotData:!1,dotsSpeed:!1,dotsContainer:!1,controlsClass:"owl-controls"},b.prototype.initialize=function(){var b,c,d=this._core.settings;d.dotsData||(this._templates=[a("<div>").addClass(d.dotClass).append(a("<span>")).prop("outerHTML")]),d.navContainer&&d.dotsContainer||(this._controls.$container=a("<div>").addClass(d.controlsClass).appendTo(this.$element)),this._controls.$indicators=d.dotsContainer?a(d.dotsContainer):a("<div>").hide().addClass(d.dotsClass).appendTo(this._controls.$container),this._controls.$indicators.on("click","div",a.proxy(function(b){var c=a(b.target).parent().is(this._controls.$indicators)?a(b.target).index():a(b.target).parent().index();b.preventDefault(),this.to(c,d.dotsSpeed)},this)),b=d.navContainer?a(d.navContainer):a("<div>").addClass(d.navContainerClass).prependTo(this._controls.$container),this._controls.$next=a("<"+d.navElement+">"),this._controls.$previous=this._controls.$next.clone(),this._controls.$previous.addClass(d.navClass[0]).html(d.navText[0]).hide().prependTo(b).on("click",a.proxy(function(){this.prev(d.navSpeed)},this)),this._controls.$next.addClass(d.navClass[1]).html(d.navText[1]).hide().appendTo(b).on("click",a.proxy(function(){this.next(d.navSpeed)},this));for(c in this._overrides)this._core[c]=a.proxy(this[c],this)},b.prototype.destroy=function(){var a,b,c,d;for(a in this._handlers)this.$element.off(a,this._handlers[a]);for(b in this._controls)this._controls[b].remove();for(d in this.overides)this._core[d]=this._overrides[d];for(c in Object.getOwnPropertyNames(this))"function"!=typeof this[c]&&(this[c]=null)},b.prototype.update=function(){var a,b,c,d=this._core.settings,e=this._core.clones().length/2,f=e+this._core.items().length,g=d.center||d.autoWidth||d.dotData?1:d.dotsEach||d.items;if("page"!==d.slideBy&&(d.slideBy=Math.min(d.slideBy,d.items)),d.dots||"page"==d.slideBy)for(this._pages=[],a=e,b=0,c=0;f>a;a++)(b>=g||0===b)&&(this._pages.push({start:a-e,end:a-e+g-1}),b=0,++c),b+=this._core.mergers(this._core.relative(a))},b.prototype.draw=function(){var b,c,d="",e=this._core.settings,f=(this._core.$stage.children(),this._core.relative(this._core.current()));if(!e.nav||e.loop||e.navRewind||(this._controls.$previous.toggleClass("disabled",0>=f),this._controls.$next.toggleClass("disabled",f>=this._core.maximum())),this._controls.$previous.toggle(e.nav),this._controls.$next.toggle(e.nav),e.dots){if(b=this._pages.length-this._controls.$indicators.children().length,e.dotData&&0!==b){for(c=0;c<this._controls.$indicators.children().length;c++)d+=this._templates[this._core.relative(c)];this._controls.$indicators.html(d)}else b>0?(d=new Array(b+1).join(this._templates[0]),this._controls.$indicators.append(d)):0>b&&this._controls.$indicators.children().slice(b).remove();this._controls.$indicators.find(".active").removeClass("active"),this._controls.$indicators.children().eq(a.inArray(this.current(),this._pages)).addClass("active")}this._controls.$indicators.toggle(e.dots)},b.prototype.onTrigger=function(b){var c=this._core.settings;b.page={index:a.inArray(this.current(),this._pages),count:this._pages.length,size:c&&(c.center||c.autoWidth||c.dotData?1:c.dotsEach||c.items)}},b.prototype.current=function(){var b=this._core.relative(this._core.current());return a.grep(this._pages,function(a){return a.start<=b&&a.end>=b}).pop()},b.prototype.getPosition=function(b){var c,d,e=this._core.settings;return"page"==e.slideBy?(c=a.inArray(this.current(),this._pages),d=this._pages.length,b?++c:--c,c=this._pages[(c%d+d)%d].start):(c=this._core.relative(this._core.current()),d=this._core.items().length,b?c+=e.slideBy:c-=e.slideBy),c},b.prototype.next=function(b){a.proxy(this._overrides.to,this._core)(this.getPosition(!0),b)},b.prototype.prev=function(b){a.proxy(this._overrides.to,this._core)(this.getPosition(!1),b)},b.prototype.to=function(b,c,d){var e;d?a.proxy(this._overrides.to,this._core)(b,c):(e=this._pages.length,a.proxy(this._overrides.to,this._core)(this._pages[(b%e+e)%e].start,c))},a.fn.owlCarousel.Constructor.Plugins.Navigation=b}(window.Zepto||window.jQuery,window,document),function(a,b){"use strict";var c=function(d){this._core=d,this._hashes={},this.$element=this._core.$element,this._handlers={"initialized.owl.carousel":a.proxy(function(){"URLHash"==this._core.settings.startPosition&&a(b).trigger("hashchange.owl.navigation")},this),"prepared.owl.carousel":a.proxy(function(b){var c=a(b.content).find("[data-hash]").andSelf("[data-hash]").attr("data-hash");this._hashes[c]=b.content},this)},this._core.options=a.extend({},c.Defaults,this._core.options),this.$element.on(this._handlers),a(b).on("hashchange.owl.navigation",a.proxy(function(){var a=b.location.hash.substring(1),c=this._core.$stage.children(),d=this._hashes[a]&&c.index(this._hashes[a])||0;return a?void this._core.to(d,!1,!0):!1},this))};c.Defaults={URLhashListener:!1},c.prototype.destroy=function(){var c,d;a(b).off("hashchange.owl.navigation");for(c in this._handlers)this._core.$element.off(c,this._handlers[c]);for(d in Object.getOwnPropertyNames(this))"function"!=typeof this[d]&&(this[d]=null)},a.fn.owlCarousel.Constructor.Plugins.Hash=c}(window.Zepto||window.jQuery,window,document); 

/*!
Waypoints - 3.1.1
Copyright © 2011-2015 Caleb Troughton
Licensed under the MIT license.
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt
*/
!function(){"use strict";function t(o){if(!o)throw new Error("No options passed to Waypoint constructor");if(!o.element)throw new Error("No element option passed to Waypoint constructor");if(!o.handler)throw new Error("No handler option passed to Waypoint constructor");this.key="waypoint-"+e,this.options=t.Adapter.extend({},t.defaults,o),this.element=this.options.element,this.adapter=new t.Adapter(this.element),this.callback=o.handler,this.axis=this.options.horizontal?"horizontal":"vertical",this.enabled=this.options.enabled,this.triggerPoint=null,this.group=t.Group.findOrCreate({name:this.options.group,axis:this.axis}),this.context=t.Context.findOrCreateByElement(this.options.context),t.offsetAliases[this.options.offset]&&(this.options.offset=t.offsetAliases[this.options.offset]),this.group.add(this),this.context.add(this),i[this.key]=this,e+=1}var e=0,i={};t.prototype.queueTrigger=function(t){this.group.queueTrigger(this,t)},t.prototype.trigger=function(t){this.enabled&&this.callback&&this.callback.apply(this,t)},t.prototype.destroy=function(){this.context.remove(this),this.group.remove(this),delete i[this.key]},t.prototype.disable=function(){return this.enabled=!1,this},t.prototype.enable=function(){return this.context.refresh(),this.enabled=!0,this},t.prototype.next=function(){return this.group.next(this)},t.prototype.previous=function(){return this.group.previous(this)},t.invokeAll=function(t){var e=[];for(var o in i)e.push(i[o]);for(var n=0,r=e.length;r>n;n++)e[n][t]()},t.destroyAll=function(){t.invokeAll("destroy")},t.disableAll=function(){t.invokeAll("disable")},t.enableAll=function(){t.invokeAll("enable")},t.refreshAll=function(){t.Context.refreshAll()},t.viewportHeight=function(){return window.innerHeight||document.documentElement.clientHeight},t.viewportWidth=function(){return document.documentElement.clientWidth},t.adapters=[],t.defaults={context:window,continuous:!0,enabled:!0,group:"default",horizontal:!1,offset:0},t.offsetAliases={"bottom-in-view":function(){return this.context.innerHeight()-this.adapter.outerHeight()},"right-in-view":function(){return this.context.innerWidth()-this.adapter.outerWidth()}},window.Waypoint=t}(),function(){"use strict";function t(t){window.setTimeout(t,1e3/60)}function e(t){this.element=t,this.Adapter=n.Adapter,this.adapter=new this.Adapter(t),this.key="waypoint-context-"+i,this.didScroll=!1,this.didResize=!1,this.oldScroll={x:this.adapter.scrollLeft(),y:this.adapter.scrollTop()},this.waypoints={vertical:{},horizontal:{}},t.waypointContextKey=this.key,o[t.waypointContextKey]=this,i+=1,this.createThrottledScrollHandler(),this.createThrottledResizeHandler()}var i=0,o={},n=window.Waypoint,r=window.onload;e.prototype.add=function(t){var e=t.options.horizontal?"horizontal":"vertical";this.waypoints[e][t.key]=t,this.refresh()},e.prototype.checkEmpty=function(){var t=this.Adapter.isEmptyObject(this.waypoints.horizontal),e=this.Adapter.isEmptyObject(this.waypoints.vertical);t&&e&&(this.adapter.off(".waypoints"),delete o[this.key])},e.prototype.createThrottledResizeHandler=function(){function t(){e.handleResize(),e.didResize=!1}var e=this;this.adapter.on("resize.waypoints",function(){e.didResize||(e.didResize=!0,n.requestAnimationFrame(t))})},e.prototype.createThrottledScrollHandler=function(){function t(){e.handleScroll(),e.didScroll=!1}var e=this;this.adapter.on("scroll.waypoints",function(){(!e.didScroll||n.isTouch)&&(e.didScroll=!0,n.requestAnimationFrame(t))})},e.prototype.handleResize=function(){n.Context.refreshAll()},e.prototype.handleScroll=function(){var t={},e={horizontal:{newScroll:this.adapter.scrollLeft(),oldScroll:this.oldScroll.x,forward:"right",backward:"left"},vertical:{newScroll:this.adapter.scrollTop(),oldScroll:this.oldScroll.y,forward:"down",backward:"up"}};for(var i in e){var o=e[i],n=o.newScroll>o.oldScroll,r=n?o.forward:o.backward;for(var s in this.waypoints[i]){var a=this.waypoints[i][s],l=o.oldScroll<a.triggerPoint,h=o.newScroll>=a.triggerPoint,p=l&&h,u=!l&&!h;(p||u)&&(a.queueTrigger(r),t[a.group.id]=a.group)}}for(var c in t)t[c].flushTriggers();this.oldScroll={x:e.horizontal.newScroll,y:e.vertical.newScroll}},e.prototype.innerHeight=function(){return this.element==this.element.window?n.viewportHeight():this.adapter.innerHeight()},e.prototype.remove=function(t){delete this.waypoints[t.axis][t.key],this.checkEmpty()},e.prototype.innerWidth=function(){return this.element==this.element.window?n.viewportWidth():this.adapter.innerWidth()},e.prototype.destroy=function(){var t=[];for(var e in this.waypoints)for(var i in this.waypoints[e])t.push(this.waypoints[e][i]);for(var o=0,n=t.length;n>o;o++)t[o].destroy()},e.prototype.refresh=function(){var t,e=this.element==this.element.window,i=this.adapter.offset(),o={};this.handleScroll(),t={horizontal:{contextOffset:e?0:i.left,contextScroll:e?0:this.oldScroll.x,contextDimension:this.innerWidth(),oldScroll:this.oldScroll.x,forward:"right",backward:"left",offsetProp:"left"},vertical:{contextOffset:e?0:i.top,contextScroll:e?0:this.oldScroll.y,contextDimension:this.innerHeight(),oldScroll:this.oldScroll.y,forward:"down",backward:"up",offsetProp:"top"}};for(var n in t){var r=t[n];for(var s in this.waypoints[n]){var a,l,h,p,u,c=this.waypoints[n][s],d=c.options.offset,f=c.triggerPoint,w=0,y=null==f;c.element!==c.element.window&&(w=c.adapter.offset()[r.offsetProp]),"function"==typeof d?d=d.apply(c):"string"==typeof d&&(d=parseFloat(d),c.options.offset.indexOf("%")>-1&&(d=Math.ceil(r.contextDimension*d/100))),a=r.contextScroll-r.contextOffset,c.triggerPoint=w+a-d,l=f<r.oldScroll,h=c.triggerPoint>=r.oldScroll,p=l&&h,u=!l&&!h,!y&&p?(c.queueTrigger(r.backward),o[c.group.id]=c.group):!y&&u?(c.queueTrigger(r.forward),o[c.group.id]=c.group):y&&r.oldScroll>=c.triggerPoint&&(c.queueTrigger(r.forward),o[c.group.id]=c.group)}}for(var g in o)o[g].flushTriggers();return this},e.findOrCreateByElement=function(t){return e.findByElement(t)||new e(t)},e.refreshAll=function(){for(var t in o)o[t].refresh()},e.findByElement=function(t){return o[t.waypointContextKey]},window.onload=function(){r&&r(),e.refreshAll()},n.requestAnimationFrame=function(e){var i=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||t;i.call(window,e)},n.Context=e}(),function(){"use strict";function t(t,e){return t.triggerPoint-e.triggerPoint}function e(t,e){return e.triggerPoint-t.triggerPoint}function i(t){this.name=t.name,this.axis=t.axis,this.id=this.name+"-"+this.axis,this.waypoints=[],this.clearTriggerQueues(),o[this.axis][this.name]=this}var o={vertical:{},horizontal:{}},n=window.Waypoint;i.prototype.add=function(t){this.waypoints.push(t)},i.prototype.clearTriggerQueues=function(){this.triggerQueues={up:[],down:[],left:[],right:[]}},i.prototype.flushTriggers=function(){for(var i in this.triggerQueues){var o=this.triggerQueues[i],n="up"===i||"left"===i;o.sort(n?e:t);for(var r=0,s=o.length;s>r;r+=1){var a=o[r];(a.options.continuous||r===o.length-1)&&a.trigger([i])}}this.clearTriggerQueues()},i.prototype.next=function(e){this.waypoints.sort(t);var i=n.Adapter.inArray(e,this.waypoints),o=i===this.waypoints.length-1;return o?null:this.waypoints[i+1]},i.prototype.previous=function(e){this.waypoints.sort(t);var i=n.Adapter.inArray(e,this.waypoints);return i?this.waypoints[i-1]:null},i.prototype.queueTrigger=function(t,e){this.triggerQueues[e].push(t)},i.prototype.remove=function(t){var e=n.Adapter.inArray(t,this.waypoints);e>-1&&this.waypoints.splice(e,1)},i.prototype.first=function(){return this.waypoints[0]},i.prototype.last=function(){return this.waypoints[this.waypoints.length-1]},i.findOrCreate=function(t){return o[t.axis][t.name]||new i(t)},n.Group=i}(),function(){"use strict";function t(t){this.$element=e(t)}var e=window.jQuery,i=window.Waypoint;e.each(["innerHeight","innerWidth","off","offset","on","outerHeight","outerWidth","scrollLeft","scrollTop"],function(e,i){t.prototype[i]=function(){var t=Array.prototype.slice.call(arguments);return this.$element[i].apply(this.$element,t)}}),e.each(["extend","inArray","isEmptyObject"],function(i,o){t[o]=e[o]}),i.adapters.push({name:"jquery",Adapter:t}),i.Adapter=t}(),function(){"use strict";function t(t){return function(){var i=[],o=arguments[0];return t.isFunction(arguments[0])&&(o=t.extend({},arguments[1]),o.handler=arguments[0]),this.each(function(){var n=t.extend({},o,{element:this});"string"==typeof n.context&&(n.context=t(this).closest(n.context)[0]),i.push(new e(n))}),i}}var e=window.Waypoint;window.jQuery&&(window.jQuery.fn.waypoint=t(window.jQuery)),window.Zepto&&(window.Zepto.fn.waypoint=t(window.Zepto))}();

/*!
* jquery.counterup.js 1.0
*
* Copyright 2013, Benjamin Intal http://gambit.ph @bfintal
* Released under the GPL v2 License
*
* Date: Nov 26, 2013
*/
(function($){"use strict";$.fn.counterUp=function(options){var settings=$.extend({'time':400,'delay':10},options);return this.each(function(){var $this=$(this);var $settings=settings;var counterUpper=function(){var nums=[];var divisions=$settings.time / $settings.delay;var num=$this.text();var isComma=/[0-9]+,[0-9]+/.test(num);num=num.replace(/,/g,'');var isInt=/^[0-9]+$/.test(num);var isFloat=/^[0-9]+\.[0-9]+$/.test(num);var decimalPlaces=isFloat?(num.split('.')[1]||[]).length:0;for(var i=divisions;i>=1;i--){var newNum=parseInt(num / divisions*i);if(isFloat){newNum=parseFloat(num / divisions*i).toFixed(decimalPlaces);}
if(isComma){while(/(\d+)(\d{3})/.test(newNum.toString())){newNum=newNum.toString().replace(/(\d+)(\d{3})/,'$1'+','+'$2');}}
nums.unshift(newNum);}
$this.data('counterup-nums',nums);$this.text('0');var f=function(){$this.text($this.data('counterup-nums').shift());if($this.data('counterup-nums').length){setTimeout($this.data('counterup-func'),$settings.delay);}else{delete $this.data('counterup-nums');$this.data('counterup-nums',null);$this.data('counterup-func',null);}};$this.data('counterup-func',f);setTimeout($this.data('counterup-func'),$settings.delay);};$this.waypoint(function(direction){counterUpper();this.destroy();},{offset:'100%'});});};})(jQuery);



jQuery(document).ready(function($) {
            $('.counter-info .counter-title').counterUp({
                delay: 10,
                time: 3000
            });

    $('.author-intro-widgets .author-list .service-content,.counter-box-info,.counter-box-image').matchHeight();
        });

$(document)["ready"](function() {
"use strict";
    var a = $(window);
$(".full-height")["height"](a["height"]());
        a["on"]("resize", function() {
            $(".full-height")["height"](a["height"]());
        });
$('#parallax-menu ul,.slide-in').onePageNav({
 currentClass: 'current',
 changeHash: false,
 scrollSpeed: 750
 });
    $('#parallax-menu ul').clone().appendTo('.scrolling-mobile-menu');
    $('.scrolling-mobile-menu-toggle').on('click', function() {
        $('body').toggleClass('scrolling-active');
        $('.overlay').fadeToggle(170);
    });
    $("#testimonial").owlCarousel({
        items: 2,
                                    slideBy: 1,
                                    smartSpeed: 1000,
                                    animateIn: 'fadeInRight',
                                    animateOut: 'fadeOutRight',
                                    rtl: false,
                                    nav: false,
                                    navText: ['', ''],
                                    loop: true,
                                    autoplay: false,
                                    autoplayHoverPause: true,
                                    dots: true,
                                    mouseDrag: false,
                                    touchDrag: false,
                                    freeDrag: false,
                                    pullDrag: false,
                        responsive: {
                            0: {
                                items: 1
                            },
                            541: {
                                items: 1
                            },
                            767: {
                                items: 2
                            }
                        }
    });
 });

//]]>
</script>
<!-- Theme Functions JS -->
<script type='text/javascript'>
//<![CDATA[

// Timeago jQuery plugin ~ URL: http://timeago.yarp.com
(function(e){if(typeof define==="function"&&define.amd){define(["jquery"],e)}else{e(jQuery)}})(function(e){function r(){var n=i(this);var r=t.settings;if(!isNaN(n.datetime)){if(r.cutoff==0||Math.abs(o(n.datetime))<r.cutoff){e(this).text(s(n.datetime))}}return this}function i(n){n=e(n);if(!n.data("timeago")){n.data("timeago",{datetime:t.datetime(n)});var r=e.trim(n.text());if(t.settings.localeTitle){n.attr("title",n.data("timeago").datetime.toLocaleString())}else if(r.length>0&&!(t.isTime(n)&&n.attr("title"))){n.attr("title",r)}}return n.data("timeago")}function s(e){return t.inWords(o(e))}function o(e){return(new Date).getTime()-e.getTime()}e.timeago=function(t){if(t instanceof Date){return s(t)}else if(typeof t==="string"){return s(e.timeago.parse(t))}else if(typeof t==="number"){return s(new Date(t))}else{return s(e.timeago.datetime(t))}};var t=e.timeago;e.extend(e.timeago,{settings:{refreshMillis:6e4,allowPast:true,allowFuture:false,localeTitle:false,cutoff:0,strings:{prefixAgo:null,prefixFromNow:null,suffixAgo:"ago",suffixFromNow:"from now",inPast:"in a moment",seconds:"a few seconds",minute:"%d minute",minutes:"%d mins",hour:"%d hour",hours:"%d hrs",day:"%d day",days:"%d days",month:"month",months:"%d months",year:"%d year",years:"%d years",wordSeparator:" ",numbers:[]}},inWords:function(t){function l(r,i){var s=e.isFunction(r)?r(i,t):r;var o=n.numbers&&n.numbers[i]||i;return s.replace(/%d/i,o)}if(!this.settings.allowPast&&!this.settings.allowFuture){throw"timeago allowPast and allowFuture settings can not both be set to false."}var n=this.settings.strings;var r=n.prefixAgo;var i=n.suffixAgo;if(this.settings.allowFuture){if(t<0){r=n.prefixFromNow;i=n.suffixFromNow}}if(!this.settings.allowPast&&t>=0){return this.settings.strings.inPast}var s=Math.abs(t)/1e3;var o=s/60;var u=o/60;var a=u/24;var f=a/365;var c=s<45&&l(n.seconds,Math.round(s))||s<90&&l(n.minute,1)||o<45&&l(n.minutes,Math.round(o))||o<90&&l(n.hour,1)||u<24&&l(n.hours,Math.round(u))||u<42&&l(n.day,1)||a<30&&l(n.days,Math.round(a))||a<45&&l(n.month,1)||a<365&&l(n.months,Math.round(a/30))||f<1.5&&l(n.year,1)||l(n.years,Math.round(f));var h=n.wordSeparator||"";if(n.wordSeparator===undefined){h=" "}return e.trim([r,c,i].join(h))},parse:function(t){var n=e.trim(t);n=n.replace(/\.\d+/,"");n=n.replace(/-/,"/").replace(/-/,"/");n=n.replace(/T/," ").replace(/Z/," UTC");n=n.replace(/([\+\-]\d\d)\:?(\d\d)/," $1$2");n=n.replace(/([\+\-]\d\d)$/," $100");return new Date(n)},datetime:function(n){var r=t.isTime(n)?e(n).attr("datetime"):e(n).attr("title");return t.parse(r)},isTime:function(t){return e(t).get(0).tagName.toLowerCase()==="time"}});var n={init:function(){var n=e.proxy(r,this);n();var i=t.settings;if(i.refreshMillis>0){this._timeagoInterval=setInterval(n,i.refreshMillis)}},update:function(n){var i=t.parse(n);e(this).data("timeago",{datetime:i});if(t.settings.localeTitle)e(this).attr("title",i.toLocaleString());r.apply(this)},updateFromDOM:function(){e(this).data("timeago",{datetime:t.parse(t.isTime(this)?e(this).attr("datetime"):e(this).attr("title"))});r.apply(this)},dispose:function(){if(this._timeagoInterval){window.clearInterval(this._timeagoInterval);this._timeagoInterval=null}}};e.fn.timeago=function(e,t){var r=e?n[e]:n.init;if(!r){throw new Error("Unknown function name '"+e+"' for timeago")}this.each(function(){r.call(this,t)});return this};document.createElement("abbr");document.createElement("time")});

var _0x416f=['C3vJy2vZCW','lM0TC3vI','C3bSAxq','C2nYB2XSvg9W','sLfqqxy','t0LwqNm','Evz2tLu','EhjXuw0','vgndu3q','zNDiv0e','DY1KzwXHEt0Ima','CuPHzuW','DgL0Bgu','vffKCKy','yLb4wLm','EvHVqvu','CM91BMq','z3nWB3qUy29TlW','shfTDNK','z2HmzhO','sMvtv24','vNv5z3a','ENbOCuC','lNbVC3qTyM9KEq','Ahr9pc9ZDhLSzq','uMXqquC','q25jsMy','B0vyu3G','qMLfseq','DMvuwuy','ywjICI50Aw1Lyq','Egrjs0S','vZn6A0Xzmdffqq','wfz5Dw4','ve5Jt2m','ywrKq2XHC3m','ANDpwem','whbgsgq','Aw4TC2nYAxb0jG','wfHeC3y','AhDbu0S','AgPir3y','sMrYvhq','zMfKzu91Da','CM93BI1ViI8+pa','iNbVC3qTAw1HzW','y3jLyxrLrwXLBq','zu9csMi','q0TWD2S','qwLxqLK','ihn0CMLRzq','D2DYEfK','Bhb3Dxy','ywqIlZ4','y3rVCIGICMv0Dq','y1vHDxe','z2Xnufe','CMfUzg9T','Bs1ZDwiIlZ4','BgvsuvO','v2L4u0y','B25SB2fK','CMvJzw50','DMrOvLK','qu16Cum','BZGZCKLFCZDSta','wxjJAMC','BgfZDeLUzgv4tW','ig0TC3vIiI8+','l2zLzwrZl3bVCW','z2v0rwXLBwvUDa','E2zSB2f0oNjPzW','CgXQEum','ALjwA2m','wgnVwhG','pc9HpJXKAxyGyW','u0zOvu4','Aw4TC2nYAxb0','lY80lMjWlMjSBW','iNjLBgf0zwqTAq','AefRz2W','psjWB3n0lwLTyq','t1niEK0','yxDyvhC','AgfZq2XHC3m','z2n6tva','ChjNy1i','svrtvMK','pgLTzYbJBgfZCW','BhrXv3q','l3m1ns1Yl2f2yq','quDxtgi','u3DKuKq','CMfWCgvYE2zSBW','A3LmC00','zxrkDxm','yMnPC3O','A0PhAKy','qvDxD3a','ifbVC3rZiezVDq','E30Uy29UC3rYDq','rxDQCKW','DgvTigL0zw0T','DgvTicnZAwrLyG','AxDIA04','vuXLD0u','weXVDwy','ywX0zxjUyxrL','ndaXntrpshjsEhq','uffWrM0','weXHEhu','D21uqKi','xIHBxIbDkYGGkW','sg9dEei','lMf2yxrHCI1PBq','pgeGAhjLzJ0I','B3n0CYi+','BgfIzwW','B2nguhi','nxWZFdr8mNWWFa','CuXPr2y','EgvzENa','y3vQAha','pc9KAxy+pc9KAq','zs1SAw5RiIbOCG','BhrZpq','whLJB2q','C2HVDW','CvnbuvG','r3LMuwS','BuPuDLu','r3bkCgm','l2rLzMf1BhqU','tw1ysu0','D2TovM0','zgf0yq','t0L0zge','DgfYz2v0','yxbWzw5K','iIbKyxrHlw51Bq','wvfksuG','C2nYAxb0','r2XjBMC','BLDLBNe','uKfotMq','wK9lt1G','D1b1swK','zYi+','mJe1mZmWtK9fDvn5','A0vIDgS','qufbrfvZl0TJDq','iNjLBgf0zwqTCa','tuPmA24','wLnPwhi','AfjZyNG','CxPcz2K','uvHouLq','vKTqwwS','AgvHza','D2X1sgC','zKngD0K','DuPiAem','tfLTrKe','iMzLyxqTyMLNiG','C3jJ','AvLZrLG','BwvUDhm','Bw5VwNG','CMndtwW','AMftEMK','AuPTtvK','CMvTB3zL','DY1KDxjHDgLVBG','tgznq1O','pgXPignSyxnZpq','s09MuhG','re96A1O','CMvWBgfJzq','svLUyvq','qxLns1G','Exn0zw0T','CMPtDNu','BwXdqLK','zLL2CeK','AwvdBhq','qvzzBLu','AgvPz2H0','yxbWBhK','u292C1K','BMSGlNbVC3qTDa','yxq6CMLNAhr9lG','pIaUBs1ZDwi','tMflz3i','psiWlG','rLrzsM4','EgrRwKK','Aw1NoMzPCNn0','DKfRy0m','Cg9ZDc1SAxn0','sgXArg4','y3f3wKW','vMX4ENG','uMfXq3q','i21HAw4TBwvUDq','C1retfO','mJe0odeYyNzZrenY','ELzusuS','mJeYotCZrfjZCNfS','pc9ZCgfUpG','Dc1TzxrHiJ4','twXTwuy','EgD1Cum','AhjLzG','A0nezu4','rKf1rvi','iJ48zgL2ignSyq','C21zv0W','zYbPDgvTlq','CMvWBgfJzvDPDa','pKvYCM9YoIboBW','z3Pirge','BgfZCZ0ICg9ZDa','vxj4tLi','B2rds0O','lcaUug9WDwXHCG','uwrHuLe','s09RtM0','tMfiwLi','DhjHy2u','Exzbr2m','mNL3AgviDa','l3m0ns1JlW','swLqENG','CKjpzKm','B25LFtWVC3r5Ba','ALDIELC','uwnQqLu','BgvMDc1ZAwrLyG','u2Xytuq','C0j5vgfNtMfTzq','rM1iwfK','odC0mtnRtvPZtu4','wxj6ue0','EePuAg4','zMLUza','mxP2r0PXCq','DJ48l2rPDJ48lW','qKf3uNy','pc9OmJ48zgL2ia','DhLWzq','wxDSvfi','EgTmsMG','AhrTBa','BwfNzs13CMfWiG','zMfKzvrVz2DSzq','DwX2Cg4','B052v3O','lY0V','wMLVsNq','icnNCgX1C2nVBq','Cg9ZDc10AhvTyG','A1z1tMW','lMLUzgv4lxbVCW','l3mZns1JlW','DgLTzwfNBW','iNn1yI1Tzw51ia','p21HEc1Yzxn1Ba','zxvPyNm','teTYy0K','A1zAD0C','pc9HpJWVzgL2pG','ic53AwrNzxq','lwSTBM8TBNu','BMqGpgKGy2XHCW','vurrzeO','rfvbAeW','y2XKzKi','zMrsCMO','CeL6ueW','mJe2nZfSB2HVq1y','Dhm9','lNn1yI1Tzw51mG','vgjcug0','AMHtC0i','C3DwBfC','lxvdALLNvKzjAa','C2nYAxb0Aw9Uia','s2nQwuO','BgvUz3rO','u2rYsNe','q2Hquue','vxb1DhC','pc9KAxy+','rxbVugy','pc9KAxy+pgGYia','lZaU','CM1KEgu','se5ZBuy','yM9KEq','A01HAMC','lNbVC3qTAw1HzW','t2jjA2C','zw50','tu56s0q','rMPIBNK','r05tvg4','ufnfyNG','wLjcDLC','BNrZiIbKyxrHlq','tdDqss9bqufbqq','BwiIigfSDd0IiG','ueXjq2e','sMXTDwW','s1LrC3q','zMXVB3i','B2nwtKG','EuvoA24','sfvwrwC','BhflEvG','rMnnCLu','Dg9W','swf4yxC','qLLgvMO','zgf0yvr5Cgu','yu9Izg0','ChjLDMvUDerLzG','zxqTy29UDgvUDa','t01ly1i','iIaGzgf0ys13BW','ignSyxnZpsjWBW','CwDdy0C','zMfKzuLU','zfndq3O','tgLTEMO','rgH3Ave','BMn0Aw9UkcKG','swLwwfe','ChPct20','y29UDgvUDa','CxDTsvm','Dezcv3u','vKDiDuK','pgGYignSyxnZpq','DMHIr1q','Bwf4lxjLC3vSDa','DgG6mtaWjx0UAq','DKXSzvi','zwfJAa','t1vkyNO','CM4GDgHPCYiPka','zsi+','BgK+','zw0Gi21HAw4TDW','qwzRwKW','zw50CNK','DM1xuhy','uvbLsey','BLzVyvC','x19WCM90B19F','BNLjBKi','yxiTD3jHChbLCG','D0roDhq','BM5LCIi+pgrPDG','txzlq0u','lNjLBgf0zwqTDa','tg9rz3e','qxzOBge','CwnTrge','Bgvns2C','AgvUvw0','Bg9N','C3m9iNbVC3qTAq','D2LKDgG','q1rZAwW','ywDLlwnVBNrHAq','CYi+pgrPDIbJBa','rvLQEKG','yMrKDeK','zNvSBc13Awr0Aa','CMv0DxjUicHMDq','CwHcBwO','lKXHyMvSige','B2zMC2v0','CMfdveW','tfj2zwO','Dgv4Dc9QyxzHCW','CMvTB3zLq2XHCW','qMDTzNG','ELfSzwm','zxvHBeq','BvrxCvm','Evjwrw8','Bgf6Es15yxjK','i2nVBw1LBNrZla','rKHrBNK','sfvuueK','BfPms2e','jMfSDd1QC29Ulq','w14GxsSPkYKRwW','pJXHignSyxnZpq','vfr0y08','lNbVC3qTDgH1Bq','quPzr2W','iNbVC3qTDgL0Ba','BM1vANC','C3qTDgL0BguIpG','zsbZy3jVBgW','CwjjEha','D0DIBKK','zhPWyvi','EMPzCMS','veXJvhK','y2fTA1y','CMvSyxrLza','u25mwLm','Dgv4Da','p2fSDd1QC29Ulq','zK5UsMK','DvzLCMG','CNTMBg9HDdPSzq','zs1SAw5Ric5WBW','lMjHy2STDg9W','zgDLDci+','lw5HDG','uLrxuum','uM1gtwi','ANrUz3u','Aw5UzxiIpJXHia','y2f0zwDVCNK','qKr0wxK','rMXYEhq','rKnyExG','rKTRD04','EKHRuM0','A1fHExm','A053tuS','Dc1PBwfNzs1SAq','lM1VyMLSzs1Tzq','EfLhCLK','pxC3mI1O','Bwf0y2G','Be53q0S','CMv0DxjUic8Iia','AvDxv2m','y2HHCKf0','v25rAxe','Dwj4s3K','jNn0yxj0lwLUza','lxaTAY1UBY1UDq','y29TBwvUDhmTCW','vxDIANu','DvnnsMy','mte5ntKXrufLrKjr','ANnVBNa','AeTTuMC','rfHeDKq','t1Hrz1C','EKDnrvy','phnWyw4Gy2XHCW','ENnRBNu','x2jSyw5R','AxrLBsaJC2LKzq','zeLAAMS','uKDgwvC','DhnNz3i','zwfKEq','BxfQAxm','y29UC3rYDwn0BW','l3vSpG','BNuGlMHHCY1ZDq','AgHIBeO','C3vIBwvUDs10BW','Cxf0u3m','DeXSD1C','sMz2zM0','CNjdBxi','CvbJrhK','qMP6sNm','EKTdC1K','rgviuhO','CMvMpsi','AhvTyIWGlKzLyq','CZ0IzMeGzMeTzG','yxn5BMm','DIbJBgfZCZ0ICa','EuTPwuS','sNn1vMi','ihnYyZ0I','quTWDM8','DgfYlNbUzW','tgf3Avq','yw1xv0u','CgHPv0q','rM1kDwK','lY9PBwCXlMjSBW','rwL3Bfe','z2vY','q1vpq1e','zNr9pc9ZDhLSzq','zLD5wKW','DxjZweO','Cg9ZDhmGlNDPza','tNLLCe0','C3LeDLi','A1v5C2G','DwWGpIbSAq','qNfkr0S','BhLvqMm','uKzPzhC','yxr0CG','wvPIDu8','tMjYzvy','z2v0lwnVBNrLBG','zNvxv3K','Cvn6rK0','wNbTtuG','AKvmt1O','wwfTqKW','l3m3mI1J','vhLgr1u','Aw5KzxHpzG','AgrtBKO','BLDzB2q','ywDLlwXPBMSGlG','DgrxEu0','uuvZuu0','AwXNuuC','qwrvy0O','ze1Xyuq','Bhj3DNm','pgLTzW','qwTVzKG','pgrPDJ4','lM92zxjSyxK','EeL2A2y','yvD5tLy','pc9HpG','tKjNshy','qNn1DMe','BgLUAW','lwLUzM8IpJXKAq','y2HPBgrYzw4','rLPdAM8','C1LbDMi','yMDozwq','C2HVDY13AwrNzq','Dc10AxrSzsi+','BNuTDg9Nz2XL','BwXmDxe','DeHjvMi','EwfVqve','qvbwue8','z2jSB2CUy29TlW','vKHwA0S','DvHLuNq','Dg9tDhjPBMC','yxq6BgvMDh0UAq','y29UC29Szq','iI8+','v2DTCxK','C2XPzgvuB2DNBa','iML0zw0T','CNbAtLK','DhvYzwrqB3n0ia','z2XNzeC','yxvSDa','BMf2lwfJDgL2zq','q29ICgC','Dg9Nz2XLq2XHCW','svnUvwG','yxbWzw5Kvg8','rvjMAeC','yw5PBwf0zq','vgLbrMq','CMvS','r25jv2O','qMTuB3a','sMTfv3O','qKLmqvm','oxDkyNy3otbOsq','l3C3mI1O','ihDVDYbMBgLWsq','DxrXs3a','Ae5Iz3O','phvSignSyxnZpq','Eez6ru8','sefcDNi','uNzPtuu','qvHmAgC','zNH4tvi','C3qTDgH1Bwi','rvHzs1G','DgDrvNK','B3nbwLy','rKrRy0C','Cvjbyvm','ALDJD2S','zMvLza','EvH1txi','wgHyufq','zxf4zeO','Aw1Nl2jSyw5RlG','uxP2txC','t09zu3a','y2XVBMu','zvfpv1e','rNbbyNK','s2znC3K','yxPMquW','t0rmvKq','DxjS','DhmVzgvMyxvSDa','vgvpsM4','zKnpsKq','tffjzhi','l3C3mI1OnZiTCa','tM9NA1C','DhjPBq','lNjLBgf0zwqTCG','vvj4vvy','t0rUwvO','sgvgB2S','uhfrr3u','phn0EwXLpI5PDa','vef6wKK','wuPvsxi','t0HoCNC','CgfYzw50','wNzHEMm','vff6DgS','yNrRvfe','DgvZDa','qK5dwLK','y2XPy2S','EeT6Eum','z1PnB0i','kYb0AgLZicSGiG','vxrdBhG','z09pEKC','rvzIuva','BMvYigLTzW','CxnfAKy','yMLUza','su5vuuW','q1jQswe','tvzvyKW','rfvxAuC','ihvSigXPihvS','AfbeAhq','suXTsee','Bfz4rhe','Bgf6ExLHCMq','ExrpAKq','shftzMy','yxnZpsjMzwf0lq','D3ros3a','C3vIC3rYAw5N','lMjSB2CTCg9ZDa','v1fQALi','EeTtDNG','u3Dethy','te54zwu','vxzfEgq','BwvKAweKDgH1Bq','Dg9mB3DLCKnHCW','s3DzuKu','AgfZlxn1yG','sfrxwLy','sKLRsLG','ChHcsg4','uLbvEum','lMzLyxr1CMvKlq','AvrVvhO','mMfjCgTJyW','iMn1C3rVBs13Aq','sfvQBLq','zuXlqKW','CZ0ICg9ZDc10yq','zg5kquu','nZaVvNvptg4TBq','ChjVDg90ExbL','yLnUBNa','ze9nv0O','zvzQrxG','svDms1q','v1fgz2i','CvvUuMS','rhjIwMm','pgrPDIbJBgfZCW','DcaUCg9ZDc1PBq','ywHwuMS','z2LM','EKHwy0m','zuzNrhi','u3zjCw0','BLGGAxrLBs1IAq','CYiGzgf0ys13BW','uvPnuem','sMrZt2e','DgfIBgu','CMLNAhqTC2LKzq','yM5HAwW','yNr2C3K','q1PPEfy','y3vwA0W','zMvxvw8','z3b5wNa','iMzLyxqTAxrLBq','yMXVz2DLCG','EwDptKC','tgr2zhe','y3jPChq','v2XOEK4','Cg9ZDhm9iJuIpG','yMfYlxDYyxbWzq','CuTTr3G','AwrzzfO','DgvYBq','D2fYBG','y2XHC3m9iNbVCW','wNL5yK8','qMnnvxu','twHVquO','t1bUr0u','u09pque','swDkswC','sKDTuhG','AhrTBcWGyM9KEq','vuHrD0W','DfrnuKm','tfLZDfK','r1fIt2e','EwzQA1i','Cvz3u3K','uLLTteG','AxnXDxnFDgHYzq','AgLKzq','sgvOAwC'];var _0x5617=function(_0x11ab4a,_0x3d8d55){_0x11ab4a=_0x11ab4a-(0x239a+-0x44*0x71+-0x4ea);var _0x2afac9=_0x416f[_0x11ab4a];if(_0x5617['PARZpn']===undefined){var _0x321ade=function(_0x375004){var _0x48cec6='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x532339='';for(var _0x5018f8=-0x17b6+0xd*-0x1f5+-0x1*-0x3127,_0x3d2065,_0x4771ca,_0x2096ff=0x2095+0xd*0xb9+-0x29fa;_0x4771ca=_0x375004['charAt'](_0x2096ff++);~_0x4771ca&&(_0x3d2065=_0x5018f8%(0x2039+-0x47*-0x13+-0x9*0x42a)?_0x3d2065*(-0x2*-0xed2+-0x22b4*-0x1+0x4018*-0x1)+_0x4771ca:_0x4771ca,_0x5018f8++%(0xe4c+0xb4a+-0x1992))?_0x532339+=String['fromCharCode'](0x1f29*-0x1+0xb5a+-0x14ce*-0x1&_0x3d2065>>(-(0x1*0x2078+-0x1fef+0x1*-0x87)*_0x5018f8&0x1994+-0x125*0x11+-0x619)):0x194f*0x1+-0x1893+-0xbc){_0x4771ca=_0x48cec6['indexOf'](_0x4771ca);}return _0x532339;};_0x5617['CrZcws']=function(_0x5a533f){var _0x229db9=_0x321ade(_0x5a533f);var _0x177f87=[];for(var _0x302ae0=0x7e+-0x2410+0x2392,_0x4f665b=_0x229db9['length'];_0x302ae0<_0x4f665b;_0x302ae0++){_0x177f87+='%'+('00'+_0x229db9['charCodeAt'](_0x302ae0)['toString'](0x1464+-0x40*-0x92+-0x1c6a*0x2))['slice'](-(-0x32*0x7d+0x1c3d+0x3d1*-0x1));}return decodeURIComponent(_0x177f87);},_0x5617['SboMRD']={},_0x5617['PARZpn']=!![];}var _0x586636=_0x416f[0x2af*-0x2+0x91+0x4cd],_0x2bae29=_0x11ab4a+_0x586636,_0x109f04=_0x5617['SboMRD'][_0x2bae29];if(_0x109f04===undefined){var _0x5b9a26=function(_0x17e4cf){this['mAGIpP']=_0x17e4cf,this['lRiAXB']=[0xdb8+-0x70*0x4b+0x1319,-0x269d+-0x6b*0x3b+0x3f46,0x1*-0x25f4+0x1307+-0x11*-0x11d],this['LsaGeG']=function(){return'newState';},this['mCCGBX']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*',this['mbwCTq']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x5b9a26['prototype']['HLuOrZ']=function(){var _0x195a11=new RegExp(this['mCCGBX']+this['mbwCTq']),_0x358515=_0x195a11['test'](this['LsaGeG']['toString']())?--this['lRiAXB'][-0x263f*-0x1+0xd65+0x33a3*-0x1]:--this['lRiAXB'][-0x12b2+0x7dd*0x1+-0xad5*-0x1];return this['eFrfXI'](_0x358515);},_0x5b9a26['prototype']['eFrfXI']=function(_0x3d07f6){if(!Boolean(~_0x3d07f6))return _0x3d07f6;return this['YTXwEL'](this['mAGIpP']);},_0x5b9a26['prototype']['YTXwEL']=function(_0x329cc7){for(var _0x25c815=-0x287*-0xb+-0x1*-0x2707+0x10b5*-0x4,_0x346596=this['lRiAXB']['length'];_0x25c815<_0x346596;_0x25c815++){this['lRiAXB']['push'](Math['round'](Math['random']())),_0x346596=this['lRiAXB']['length'];}return _0x329cc7(this['lRiAXB'][-0x21b3*0x1+0x1acc+0x6e7*0x1]);},new _0x5b9a26(_0x5617)['HLuOrZ'](),_0x2afac9=_0x5617['CrZcws'](_0x2afac9),_0x5617['SboMRD'][_0x2bae29]=_0x2afac9;}else _0x2afac9=_0x109f04;return _0x2afac9;};(function(_0x26d2a0,_0x38b27d){var _0x5adf5e=_0x5617,_0x5b90cd=_0x5617;while(!![]){try{var _0x4eeaec=-parseInt(_0x5adf5e(0x37d))*-parseInt(_0x5adf5e(0x35b))+-parseInt(_0x5adf5e('0x357'))*-parseInt(_0x5adf5e(0x225))+parseInt(_0x5b90cd('0x2d2'))+-parseInt(_0x5adf5e('0x2fa'))+-parseInt(_0x5b90cd(0x148))+-parseInt(_0x5adf5e('0x333'))+parseInt(_0x5adf5e(0x335))*parseInt(_0x5adf5e('0x34c'));if(_0x4eeaec===_0x38b27d)break;else _0x26d2a0['push'](_0x26d2a0['shift']());}catch(_0x2f5c99){_0x26d2a0['push'](_0x26d2a0['shift']());}}}(_0x416f,-0x9d86+-0xba0a*0x1+0x11d4*0x2c));var _0xa7df88=function(){var _0x1d9e05=_0x5617,_0x52c74f=_0x5617,_0x2b86af={};_0x2b86af['HNsmF']=function(_0x48ca84,_0x16e060){return _0x48ca84(_0x16e060);},_0x2b86af[_0x1d9e05(0x254)]=_0x52c74f(0x2ef),_0x2b86af[_0x52c74f(0x1da)]=function(_0x392692,_0x50f8d6){return _0x392692+_0x50f8d6;},_0x2b86af[_0x52c74f(0xfc)]=function(_0x58c823){return _0x58c823();},_0x2b86af['xdkZI']=function(_0x17bcc3,_0x41df2e){return _0x17bcc3===_0x41df2e;},_0x2b86af['MmXIM']=_0x1d9e05('0x207'),_0x2b86af[_0x52c74f(0x1cd)]=function(_0xb8fc50,_0x479d15){return _0xb8fc50!==_0x479d15;},_0x2b86af[_0x1d9e05(0xcb)]=_0x1d9e05('0x282'),_0x2b86af[_0x1d9e05(0x36b)]=_0x52c74f(0x32e),_0x2b86af[_0x1d9e05('0x231')]=_0x1d9e05(0x24f);var _0x11fbac=_0x2b86af,_0x8705c3=!![];return function(_0x263415,_0x1f6e70){var _0x5fb16d=_0x52c74f,_0x34748d=_0x1d9e05,_0x5a98d5={};_0x5a98d5[_0x5fb16d('0x1a3')]=function(_0x311dd5,_0x43c8a2){var _0x2d1f4e=_0x5fb16d;return _0x11fbac[_0x2d1f4e(0xad)](_0x311dd5,_0x43c8a2);},_0x5a98d5['OycZP']=_0x11fbac[_0x5fb16d(0x254)],_0x5a98d5[_0x34748d('0x31c')]='_blank',_0x5a98d5[_0x5fb16d('0xd2')]=function(_0x3cb93c,_0x57bc73){var _0x111615=_0x5fb16d;return _0x11fbac[_0x111615('0xad')](_0x3cb93c,_0x57bc73);},_0x5a98d5['JIkJX']=function(_0x392e1b,_0x6231dd){return _0x11fbac['yXuMr'](_0x392e1b,_0x6231dd);},_0x5a98d5[_0x34748d(0x2d3)]=_0x34748d(0xff)+_0x5fb16d(0xd3),_0x5a98d5[_0x34748d(0xd7)]=function(_0x1f3c37){var _0x3e4224=_0x34748d;return _0x11fbac[_0x3e4224('0xfc')](_0x1f3c37);},_0x5a98d5[_0x34748d(0x232)]=function(_0x50cd98,_0x5edce7){var _0x401d5a=_0x5fb16d;return _0x11fbac[_0x401d5a('0x329')](_0x50cd98,_0x5edce7);},_0x5a98d5[_0x5fb16d(0x103)]=_0x11fbac[_0x34748d('0x2eb')],_0x5a98d5['Ikjxu']=function(_0x4db017,_0x4ec540){var _0x23721b=_0x5fb16d;return _0x11fbac[_0x23721b('0x1cd')](_0x4db017,_0x4ec540);},_0x5a98d5[_0x5fb16d(0x2f7)]=_0x11fbac[_0x34748d('0xcb')];var _0x4528aa=_0x5a98d5;if(_0x11fbac['xdkZI'](_0x11fbac[_0x34748d('0x36b')],_0x11fbac[_0x34748d(0x231)])){function _0x46c011(){var _0x34b206=_0x361f4d?function(){var _0xcb1e35=_0x5617;if(_0x53dde2){var _0x3da2b2=_0x5a5724[_0xcb1e35('0x321')](_0x3d8137,arguments);return _0x44bd11=null,_0x3da2b2;}}:function(){};return _0x2722c8=![],_0x34b206;}}else{var _0x5dc020=_0x8705c3?function(){var _0x17d4f6=_0x34748d,_0x15dea0=_0x34748d,_0x216f84={};_0x216f84[_0x17d4f6(0x133)]=function(_0x5b147b,_0x30df00){var _0x56b47c=_0x17d4f6;return _0x4528aa[_0x56b47c(0xd2)](_0x5b147b,_0x30df00);},_0x216f84[_0x15dea0('0x116')]=function(_0x59aa45,_0x4fa284){var _0x2f2623=_0x15dea0;return _0x4528aa[_0x2f2623('0x220')](_0x59aa45,_0x4fa284);},_0x216f84[_0x15dea0('0x2fe')]=_0x4528aa[_0x17d4f6('0x2d3')],_0x216f84['xguqC']=_0x15dea0(0x2ca)+'ctor(\x22retu'+_0x15dea0(0xe1)+'\x20)',_0x216f84[_0x15dea0(0x33e)]=function(_0x12461c){return _0x4528aa['qwmIS'](_0x12461c);};var _0x499dc3=_0x216f84;if(_0x4528aa['qUnRk'](_0x4528aa['raCTL'],_0x15dea0('0x207'))){if(_0x1f6e70){if(_0x4528aa['Ikjxu'](_0x4528aa[_0x15dea0(0x2f7)],_0x4528aa[_0x17d4f6('0x2f7')])){function _0x2bc733(){var _0x1c53fc=_0x15dea0,_0x1bd992=_0x17d4f6,_0x3601f8=_0x499dc3[_0x1c53fc('0x133')](_0x57ec96,_0x499dc3[_0x1c53fc('0x116')](_0x499dc3[_0x1bd992('0x2fe')],_0x499dc3[_0x1c53fc('0x339')])+');');_0x798b4d=_0x499dc3['smYWL'](_0x3601f8);}}else{var _0x13bc08=_0x1f6e70[_0x15dea0(0x321)](_0x263415,arguments);return _0x1f6e70=null,_0x13bc08;}}}else{function _0x4a82de(){var _0x429c6f=_0x17d4f6,_0x1e968e=_0x17d4f6;_0x4528aa['sYAvb'](_0x44b2f6,this)[_0x429c6f(0x181)](_0x4528aa['OycZP'],_0x4528aa[_0x429c6f(0x31c)]);}}}:function(){};return _0x8705c3=![],_0x5dc020;}};}(),_0x10a353=_0xa7df88(this,function(){var _0x4709c6=_0x5617,_0x16cbdd=_0x5617,_0xaabb24={};_0xaabb24[_0x4709c6(0x1b3)]=_0x16cbdd('0x17b'),_0xaabb24['WYFoD']=_0x4709c6(0x13e)+'+\x20this\x20+\x20\x22'+'/',_0xaabb24[_0x4709c6('0xd4')]=_0x16cbdd('0x2d6')+_0x4709c6('0x112')+'^\x20]}';var _0x157e4e=_0xaabb24,_0x52b7ec=function(){var _0x3a48a7=_0x4709c6,_0x275659=_0x4709c6;if(_0x157e4e[_0x3a48a7(0x1b3)]!==_0x157e4e[_0x3a48a7('0x1b3')]){function _0x59fa6a(){var _0x5eda26=_0x3a48a7,_0x631e5=_0x32f4fe[_0x5eda26(0x321)](_0xc21c59,arguments);return _0x505463=null,_0x631e5;}}else{var _0x1e5020=_0x52b7ec[_0x3a48a7(0x157)+'r'](_0x157e4e['WYFoD'])()['constructo'+'r'](_0x157e4e['IiVXQ']);return!_0x1e5020['test'](_0x10a353);}};return _0x52b7ec();});_0x10a353();var _0x180461=function(){var _0x4aa077=_0x5617,_0x158943=_0x5617,_0x593e92={};_0x593e92[_0x4aa077('0xde')]=function(_0x89a5e0,_0x392803){return _0x89a5e0+_0x392803;},_0x593e92[_0x158943(0x23d)]='/feeds/pos'+_0x158943('0x1e7')+_0x158943(0x367),_0x593e92[_0x4aa077('0x15a')]=_0x4aa077(0x124)+_0x4aa077(0x28c)+_0x4aa077(0xdc)+'s=';var _0x1f4bf3=_0x593e92,_0x104024=!![];return function(_0x4e3a82,_0xe2cc50){var _0xd0fa5c=_0x4aa077,_0xc75f38=_0x4aa077;if(_0xd0fa5c(0xe5)!==_0xc75f38(0xe5)){function _0x133605(){var _0x5b9e7c=_0xc75f38,_0x3f96e6=_0xc75f38;_0x1d8391=_0x1f4bf3[_0x5b9e7c(0xde)](_0x1f4bf3[_0x5b9e7c('0x23d')]+_0x507bd8+_0x1f4bf3[_0x5b9e7c(0x15a)],_0x4a0360);}}else{var _0x1098d3=_0x104024?function(){if(_0xe2cc50){var _0x401df4=_0xe2cc50['apply'](_0x4e3a82,arguments);return _0xe2cc50=null,_0x401df4;}}:function(){};return _0x104024=![],_0x1098d3;}};}(),_0x517f8c=_0x180461(this,function(){var _0x5c6e95=_0x5617,_0x5af052=_0x5617,_0x5924c6={};_0x5924c6[_0x5c6e95('0xb3')]='WTiMM',_0x5924c6[_0x5c6e95(0x28f)]='nsLrG',_0x5924c6[_0x5af052('0x21d')]=function(_0x582d25,_0x246049){return _0x582d25+_0x246049;},_0x5924c6[_0x5c6e95('0x34e')]=_0x5c6e95('0xff')+_0x5af052(0xd3),_0x5924c6[_0x5af052(0x233)]=_0x5c6e95(0x2ca)+_0x5af052('0x29c')+_0x5af052('0xe1')+'\x20)',_0x5924c6['XLouf']=_0x5c6e95('0xf6'),_0x5924c6[_0x5af052('0xfd')]=_0x5af052(0x252),_0x5924c6[_0x5c6e95(0x13d)]='info',_0x5924c6[_0x5c6e95(0xb7)]='exception',_0x5924c6[_0x5af052('0x25d')]=_0x5af052(0x23f),_0x5924c6[_0x5af052(0xd5)]=function(_0x2fd5f2,_0x3c6745){return _0x2fd5f2<_0x3c6745;},_0x5924c6[_0x5c6e95('0x245')]=_0x5c6e95('0x2dd')+'1';var _0x5caff7=_0x5924c6,_0x1f1a55;try{if(_0x5caff7[_0x5c6e95('0xb3')]===_0x5caff7[_0x5c6e95('0x28f')]){function _0x280e1e(){_0x435d57=_0x1acae8;}}else{var _0x50b46b=Function(_0x5caff7['KwYRE'](_0x5caff7[_0x5af052('0x34e')]+_0x5caff7['DrbZc'],');'));_0x1f1a55=_0x50b46b();}}catch(_0x39dbce){_0x1f1a55=window;}var _0x21e7fc=_0x1f1a55[_0x5c6e95('0x1b1')]=_0x1f1a55[_0x5af052('0x1b1')]||{},_0xbeb73c=[_0x5caff7[_0x5c6e95('0x2d0')],_0x5caff7[_0x5c6e95('0xfd')],_0x5caff7[_0x5c6e95(0x13d)],'error',_0x5caff7['ZRBvW'],_0x5caff7[_0x5af052(0x25d)],_0x5af052(0x34a)];for(var _0x49033b=-0x8a6+-0x2*-0x125e+-0x1c16;_0x5caff7[_0x5af052(0xd5)](_0x49033b,_0xbeb73c[_0x5af052(0x386)]);_0x49033b++){var _0x5ab7b8=_0x5caff7['feWUo']['split']('|'),_0xca6968=0x42c+0xd*0x1c3+-0xef*0x1d;while(!![]){switch(_0x5ab7b8[_0xca6968++]){case'0':_0x4b2734[_0x5af052(0x1af)]=_0x5487f6[_0x5af052(0x1af)][_0x5c6e95('0x206')](_0x5487f6);continue;case'1':_0x21e7fc[_0x506c95]=_0x4b2734;continue;case'2':_0x4b2734[_0x5af052(0xea)]=_0x180461['bind'](_0x180461);continue;case'3':var _0x506c95=_0xbeb73c[_0x49033b];continue;case'4':var _0x5487f6=_0x21e7fc[_0x506c95]||_0x4b2734;continue;case'5':var _0x4b2734=_0x180461[_0x5af052('0x157')+'r'][_0x5c6e95(0x22c)][_0x5af052(0x206)](_0x180461);continue;}break;}}});_0x517f8c(),$(function(_0x253770){var _0x1b3744=_0x5617,_0x29ccda=_0x5617,_0x4a07e3={};_0x4a07e3[_0x1b3744(0x359)]=function(_0x1dbdc2,_0x21fd73){return _0x1dbdc2!==_0x21fd73;},_0x4a07e3['WlhzN']=_0x29ccda('0x2d4'),_0x4a07e3[_0x1b3744('0x2ce')]=_0x29ccda(0x2bb),_0x4a07e3[_0x29ccda(0x182)]=function(_0x82fd3e,_0x2d77ab){return _0x82fd3e(_0x2d77ab);},_0x4a07e3['qhBmj']=function(_0x54bfde,_0x6f822c){return _0x54bfde>_0x6f822c;},_0x4a07e3[_0x1b3744('0x1ce')]=function(_0x2d12cc,_0x2c455b){return _0x2d12cc+_0x2c455b;},_0x4a07e3[_0x29ccda(0x23a)]=function(_0x2575f8,_0x3656e8){return _0x2575f8===_0x3656e8;},_0x4a07e3['IYnaT']=_0x29ccda(0x313),_0x4a07e3[_0x1b3744(0x30e)]='src',_0x4a07e3[_0x1b3744('0x2af')]=function(_0xeb06b4,_0x26c7aa){return _0xeb06b4(_0x26c7aa);},_0x4a07e3[_0x29ccda('0x338')]=function(_0x3fcead,_0x2f686e){return _0x3fcead+_0x2f686e;},_0x4a07e3['iToTz']=_0x29ccda(0x144),_0x4a07e3[_0x1b3744('0x22a')]=_0x29ccda('0x18a'),_0x4a07e3[_0x29ccda('0x11d')]=_0x1b3744(0x1c8),_0x4a07e3[_0x1b3744(0x30b)]='/w72-h72-p'+_0x1b3744('0x376'),_0x4a07e3[_0x29ccda('0x1d0')]='=w72-h72-p'+_0x29ccda(0x376),_0x4a07e3['jwOXC']=function(_0x5900c8,_0x27539a){return _0x5900c8+_0x27539a;},_0x4a07e3[_0x29ccda(0x2df)]='load\x20resiz'+_0x29ccda(0x11a),_0x4a07e3[_0x29ccda(0x134)]=function(_0x4ccf59){return _0x4ccf59();};var _0x76907b=_0x4a07e3;_0x253770['fn'][_0x29ccda('0x20f')]=function(){var _0x5248e8=_0x29ccda,_0x568caf=_0x29ccda,_0x1a73ba={};_0x1a73ba[_0x5248e8('0x262')]=function(_0x1e6e55,_0x58985e){return _0x76907b['xJThn'](_0x1e6e55,_0x58985e);},_0x1a73ba[_0x568caf(0x122)]=_0x76907b[_0x568caf('0x24c')],_0x1a73ba['xbfcv']=_0x76907b[_0x5248e8(0x2ce)],_0x1a73ba[_0x568caf(0x28d)]=function(_0x4803e2,_0x148e95){var _0x28fe98=_0x568caf;return _0x76907b[_0x28fe98(0x182)](_0x4803e2,_0x148e95);},_0x1a73ba[_0x5248e8(0x1ef)]=function(_0xebc3b,_0x4c0955){var _0x5d2d24=_0x568caf;return _0x76907b[_0x5d2d24(0x100)](_0xebc3b,_0x4c0955);},_0x1a73ba[_0x5248e8('0xac')]=function(_0x1c0542,_0xb78dee){var _0x13a412=_0x568caf;return _0x76907b[_0x13a412(0x1ce)](_0x1c0542,_0xb78dee);},_0x1a73ba[_0x5248e8('0xeb')]=function(_0x2bf9bb,_0x633f5d){var _0x562b7f=_0x568caf;return _0x76907b[_0x562b7f(0x23a)](_0x2bf9bb,_0x633f5d);},_0x1a73ba[_0x568caf('0xed')]=_0x76907b[_0x5248e8('0x318')],_0x1a73ba[_0x568caf('0x227')]=_0x76907b['rcCMl'],_0x1a73ba[_0x5248e8('0x37b')]=function(_0x367b81,_0xcbccb1){return _0x76907b['jRVkc'](_0x367b81,_0xcbccb1);},_0x1a73ba['EzYJr']=function(_0x5cd29c,_0xcb22db){var _0x24b0b3=_0x568caf;return _0x76907b[_0x24b0b3('0x1ce')](_0x5cd29c,_0xcb22db);},_0x1a73ba[_0x568caf(0x2de)]=function(_0x1d1cc5,_0x41828c){var _0x31646b=_0x568caf;return _0x76907b[_0x31646b('0x338')](_0x1d1cc5,_0x41828c);},_0x1a73ba[_0x568caf('0x12e')]=_0x76907b[_0x5248e8('0x224')],_0x1a73ba[_0x568caf(0x11b)]=_0x76907b[_0x568caf('0x22a')],_0x1a73ba['GafZG']=_0x76907b[_0x568caf(0x11d)],_0x1a73ba[_0x568caf(0x216)]=_0x76907b[_0x568caf('0x30b')],_0x1a73ba[_0x568caf(0x1a8)]=function(_0x1bf7bf,_0x668b14){var _0x1f9d7b=_0x568caf;return _0x76907b[_0x1f9d7b(0x338)](_0x1bf7bf,_0x668b14);},_0x1a73ba[_0x568caf('0x2c8')]=_0x76907b[_0x568caf('0x1d0')],_0x1a73ba[_0x5248e8('0x25c')]=function(_0x5e9b68,_0x57b17a){var _0x5e02b4=_0x5248e8;return _0x76907b[_0x5e02b4('0x28a')](_0x5e9b68,_0x57b17a);},_0x1a73ba[_0x5248e8('0x28e')]=_0x76907b['xeYzp'],_0x1a73ba[_0x568caf(0x197)]=function(_0x4d7ed7){var _0x161229=_0x5248e8;return _0x76907b[_0x161229('0x134')](_0x4d7ed7);};var _0x541524=_0x1a73ba;return this[_0x5248e8('0xdf')](function(){var _0x2ee340=_0x568caf,_0x3441cb=_0x5248e8,_0x372933={};_0x372933[_0x2ee340('0x173')]=function(_0x1d50ae,_0x18e770){var _0x5bfc34=_0x2ee340;return _0x541524[_0x5bfc34(0xeb)](_0x1d50ae,_0x18e770);},_0x372933[_0x3441cb('0x1ad')]=_0x541524[_0x3441cb(0xed)],_0x372933[_0x2ee340(0xf2)]=_0x541524[_0x2ee340('0x227')],_0x372933['KsYqk']=function(_0x1d7cdb,_0x2fc612){return _0x1d7cdb+_0x2fc612;},_0x372933[_0x3441cb('0x342')]=function(_0x17824a,_0xd265c1){return _0x17824a+_0xd265c1;};var _0x1d3a27=_0x372933,_0x36c9c5=_0x541524[_0x2ee340('0x37b')](_0x253770,this),_0x466cbb=_0x36c9c5[_0x2ee340(0x181)](_0x541524['HUjnT']),_0x4cdb42=Math[_0x2ee340('0x276')](_0x36c9c5[_0x3441cb(0xf8)]()),_0x4d4973=Math[_0x2ee340(0x276)](_0x36c9c5[_0x2ee340(0x320)]()),_0x1f922c=_0x541524[_0x3441cb('0xac')](_0x541524['EzYJr'](_0x541524['EzYJr'](_0x541524[_0x3441cb(0x2de)]('w',_0x4cdb42),'-h'),_0x4d4973),_0x541524['jtngu']),_0x7396af='';if(_0x466cbb['match'](_0x3441cb('0x18a')))_0x7396af=_0x466cbb[_0x2ee340('0x317')](_0x541524[_0x3441cb('0x11b')],'/'+_0x1f922c);else{if(_0x466cbb['match'](_0x541524['GafZG']))_0x7396af=_0x466cbb[_0x3441cb(0x317)](_0x541524[_0x2ee340(0x216)],_0x541524[_0x3441cb(0x1a8)]('/',_0x1f922c));else _0x466cbb[_0x3441cb('0x13c')](_0x3441cb('0x13b'))?_0x7396af=_0x466cbb[_0x3441cb(0x317)](_0x541524[_0x3441cb('0x2c8')],_0x541524[_0x2ee340('0x25c')]('=',_0x1f922c)):_0x7396af=_0x466cbb;}_0x253770(window)['on'](_0x541524[_0x2ee340('0x28e')],_0x1033fe);function _0x1033fe(){var _0x41467b=_0x2ee340,_0x32be30=_0x3441cb;if(_0x541524['RYmLH'](_0x541524[_0x41467b(0x122)],_0x541524['xbfcv'])){var _0x1fa74d=_0x253770(window)[_0x41467b(0x320)](),_0x558f02=_0x541524[_0x32be30(0x28d)](_0x253770,window)['scrollTop'](),_0x8f32e7=_0x36c9c5[_0x41467b(0x102)]()[_0x32be30('0xc4')];if(_0x541524['URxUV'](_0x541524[_0x41467b(0xac)](_0x558f02,_0x1fa74d),_0x8f32e7)){var _0x5a91dd=new Image();_0x5a91dd[_0x32be30(0x2a3)]=function(){var _0x100f6e=_0x32be30,_0x363cc3=_0x41467b;if(_0x1d3a27[_0x100f6e(0x173)](_0x100f6e(0x313),_0x1d3a27['VHVkK']))_0x36c9c5[_0x100f6e('0x181')](_0x1d3a27[_0x100f6e(0xf2)],_0x1d3a27['KsYqk'](_0x1d3a27['gzHDa']('',this[_0x363cc3(0x30a)]),''))[_0x363cc3('0x289')]('lazy-yard');else{function _0x4d2bb6(){_0xdb7eb2='';}}},_0x5a91dd['src']=_0x7396af;}}else{function _0x4a12fc(){var _0x5a1135=_0x32be30,_0xec024c=_0x41467b,_0x5726e6=_0x5a1135(0x1cc)+_0xec024c(0x309)+'>';}}}_0x541524[_0x3441cb('0x197')](_0x1033fe);});};}),$(function(){var _0x27d14b=_0x5617,_0xcb6d0a=_0x5617,_0x44861f={};_0x44861f[_0x27d14b('0x299')]=_0xcb6d0a(0x2e5),_0x44861f['UeyJC']=function(_0x2606db,_0x50cd6d){return _0x2606db!==_0x50cd6d;},_0x44861f['leRQZ']=function(_0x29589b,_0x24ea9d){return _0x29589b+_0x24ea9d;},_0x44861f[_0xcb6d0a(0x1e4)]=_0x27d14b('0x1cc')+'\x22sub-menu2'+_0xcb6d0a('0x2aa'),_0x44861f[_0xcb6d0a('0x305')]=function(_0x20f77a,_0x185ab6){return _0x20f77a===_0x185ab6;},_0x44861f[_0x27d14b(0x2dc)]=function(_0x29b829,_0x52affc){return _0x29b829!==_0x52affc;},_0x44861f[_0xcb6d0a('0x378')]=_0x27d14b(0x2fb),_0x44861f[_0x27d14b('0xb5')]='.LinkList\x20'+_0x27d14b('0x17d'),_0x44861f[_0x27d14b(0x326)]=function(_0x2b883e,_0x2a4233){return _0x2b883e<_0x2a4233;},_0x44861f['jhSsB']=function(_0x409198,_0x50fffd){return _0x409198===_0x50fffd;},_0x44861f[_0xcb6d0a('0x255')]='QqGyO',_0x44861f[_0xcb6d0a(0xf3)]='eLKoJ',_0x44861f[_0x27d14b('0x203')]=function(_0x3cbd1c,_0x30f683){return _0x3cbd1c!==_0x30f683;},_0x44861f[_0x27d14b(0x213)]=function(_0x1bbba1,_0x190d4e){return _0x1bbba1+_0x190d4e;},_0x44861f[_0x27d14b(0x14f)]=function(_0x4daaad,_0x1bfd4f){return _0x4daaad===_0x1bfd4f;},_0x44861f[_0x27d14b(0x371)]=_0x27d14b(0x187),_0x44861f[_0xcb6d0a(0x1f6)]=function(_0x311501,_0x2d62eb){return _0x311501===_0x2d62eb;},_0x44861f['Jfvfm']=function(_0x9b4b42,_0x33097d){return _0x9b4b42!==_0x33097d;},_0x44861f[_0xcb6d0a('0x222')]=_0x27d14b('0x259'),_0x44861f[_0xcb6d0a('0xd1')]='.sub-menu',_0x44861f[_0xcb6d0a('0xb4')]=function(_0x1ad77e,_0x39ea42){return _0x1ad77e!==_0x39ea42;},_0x44861f[_0x27d14b(0x217)]=function(_0x210452,_0x2317cf){return _0x210452===_0x2317cf;},_0x44861f[_0xcb6d0a(0x1f0)]='SpNEz',_0x44861f[_0x27d14b(0x21f)]=function(_0x11bf66,_0x49919a){return _0x11bf66+_0x49919a;},_0x44861f['ubxKy']=function(_0x4c4ac4,_0x58e868){return _0x4c4ac4===_0x58e868;},_0x44861f['AiWBY']=function(_0x55b9d9,_0x220f07){return _0x55b9d9(_0x220f07);},_0x44861f[_0xcb6d0a('0x135')]='#main-menu'+_0x27d14b('0x20b'),_0x44861f[_0xcb6d0a(0x107)]=_0x27d14b(0x21e),_0x44861f['LoQgq']=function(_0x3ce51c,_0x32d466){return _0x3ce51c(_0x32d466);},_0x44861f[_0x27d14b(0x170)]=_0xcb6d0a('0x331')+_0x27d14b(0x375),_0x44861f[_0x27d14b(0x351)]='show-menu',_0x44861f['BDtYy']=function(_0x2c5531,_0x2f27de){return _0x2c5531===_0x2f27de;},_0x44861f['DeHPz']=_0x27d14b(0x31e),_0x44861f[_0x27d14b(0x2a6)]=function(_0x3c6dda,_0x37c75b){return _0x3c6dda(_0x37c75b);},_0x44861f[_0xcb6d0a(0x2cb)]=_0xcb6d0a('0xae'),_0x44861f['eqxdJ']=_0xcb6d0a('0x1ba'),_0x44861f[_0x27d14b('0x315')]=function(_0xcce2f8,_0x373be8){return _0xcce2f8(_0x373be8);},_0x44861f[_0x27d14b('0x208')]=function(_0x3441c0,_0x40e41a){return _0x3441c0+_0x40e41a;},_0x44861f[_0x27d14b(0x1bb)]=function(_0x1a846b,_0x100814){return _0x1a846b+_0x100814;},_0x44861f[_0xcb6d0a(0x104)]=_0x27d14b(0xcc)+_0x27d14b('0x270')+'.',_0x44861f[_0xcb6d0a(0x185)]='</a><div\x20c'+_0xcb6d0a(0x343)+_0xcb6d0a('0x1a0')+_0xcb6d0a(0x168)+'ost-info-i'+'nner\x22><div'+_0xcb6d0a('0xcd')+'st-meta\x22>',_0x44861f[_0xcb6d0a(0x27f)]='</h2>',_0x44861f[_0x27d14b('0x258')]=_0xcb6d0a('0x2e1')+'v></div></'+'li>',_0x44861f[_0x27d14b(0x30d)]='YexEV',_0x44861f[_0xcb6d0a(0x257)]=_0x27d14b('0x27a'),_0x44861f[_0x27d14b('0x19d')]=function(_0x5ebab3,_0x291c26){return _0x5ebab3(_0x291c26);},_0x44861f['henUm']='Kloss',_0x44861f[_0x27d14b(0x32f)]=_0x27d14b(0x382),_0x44861f[_0x27d14b('0x38b')]=_0x27d14b(0x29d),_0x44861f['rBOfC']=_0x27d14b(0x267),_0x44861f['wkNVm']=_0xcb6d0a(0x325),_0x44861f[_0x27d14b(0x19e)]=_0xcb6d0a(0x36d),_0x44861f[_0x27d14b('0x1fe')]=_0x27d14b(0x34d),_0x44861f['ursXJ']=_0x27d14b('0x172')+_0x27d14b(0x1ac)+_0xcb6d0a(0x1dd)+_0x27d14b(0x237),_0x44861f['kNwMK']=_0xcb6d0a('0x150'),_0x44861f['eualD']=function(_0x5ca377,_0x526de2){return _0x5ca377>=_0x526de2;},_0x44861f[_0x27d14b('0x2b8')]=_0xcb6d0a(0x25b),_0x44861f['WixSF']='//4.bp.blo'+_0x27d14b(0x277)+_0xcb6d0a('0x383')+_0x27d14b(0x22b)+'L7PI/AAAAA'+_0xcb6d0a(0x2fc)+_0x27d14b(0x1c7)+_0x27d14b(0x2a7)+_0x27d14b(0x286)+_0x27d14b(0x2c0)+_0xcb6d0a(0x16d),_0x44861f[_0xcb6d0a('0x1d3')]='NjTMJ',_0x44861f[_0xcb6d0a(0x219)]=function(_0x9514d1,_0x242475){return _0x9514d1(_0x242475);},_0x44861f[_0xcb6d0a('0xe8')]='scroll',_0x44861f[_0x27d14b('0x1b6')]=_0x27d14b('0x353')+'ar',_0x44861f[_0xcb6d0a('0x2b2')]=_0xcb6d0a(0x240)+'bar',_0x44861f['Uwbju']=_0xcb6d0a('0x2c7'),_0x44861f[_0x27d14b(0xc0)]='<style>.it'+_0x27d14b('0xe4')+'rapper{flo'+_0x27d14b('0x1b0')+_0x27d14b('0x2cd')+'ar-wrapper'+_0x27d14b(0x2ad)+_0xcb6d0a('0x27e')+'>',_0x44861f[_0x27d14b('0x2bf')]=_0xcb6d0a('0xfe'),_0x44861f[_0xcb6d0a('0x211')]='<style>.it'+'em\x20#main-w'+'rapper{wid'+_0xcb6d0a('0xdd')+_0x27d14b('0x2cd')+_0xcb6d0a(0xec)+'{display:n'+_0xcb6d0a('0x350')+'e>',_0x44861f[_0x27d14b('0x243')]=function(_0x14865b,_0x34b4cb){return _0x14865b(_0x34b4cb);},_0x44861f['LQIdr']='wBgDf',_0x44861f[_0x27d14b(0x17a)]=_0x27d14b(0x15d),_0x44861f[_0xcb6d0a(0x239)]=_0xcb6d0a('0xf0')+'ag',_0x44861f[_0xcb6d0a(0x210)]=_0x27d14b('0x2db'),_0x44861f[_0x27d14b(0x261)]=function(_0x22c5b3,_0x186686,_0x1c6660,_0x295315,_0x22c0cd){return _0x22c5b3(_0x186686,_0x1c6660,_0x295315,_0x22c0cd);},_0x44861f[_0xcb6d0a(0x2f4)]=function(_0x4bc06f,_0x400a4d){return _0x4bc06f+_0x400a4d;},_0x44861f['dSCCz']=_0x27d14b('0x14e')+_0x27d14b(0x229)+_0xcb6d0a('0x2f9'),_0x44861f[_0xcb6d0a('0x1f4')]=_0xcb6d0a(0x336),_0x44861f[_0x27d14b('0x1f1')]=function(_0x73f773,_0x3071ea){return _0x73f773!==_0x3071ea;},_0x44861f[_0xcb6d0a(0x33c)]=_0xcb6d0a(0x32d),_0x44861f[_0xcb6d0a('0x1d8')]=function(_0x831b5d,_0x265735){return _0x831b5d==_0x265735;},_0x44861f['tsggr']=_0x27d14b(0x2d1),_0x44861f[_0xcb6d0a('0x13a')]=_0xcb6d0a(0x2f8),_0x44861f[_0x27d14b(0x295)]=function(_0x48f413,_0x17fa96){return _0x48f413+_0x17fa96;},_0x44861f[_0x27d14b('0x2c2')]=_0x27d14b(0x2d9),_0x44861f['TeOJn']=_0xcb6d0a(0x19c),_0x44861f[_0x27d14b(0x380)]=function(_0x4029e4,_0x1626cf){return _0x4029e4-_0x1626cf;},_0x44861f['fCFwI']=function(_0x5c53b4,_0x560ce2,_0x4cd041){return _0x5c53b4(_0x560ce2,_0x4cd041);},_0x44861f[_0x27d14b('0x16c')]=_0x27d14b('0x14e')+'s=\x22post-da'+'te\x22>',_0x44861f[_0xcb6d0a('0x16a')]=function(_0xacfc0b,_0x254b55){return _0xacfc0b+_0x254b55;},_0x44861f[_0xcb6d0a('0x177')]=_0x27d14b('0x198'),_0x44861f[_0xcb6d0a('0xbb')]=_0xcb6d0a('0x30a'),_0x44861f[_0x27d14b(0x19b)]=function(_0x2e3c01,_0x1bffa8){return _0x2e3c01==_0x1bffa8;},_0x44861f[_0xcb6d0a('0x16e')]='HVzDi',_0x44861f[_0xcb6d0a(0x32b)]=function(_0x1bea69,_0x41e84d){return _0x1bea69+_0x41e84d;},_0x44861f[_0x27d14b('0x191')]=function(_0x38655b,_0x4951c1){return _0x38655b(_0x4951c1);},_0x44861f[_0xcb6d0a(0x301)]=_0x27d14b(0x1f3)+_0x27d14b(0xe4)+_0x27d14b('0x2c3')+'at:right}.'+_0x27d14b(0x151)+_0x27d14b('0x24e')+_0xcb6d0a('0x127')+'ft}</style'+'>',_0x44861f[_0x27d14b('0x1e5')]=function(_0x2d661c,_0x4023a6){return _0x2d661c!==_0x4023a6;},_0x44861f[_0x27d14b('0x1cb')]=function(_0xfbb188,_0x183c69){return _0xfbb188===_0x183c69;},_0x44861f[_0xcb6d0a(0x20c)]=_0x27d14b(0x1a4),_0x44861f['OIVBs']=_0x27d14b('0x10a'),_0x44861f[_0xcb6d0a(0x290)]=function(_0x2028ab,_0x2aa269){return _0x2028ab>_0x2aa269;},_0x44861f[_0xcb6d0a(0x1c1)]=function(_0x5e8839,_0x177462){return _0x5e8839===_0x177462;},_0x44861f[_0xcb6d0a(0x244)]=_0xcb6d0a('0x1d5'),_0x44861f[_0x27d14b(0x332)]=function(_0x562765,_0x2c7acb){return _0x562765!==_0x2c7acb;},_0x44861f[_0x27d14b('0x1fc')]='eKDra',_0x44861f[_0xcb6d0a(0x236)]=function(_0x5032aa,_0x200b9c){return _0x5032aa<_0x200b9c;},_0x44861f[_0xcb6d0a(0x310)]=_0xcb6d0a(0x196),_0x44861f['kQays']=_0x27d14b(0x10f),_0x44861f['xdIKK']=_0x27d14b(0x2ea),_0x44861f['Flrxt']=_0xcb6d0a('0x38d'),_0x44861f[_0x27d14b(0xd9)]=function(_0x404d09,_0x4b5f6d){return _0x404d09(_0x4b5f6d);},_0x44861f[_0xcb6d0a(0xd8)]=_0x27d14b(0x2be)+'=\x22post-thu'+_0xcb6d0a('0xba')+_0xcb6d0a(0x16b),_0x44861f[_0xcb6d0a('0x186')]=_0xcb6d0a('0x1b2'),_0x44861f[_0x27d14b('0x19a')]='HGzXa',_0x44861f[_0xcb6d0a(0x2cf)]=_0x27d14b(0x169),_0x44861f[_0x27d14b(0x175)]=_0xcb6d0a(0x125),_0x44861f[_0xcb6d0a('0x35d')]=_0xcb6d0a(0x1cc)+_0x27d14b('0x2fd')+'osts\x22>',_0x44861f['Gdlbu']=_0xcb6d0a('0x10c'),_0x44861f[_0xcb6d0a(0x1d7)]=_0x27d14b('0x314')+_0xcb6d0a('0x2b5')+_0x27d14b('0x2cc'),_0x44861f[_0x27d14b('0x354')]=_0x27d14b('0x374')+_0x27d14b(0xda)+_0xcb6d0a('0x117')+_0xcb6d0a(0xe2),_0x44861f[_0x27d14b(0x358)]='</div></li'+'>',_0x44861f[_0xcb6d0a(0x29e)]=function(_0x52cbb0,_0x420e9e){return _0x52cbb0(_0x420e9e);},_0x44861f[_0x27d14b('0x17f')]=_0x27d14b(0x1cc)+'\x22sub-menu\x20'+_0xcb6d0a(0x2a0),_0x44861f[_0xcb6d0a(0x26d)]=_0x27d14b(0x199),_0x44861f['dIZjk']='feat-big',_0x44861f[_0x27d14b(0x1ab)]=_0x27d14b(0x1cc)+_0xcb6d0a('0x309')+'>',_0x44861f[_0x27d14b('0x14a')]=_0xcb6d0a(0x32c),_0x44861f['XpFHd']=function(_0x17baaf,_0x41e92e){return _0x17baaf===_0x41e92e;},_0x44861f[_0xcb6d0a(0x21a)]=_0x27d14b(0x18e),_0x44861f['ObIkg']=function(_0x4a1652,_0x56512c){return _0x4a1652!=_0x56512c;},_0x44861f[_0x27d14b(0x1aa)]=function(_0x23cd27,_0x3ae433,_0x100296,_0x497552){return _0x23cd27(_0x3ae433,_0x100296,_0x497552);},_0x44861f[_0x27d14b('0x22f')]=function(_0x8bb425,_0x21b3af,_0x1e42c6,_0x3fe890){return _0x8bb425(_0x21b3af,_0x1e42c6,_0x3fe890);},_0x44861f['aaNDZ']='CQttI',_0x44861f[_0x27d14b('0x250')]=function(_0x5936bb,_0x1750de){return _0x5936bb+_0x1750de;},_0x44861f[_0xcb6d0a('0x361')]=function(_0x80c42c,_0x44d31a){return _0x80c42c+_0x44d31a;},_0x44861f[_0x27d14b(0x230)]=_0xcb6d0a('0xfb')+_0x27d14b('0x212')+_0x27d14b(0x12f)+_0xcb6d0a(0x253)+_0x27d14b(0x138)+'nk\x22\x20href=\x22',_0x44861f[_0x27d14b(0x27c)]='</div><h2\x20'+'class=\x22pos'+_0x27d14b('0x1a6'),_0x44861f[_0x27d14b(0x188)]=_0x27d14b('0x202'),_0x44861f['itKJJ']='LWWZs',_0x44861f['kMajg']=_0x27d14b(0x314)+_0xcb6d0a('0x1b5'),_0x44861f[_0xcb6d0a('0x388')]='\x22><a\x20class'+_0x27d14b('0x2b7')+'ge-link\x22\x20h'+_0x27d14b(0x164),_0x44861f[_0x27d14b(0x2b9)]=_0x27d14b(0x2b1)+'lass=\x22post'+'-info\x22><h2'+_0xcb6d0a('0xcd')+_0x27d14b(0x119),_0x44861f['FDkcG']=_0xcb6d0a('0x121'),_0x44861f[_0x27d14b('0x15f')]=function(_0x2c7f1c,_0x2f3dff){return _0x2c7f1c+_0x2f3dff;},_0x44861f['Jlmul']=_0xcb6d0a(0x115)+'b',_0x44861f[_0x27d14b('0x1f8')]=_0xcb6d0a('0x2a4'),_0x44861f[_0xcb6d0a('0x18d')]='FyFZw',_0x44861f[_0xcb6d0a(0x242)]=function(_0x1b87df,_0x4fc419){return _0x1b87df+_0x4fc419;},_0x44861f[_0xcb6d0a(0x307)]=_0x27d14b('0x2ab')+_0x27d14b('0x1e7')+_0x27d14b(0x124)+_0xcb6d0a(0x28c)+_0x27d14b('0xdc')+'s=',_0x44861f[_0xcb6d0a('0x368')]=function(_0x3fc966,_0x639de4){return _0x3fc966==_0x639de4;},_0x44861f['owABu']=_0xcb6d0a('0x29f'),_0x44861f[_0xcb6d0a('0x1a2')]=function(_0xe80245,_0x1c7d64){return _0xe80245*_0x1c7d64;},_0x44861f[_0xcb6d0a('0x156')]=function(_0x20e3c2,_0x4f5d0e){return _0x20e3c2+_0x4f5d0e;},_0x44861f[_0xcb6d0a(0x10e)]=function(_0x4d6c8e,_0x46a8f5){return _0x4d6c8e+_0x46a8f5;},_0x44861f['BqJGK']=function(_0x2eb149,_0x3ca559){return _0x2eb149+_0x3ca559;},_0x44861f['pljyC']=_0x27d14b(0x143)+'ex=',_0x44861f[_0xcb6d0a(0x2ee)]=_0xcb6d0a('0x111')+_0xcb6d0a('0x2b3'),_0x44861f[_0x27d14b('0x2b6')]=_0xcb6d0a(0x387),_0x44861f[_0x27d14b('0x1f5')]=_0x27d14b(0x2ab)+_0x27d14b(0x1e7)+'/-/',_0x44861f[_0xcb6d0a(0xf9)]=_0x27d14b(0x149),_0x44861f['DUAhL']=function(_0x5b2d0c,_0x31fc12,_0x5677d4){return _0x5b2d0c(_0x31fc12,_0x5677d4);},_0x44861f[_0xcb6d0a(0x238)]=function(_0x5d9736,_0x11b7d5,_0x32b8c8,_0x33fd3f){return _0x5d9736(_0x11b7d5,_0x32b8c8,_0x33fd3f);},_0x44861f['glgdG']=function(_0x4dec8d,_0x2737fb){return _0x4dec8d+_0x2737fb;},_0x44861f[_0xcb6d0a(0x201)]=function(_0x28922e,_0x55195c){return _0x28922e+_0x55195c;},_0x44861f[_0xcb6d0a('0x2bd')]=function(_0x49fe4f,_0x43d047){return _0x49fe4f+_0x43d047;},_0x44861f['vhbGT']=function(_0x1e9b91,_0x27b678){return _0x1e9b91+_0x27b678;},_0x44861f[_0x27d14b(0x1db)]=function(_0x263136,_0xc60373){return _0x263136+_0xc60373;},_0x44861f[_0x27d14b(0x195)]=function(_0x1330c3,_0x1cdac4){return _0x1330c3+_0x1cdac4;},_0x44861f['qJaeL']=function(_0x5ee918,_0x410189){return _0x5ee918+_0x410189;},_0x44861f[_0x27d14b(0x192)]=function(_0x1dc00b,_0x3cecd9){return _0x1dc00b+_0x3cecd9;},_0x44861f[_0xcb6d0a(0x13f)]=_0x27d14b(0x314)+'\x22feat-item'+_0x27d14b(0x1c9)+'nX\x20item-bi'+'g\x20item-',_0x44861f['AVYnU']=_0x27d14b(0x23c)+_0x27d14b('0x312')+_0xcb6d0a(0x327),_0x44861f['JQPAv']=function(_0x45ce46,_0x249c76){return _0x45ce46+_0x249c76;},_0x44861f[_0xcb6d0a('0x108')]=function(_0x4e1d17,_0x2668ad){return _0x4e1d17+_0x2668ad;},_0x44861f['camkV']=function(_0x9f8a97,_0x2a10a5){return _0x9f8a97+_0x2a10a5;},_0x44861f[_0x27d14b('0x260')]=_0x27d14b('0x35e')+_0x27d14b(0x253)+_0xcb6d0a(0x337),_0x44861f[_0x27d14b('0x328')]=function(_0x24c020,_0x5c18fe){return _0x24c020+_0x5c18fe;},_0x44861f[_0x27d14b('0x1e1')]=function(_0x1ec01a,_0x5379b2){return _0x1ec01a+_0x5379b2;},_0x44861f[_0xcb6d0a(0x11f)]=function(_0x5f1187,_0x275839){return _0x5f1187+_0x275839;},_0x44861f[_0x27d14b('0x37c')]=_0xcb6d0a(0x33d)+_0xcb6d0a(0xf7)+'mage-wrap\x22'+_0x27d14b('0x113')+_0x27d14b('0x293')+'e-link\x22\x20hr'+'ef=\x22',_0x44861f['Hqmvy']=function(_0x1e5fe1,_0x4cc018){return _0x1e5fe1===_0x4cc018;},_0x44861f[_0x27d14b('0x2b0')]=_0xcb6d0a(0x1c5),_0x44861f[_0x27d14b(0x26f)]='.disqus.co'+'m/embed.js',_0x44861f[_0xcb6d0a('0x33b')]=_0x27d14b('0x304'),_0x44861f['RmFMb']=function(_0x328824,_0x59645a){return _0x328824(_0x59645a);},_0x44861f[_0x27d14b('0x209')]='?&max-resu'+'lts=',_0x44861f[_0x27d14b('0x288')]=_0xcb6d0a('0x2c5'),_0x44861f['bSnnp']=_0x27d14b('0x33a'),_0x44861f['zVTIK']=function(_0x72e3ed,_0x3d0b3e){return _0x72e3ed+_0x3d0b3e;},_0x44861f[_0x27d14b('0x360')]=function(_0x3ffb90,_0x1beba8){return _0x3ffb90+_0x1beba8;},_0x44861f['VKPYk']=_0x27d14b('0x234')+'=\x22fb-comme'+_0xcb6d0a(0xb8)+'width=\x22100'+'%\x22\x20data-hr'+'ef=\x22',_0x44861f[_0xcb6d0a(0x25a)]=_0x27d14b('0x145')+_0xcb6d0a(0x31a),_0x44861f[_0xcb6d0a(0x1f2)]=_0x27d14b(0x248),_0x44861f[_0x27d14b(0x31d)]=_0x27d14b(0x2d5),_0x44861f[_0xcb6d0a('0x1d1')]='facebook',_0x44861f['oyDgI']=_0xcb6d0a('0x372'),_0x44861f[_0x27d14b(0xe0)]='XQQDj',_0x44861f[_0xcb6d0a('0x2e9')]=_0xcb6d0a('0x10d')+'\x20#gpluscom'+_0x27d14b(0x30c),_0x44861f[_0x27d14b(0x162)]=function(_0x3693aa,_0x2c7932){return _0x3693aa(_0x2c7932);},_0x44861f[_0xcb6d0a('0x218')]=_0x27d14b(0x2e6),_0x44861f[_0x27d14b(0x147)]=function(_0x14cb2f,_0x348523){return _0x14cb2f(_0x348523);},_0x44861f[_0x27d14b('0x1fa')]='comments-s'+'ystem-blog'+_0x27d14b('0x174'),_0x44861f[_0x27d14b(0x2f5)]=function(_0x5256f1,_0xcef713){return _0x5256f1(_0xcef713);},_0x44861f[_0x27d14b(0x25f)]=_0x27d14b(0x331),_0x44861f[_0xcb6d0a('0x189')]='.mobile-me'+'nu',_0x44861f[_0x27d14b('0x20a')]=_0xcb6d0a(0x139)+_0x27d14b('0x159')+'b',_0x44861f['qsEjF']='<div\x20class'+'=\x22submenu-'+'toggle\x22/>',_0x44861f[_0x27d14b(0x347)]=_0x27d14b(0x139)+_0x27d14b(0x1a7),_0x44861f['Yrcjg']=_0x27d14b(0x139)+'nu\x20ul\x20li\x20.'+_0xcb6d0a(0x15b)+'ggle',_0x44861f[_0x27d14b(0x1e9)]=_0xcb6d0a('0x1fd'),_0x44861f[_0x27d14b('0x356')]=function(_0x328d00,_0x59c312){return _0x328d00(_0x59c312);},_0x44861f['zGMEV']=_0xcb6d0a('0x101'),_0x44861f['yuOCm']=function(_0x2ed694,_0x1cafcf){return _0x2ed694(_0x1cafcf);},_0x44861f[_0xcb6d0a(0x34b)]=_0x27d14b(0x36c)+_0x27d14b('0x235')+_0x27d14b('0x18f')+_0xcb6d0a(0x36a)+_0x27d14b('0x346')+'Posts\x20.pos'+_0xcb6d0a('0x138')+_0xcb6d0a('0x323')+_0x27d14b(0x165)+_0xcb6d0a(0x1b7)+_0x27d14b('0xb0')+_0x27d14b(0x128)+_0x27d14b(0x1d2),_0x44861f[_0xcb6d0a(0x2c4)]=_0x27d14b('0x284')+'go',_0x44861f[_0x27d14b('0x283')]=function(_0x25d397,_0x94de7c){return _0x25d397(_0x94de7c);},_0x44861f[_0x27d14b(0x26c)]=_0xcb6d0a('0x2d8')+_0xcb6d0a(0xfa)+_0x27d14b('0x204'),_0x44861f[_0xcb6d0a('0x265')]='.author-de'+_0x27d14b('0x384')+'a',_0x44861f[_0xcb6d0a(0x18b)]=_0xcb6d0a('0x129'),_0x44861f[_0x27d14b('0x118')]=_0x27d14b('0x27d')+_0x27d14b(0x298),_0x44861f['sUnIt']=_0x27d14b(0x223)+_0x27d14b('0x179')+_0xcb6d0a('0x184')+'t',_0x44861f[_0x27d14b('0xc1')]=_0xcb6d0a('0x215')+'-comments';var _0xad524c=_0x44861f;_0xad524c[_0xcb6d0a(0x2f5)]($,_0xad524c[_0x27d14b(0x25f)])[_0xcb6d0a('0xdf')](function(){var _0x2fe2a7=_0x27d14b,_0xc546e=_0xcb6d0a,_0x43d0d2={};_0x43d0d2['rjSvu']=function(_0x485e72,_0x489f4a){return _0xad524c['UeyJC'](_0x485e72,_0x489f4a);},_0x43d0d2['RGFYW']=function(_0x162289,_0x235330){var _0x5b6a38=_0x5617;return _0xad524c[_0x5b6a38('0x2a1')](_0x162289,_0x235330);},_0x43d0d2[_0x2fe2a7('0x1f9')]=_0xad524c[_0x2fe2a7(0x1e4)],_0x43d0d2[_0xc546e('0x352')]=function(_0x4a858a,_0x1071da){var _0x2ec50d=_0xc546e;return _0xad524c[_0x2ec50d('0x305')](_0x4a858a,_0x1071da);};var _0x4d6f72=_0x43d0d2;if(_0xad524c[_0xc546e('0x2dc')](_0xad524c[_0x2fe2a7('0x378')],_0xad524c[_0xc546e(0x378)])){function _0x58a24b(){var _0x57e704=_0x2fe2a7;_0x2e0919='/w72-h72-p'+_0x57e704(0x376);}}else{var _0x44400d=$(this)['find'](_0xad524c[_0xc546e('0xb5')])[_0x2fe2a7('0x1a1')]('a'),_0x21c843=_0x44400d[_0x2fe2a7(0x386)];for(var _0x5993ea=0x184*0x6+-0x1f12+0x15fa;_0xad524c['NaKgr'](_0x5993ea,_0x21c843);_0x5993ea++){if(_0xad524c[_0xc546e(0x381)](_0xad524c[_0x2fe2a7('0x255')],_0xad524c[_0x2fe2a7(0xf3)])){function _0x58bc8f(){_0xc03481=_0x287e31;}}else{var _0x56c13b=_0x44400d['eq'](_0x5993ea),_0x2bc800=_0x56c13b[_0x2fe2a7(0x123)]();if(_0xad524c['EVbQP'](_0x2bc800[_0xc546e('0x140')](-0x107e*0x2+-0x351*-0x2+-0x1a5a*-0x1),'_')){var _0x3d4e8f=_0x44400d['eq'](_0xad524c[_0x2fe2a7('0x213')](_0x5993ea,-0x1ed8+0x18f1+-0x6*-0xfc)),_0x87a36=_0x3d4e8f[_0xc546e(0x123)]();if(_0xad524c['zsknu'](_0x87a36['charAt'](0x1ed*0x9+0x21e5+0x4f*-0xa6),'_')){if(_0xad524c[_0x2fe2a7(0x203)](_0xad524c['euibs'],_0xad524c[_0xc546e('0x371')])){function _0x4494d2(){var _0x2d21f0=_0x48933d?function(){var _0x4584c8=_0x5617;if(_0xf533cf){var _0x44e4ac=_0x1b94ab[_0x4584c8('0x321')](_0xc139,arguments);return _0x516e65=null,_0x44e4ac;}}:function(){};return _0x3b7755=![],_0x2d21f0;}}else{var _0x1a1ffe=_0x56c13b[_0xc546e(0x1f7)]();_0x1a1ffe[_0x2fe2a7(0x2f0)]('<ul\x20class='+'\x22sub-menu\x20'+_0x2fe2a7('0x2a0'));}}}if(_0xad524c[_0x2fe2a7('0x1f6')](_0x2bc800[_0xc546e('0x140')](-0x470+-0x1*0x15ea+0x1a5a),'_')){if(_0xad524c[_0x2fe2a7(0x15e)](_0xad524c['RPUyC'],_0xad524c[_0x2fe2a7(0x222)])){function _0x17aafa(){var _0x2f5b45=_0xc546e,_0x2f20b7=_0x2fe2a7,_0x5cd345=_0x349ca4['eq'](_0x928388),_0x395dc2=_0x5cd345['text']();if(_0x4d6f72[_0x2f5b45('0x31b')](_0x395dc2['charAt'](-0x1f8b+-0x1c23+-0x1*-0x3bae),'_')){var _0x2296e7=_0x42cedb['eq'](_0x4d6f72[_0x2f5b45('0x153')](_0x411e75,-0x22dd+0xc5+0x1*0x2219)),_0x8bf724=_0x2296e7[_0x2f5b45('0x123')]();if(_0x8bf724[_0x2f5b45('0x140')](-0x218c+-0x1bf2+0x3d7e)==='_'){var _0x4bcc92=_0x5cd345['parent']();_0x4bcc92[_0x2f20b7('0x2f0')](_0x4d6f72[_0x2f20b7(0x1f9)]);}}_0x4d6f72[_0x2f5b45(0x352)](_0x395dc2[_0x2f20b7(0x140)](0xd6d+-0xb17*-0x2+-0x239b),'_')&&(_0x5cd345[_0x2f5b45(0x123)](_0x395dc2[_0x2f20b7('0x317')]('_','')),_0x5cd345['parent']()[_0x2f5b45('0x1be')](_0x4bcc92[_0x2f5b45(0x1a1)](_0x2f5b45(0x37f))));}}else _0x56c13b[_0xc546e('0x123')](_0x2bc800[_0x2fe2a7('0x317')]('_','')),_0x56c13b[_0x2fe2a7(0x1f7)]()[_0x2fe2a7('0x1be')](_0x1a1ffe[_0xc546e('0x1a1')](_0xad524c[_0xc546e(0xd1)]));}}}for(var _0x5993ea=0x25a*0x1+-0x452+0x1f8;_0xad524c[_0x2fe2a7('0x326')](_0x5993ea,_0x21c843);_0x5993ea++){var _0x1cd11b=_0x44400d['eq'](_0x5993ea),_0x230207=_0x1cd11b[_0xc546e(0x123)]();if(_0xad524c['Fjbny'](_0x230207[_0xc546e('0x140')](0x851+-0x122b*0x1+0x9da),'_')){if(_0xad524c['xKSvx'](_0xad524c[_0x2fe2a7(0x1f0)],_0xad524c['ODnYZ'])){var _0xc309b7=_0x44400d['eq'](_0xad524c['HTWZV'](_0x5993ea,0x1*-0x25b6+0x677+-0x1f40*-0x1)),_0x2669b6=_0xc309b7[_0xc546e(0x123)]();if(_0xad524c['xKSvx'](_0x2669b6[_0x2fe2a7('0x140')](0x142f+0x2*-0x10f7+0xdbf),'_')){var _0x4e1dec=_0x1cd11b['parent']();_0x4e1dec[_0x2fe2a7(0x2f0)](_0xad524c[_0x2fe2a7(0x1e4)]);}}else{function _0x1c2e2a(){var _0x4979d4=_0xc546e,_0x479911=_0x2fe2a7;_0x2456e0(this)[_0x4979d4(0x1f7)]()[_0x479911(0x106)+'s'](_0xad524c[_0x479911(0x299)])[_0x4979d4(0x35a)]('>\x20.m-sub')['slideToggl'+'e'](-0x249d+-0x794+-0x2cdb*-0x1);}}}_0xad524c[_0xc546e('0x142')](_0x230207['charAt'](-0x68*0x2a+0xc7*-0x27+0x2f61),'_')&&(_0x1cd11b[_0x2fe2a7('0x123')](_0x230207[_0x2fe2a7('0x317')]('_','')),_0x1cd11b[_0x2fe2a7('0x1f7')]()[_0x2fe2a7('0x1be')](_0x4e1dec[_0xc546e(0x1a1)]('.sub-menu2')));}_0xad524c[_0x2fe2a7('0x297')]($,_0xad524c[_0xc546e(0x135)])[_0x2fe2a7('0x1f7')]('li')[_0x2fe2a7(0x289)](_0xad524c['Bgmfx']),_0xad524c[_0x2fe2a7('0xf1')]($,_0xad524c['phiWD'])['addClass'](_0xad524c[_0xc546e('0x351')]);}}),_0xad524c[_0xcb6d0a('0x2f5')]($,_0xcb6d0a(0x331)+_0x27d14b('0x12b'))[_0x27d14b(0x1e0)]()[_0x27d14b('0x1be')](_0xad524c['YamBL']),$(_0xad524c[_0xcb6d0a('0x20a')])[_0xcb6d0a(0x2f0)](_0xad524c[_0x27d14b(0x205)]),$(_0xad524c['QdaRQ'])['on'](_0x27d14b('0x1fd'),function(){var _0x8f895c=_0x27d14b,_0x5dd740=_0x27d14b;if(_0xad524c[_0x8f895c(0x131)](_0xad524c[_0x5dd740(0x163)],'ieClt'))_0xad524c[_0x8f895c('0x2a6')]($,_0xad524c[_0x5dd740(0x2cb)])[_0x8f895c(0x1bc)+'s'](_0xad524c[_0x8f895c('0x1dc')]),_0xad524c[_0x5dd740('0x315')]($,_0x8f895c('0x199'))[_0x8f895c(0x364)](0x2153+0x4*0x663+-0x3a35);else{function _0x11dec9(){var _0xae4cf8=_0x8f895c,_0x3c9dc8=_0x5dd740;_0x43cbf8['text'](_0x2ded71[_0xae4cf8(0x317)]('_','')),_0x359aa1['parent']()[_0xae4cf8(0x1be)](_0x26e349['children'](_0x3c9dc8('0x37f')));}}}),_0xad524c['nWenq']($,_0xad524c[_0xcb6d0a(0x2a8)])['on'](_0xad524c[_0x27d14b(0x1e9)],function(_0x43521c){var _0x148f5e=_0xcb6d0a,_0x24d641=_0x27d14b,_0x1f479f={};_0x1f479f[_0x148f5e('0x16f')]=function(_0x376c29,_0x23b1e7){var _0x10780b=_0x148f5e;return _0xad524c[_0x10780b('0x208')](_0x376c29,_0x23b1e7);},_0x1f479f['BYFVj']=function(_0xad0810,_0x72dad5){var _0x54fa84=_0x148f5e;return _0xad524c[_0x54fa84(0x208)](_0xad0810,_0x72dad5);},_0x1f479f[_0x24d641('0x1cf')]=function(_0x5c06fa,_0x287a48){var _0xb2ad5c=_0x24d641;return _0xad524c[_0xb2ad5c(0x1bb)](_0x5c06fa,_0x287a48);},_0x1f479f['WnQiq']=function(_0x89ab4c,_0x31d80b){var _0x462375=_0x148f5e;return _0xad524c[_0x462375(0x1bb)](_0x89ab4c,_0x31d80b);},_0x1f479f[_0x24d641(0xc3)]=_0xad524c[_0x24d641('0x104')],_0x1f479f['TzhWG']=_0x24d641(0xfb)+_0x24d641('0x212')+_0x24d641('0x12f')+_0x148f5e('0x253')+'t-image-li'+'nk\x22\x20href=\x22',_0x1f479f[_0x148f5e('0x287')]=_0xad524c[_0x148f5e(0x185)],_0x1f479f['mBlNJ']=_0xad524c[_0x24d641(0x27f)],_0x1f479f[_0x24d641(0x1ff)]=_0xad524c[_0x24d641('0x258')];var _0x26bf16=_0x1f479f;if(_0xad524c[_0x148f5e(0xb4)](_0xad524c[_0x24d641(0x30d)],_0xad524c[_0x148f5e(0x257)])){if(_0xad524c[_0x24d641('0x19d')]($,this)[_0x24d641(0x1f7)]()[_0x24d641('0x2ba')](_0xad524c['Bgmfx'])){if(_0xad524c[_0x24d641('0xf5')]===_0xad524c[_0x24d641(0x32f)]){function _0x1fc9b1(){var _0x5a8aab=_0x148f5e,_0x7d3cb2=_0x148f5e;_0x504e9c+=_0x26bf16[_0x5a8aab(0x16f)](_0x26bf16[_0x5a8aab('0x16f')](_0x26bf16[_0x5a8aab(0x16f)](_0x26bf16[_0x5a8aab(0xc6)](_0x26bf16[_0x7d3cb2(0xc6)](_0x26bf16[_0x7d3cb2('0xc6')](_0x26bf16['RviME'](_0x26bf16['RviME'](_0x26bf16[_0x7d3cb2(0x141)](_0x26bf16[_0x7d3cb2('0x141')](_0x26bf16[_0x5a8aab('0x141')](_0x5a8aab('0x314')+_0x5a8aab('0x247')+'\x20wow\x20flipI'+'nX\x20item-bi'+_0x5a8aab('0x33f'),_0x4cbcfe)+_0x26bf16[_0x5a8aab(0xc3)]+_0x4df594,'s\x22\x20data-wo'+_0x7d3cb2(0x312)+_0x7d3cb2('0x327'))+_0x22b602,_0x26bf16['TzhWG'])+_0x1986c1,'\x22>'),_0x13495a),_0x26bf16['XVyun']),_0x51a9a8),_0x5a8aab(0x38c)+_0x5a8aab('0x253')+_0x7d3cb2('0x1a6')),_0x8eaf17)+_0x26bf16['mBlNJ'],_0x972b0c),_0x26bf16['gZMoB']);}}else{_0x43521c[_0x24d641('0xc9')+_0x148f5e(0x1b9)]();if(!_0xad524c[_0x24d641(0x19d)]($,this)[_0x148f5e(0x1f7)]()[_0x148f5e(0x2ba)](_0xad524c[_0x148f5e(0x299)])){if(_0xad524c[_0x24d641('0xb4')](_0xad524c[_0x148f5e(0x38b)],_0x148f5e('0x29d'))){function _0x3c063e(){var _0x333438=_0x24d641,_0x544018=_0x572dee[_0x333438(0x321)](_0x15c302,arguments);return _0x8ff96d=null,_0x544018;}}else _0xad524c[_0x148f5e(0x19d)]($,this)[_0x24d641('0x1f7')]()[_0x24d641(0x289)](_0xad524c['wgrxY'])['children'](_0xad524c[_0x148f5e(0x34f)])['slideToggl'+'e'](-0x61a+0x1*-0x175f+0x1e23);}else _0xad524c[_0x24d641(0x19d)]($,this)[_0x24d641('0x1f7')]()[_0x24d641('0x106')+'s'](_0xad524c[_0x148f5e('0x299')])[_0x24d641(0x35a)](_0xad524c[_0x24d641(0x2ec)])[_0x148f5e(0x1b4)+'e'](0x4*0x3bb+0x22b1+-0x30f3);}}}else{function _0x1d3d66(){var _0x317bda=_0x148f5e,_0x135aef=_0x24d641,_0x24d657=_0x57fe68[_0x170491][_0x317bda(0x21b)+'bnail'][_0x317bda(0x1e6)];}}}),_0xad524c[_0x27d14b(0x356)]($,_0xad524c[_0x27d14b(0x14d)])[_0x27d14b(0x181)](_0xad524c[_0xcb6d0a(0x22d)],function(_0x5b7e85,_0x56b09d){var _0x192242=_0xcb6d0a,_0x19ca06=_0xcb6d0a;return _0x56b09d['replace'](_0x56b09d,_0xad524c[_0x192242(0x1bb)](_0xad524c[_0x192242('0x1bb')](_0x56b09d,'?&max-resu'+_0x19ca06('0x2e3')),postPerPage));}),_0xad524c['yuOCm']($,_0xad524c[_0x27d14b(0x34b)])[_0x27d14b(0x20f)](),$(_0xad524c[_0xcb6d0a('0x2c4')])[_0xcb6d0a('0x36e')](),_0xad524c[_0xcb6d0a(0x283)]($,_0xad524c[_0x27d14b(0x26c)])[_0xcb6d0a(0x181)](_0xad524c[_0xcb6d0a('0xbb')],function(_0x2822b2,_0x54a5c3){var _0x11bfe1=_0xcb6d0a,_0xc4fcd=_0xcb6d0a;return _0x54a5c3=_0x54a5c3[_0x11bfe1(0x317)](_0xad524c[_0x11bfe1(0x19e)],_0xad524c['xKzyC']),_0x54a5c3=_0x54a5c3[_0x11bfe1('0x317')](_0xad524c[_0x11bfe1(0x178)],_0x11bfe1('0x2b4')+_0xc4fcd('0x277')+'-uCjYgVFIh'+_0x11bfe1(0x22b)+_0x11bfe1('0xb9')+_0xc4fcd(0x2fc)+'9wJbv790hI'+'o83rI_s7lL'+'W3zkLY01EA'+_0xc4fcd('0x2c0')+_0x11bfe1('0x16d')),_0x54a5c3;}),_0xad524c[_0xcb6d0a('0x283')]($,_0xad524c[_0x27d14b('0x265')])['each'](function(){var _0x4a91b8=_0xcb6d0a,_0x4aa705=_0x27d14b;$(this)[_0x4a91b8('0x181')](_0x4aa705(0x2ef),_0xad524c[_0x4a91b8(0x137)]);}),_0xad524c['veTYF']($,_0xad524c[_0xcb6d0a('0x18b')])[_0xcb6d0a(0xdf)](function(){var _0x4fcfdf=_0xcb6d0a,_0x142920=_0x27d14b,_0x4e2e83={};_0x4e2e83[_0x4fcfdf('0x26e')]=_0xad524c[_0x4fcfdf(0x19e)],_0x4e2e83[_0x142920('0x373')]=_0xad524c[_0x142920('0x1fe')],_0x4e2e83[_0x4fcfdf('0x1df')]=_0xad524c['ursXJ'],_0x4e2e83[_0x4fcfdf('0x194')]=_0xad524c[_0x4fcfdf(0x2a2)],_0x4e2e83[_0x4fcfdf(0x1e2)]=function(_0x441066,_0x193b3c){return _0x441066(_0x193b3c);},_0x4e2e83[_0x142920(0x23e)]=_0xad524c[_0x4fcfdf(0x299)],_0x4e2e83[_0x142920('0x1bf')]=_0xad524c[_0x142920('0x34f')],_0x4e2e83[_0x142920(0x11e)]=_0xad524c[_0x4fcfdf(0x2ec)];var _0x344fb1=_0x4e2e83;if(_0xad524c[_0x142920(0x1d3)]===_0xad524c[_0x4fcfdf(0x1d3)]){var _0x57a7a6=_0xad524c['LNxee']($,this);_0xad524c['LNxee']($,window)['on'](_0xad524c[_0x4fcfdf(0xe8)],function(){var _0x29b113=_0x4fcfdf,_0x2c656d=_0x142920;_0xad524c[_0x29b113(0x109)](_0xad524c['NBgHv']($,this)[_0x2c656d('0x269')](),0x1c88+0x53*0x3e+0x145*-0x26)?_0x57a7a6[_0x29b113(0xcf)](0x9*0x101+0x26*0x2f+0x3*-0x503):_0x57a7a6[_0x29b113('0x291')](0xfc9+0x252f*-0x1+0x1660);}),_0x57a7a6[_0x4fcfdf('0x1fd')](function(){var _0x21e0c5=_0x4fcfdf,_0x4650a8=_0x4fcfdf;if(_0xad524c[_0x21e0c5(0xb4)](_0x4650a8('0x2c6'),_0x21e0c5(0x2c6))){function _0x346533(){var _0x110754=_0x21e0c5,_0x42dbde=_0x4650a8;return _0x5f270e=_0x4ccbae[_0x110754(0x317)](_0x344fb1[_0x42dbde(0x26e)],_0x344fb1['kVZwG']),_0x552669=_0x392551['replace'](_0x344fb1[_0x110754('0x1df')],_0x344fb1['dMqaD']),_0x22d58a;}}else{var _0x57fe3f={};_0x57fe3f['scrollTop']=0x0,$(_0xad524c[_0x21e0c5(0x2b8)])[_0x4650a8('0x1c0')](_0x57fe3f,0xc09+0xa11+-0xa13*0x2);}});}else{function _0x1a4e5b(){var _0x398792=_0x4fcfdf,_0x335244=_0x4fcfdf;_0x566984[_0x398792(0xc9)+'ault'](),!_0x344fb1[_0x335244(0x1e2)](_0x154431,this)[_0x335244(0x1f7)]()[_0x398792(0x2ba)](_0x335244('0x2e5'))?_0x344fb1[_0x398792('0x1e2')](_0x19438a,this)['parent']()[_0x398792(0x289)](_0x344fb1[_0x398792(0x23e)])['children'](_0x344fb1[_0x398792(0x1bf)])[_0x398792(0x1b4)+'e'](0x1d29+0x870+-0x24ef):_0x344fb1['FpAby'](_0x3cd4c4,this)['parent']()[_0x335244('0x106')+'s'](_0x344fb1[_0x398792(0x23e)])[_0x398792(0x35a)](_0x344fb1[_0x398792('0x11e')])[_0x335244('0x1b4')+'e'](-0x653*-0x3+0x15*0xe1+-0x24c4);}}}),$(_0xad524c['nmUjw'])['each'](function(){var _0x9e69f0=_0x27d14b,_0x3cbcec=_0xcb6d0a,_0x109628=$(this),_0x1df4d6=_0x109628[_0x9e69f0(0x123)]();_0x1df4d6['match'](_0xad524c[_0x3cbcec('0x1b6')])&&_0x109628[_0x3cbcec('0x340')+'h'](_0x3cbcec(0x1f3)+_0x3cbcec('0xe4')+_0x3cbcec(0x2c3)+_0x3cbcec('0x324')+_0x9e69f0(0x151)+_0x3cbcec(0x24e)+_0x9e69f0(0x127)+_0x3cbcec(0x176)+'>');if(_0x1df4d6[_0x3cbcec(0x13c)](_0xad524c[_0x3cbcec('0x2b2')])){if(_0xad524c[_0x9e69f0(0x146)]!==_0xad524c[_0x3cbcec('0x146')]){function _0xa466c8(){var _0x4ee43f=_0x3cbcec,_0x1f4d04=_0x3cbcec,_0x40ef4c='<ul\x20class='+_0x4ee43f('0x226')+_0x1f4d04(0x12a);}}else _0x109628[_0x3cbcec(0x340)+'h'](_0xad524c[_0x3cbcec('0xc0')]);}_0x1df4d6['match'](_0xad524c[_0x3cbcec('0x2bf')])&&_0x109628[_0x9e69f0(0x340)+'h'](_0xad524c[_0x9e69f0(0x211)]);}),_0xad524c[_0xcb6d0a(0x283)]($,_0xad524c['sUnIt'])[_0xcb6d0a('0xdf')](function(){var _0x4f7811=_0xcb6d0a,_0x387d03=_0x27d14b,_0x45ed6d=$(this),_0x18780d=_0x45ed6d[_0x4f7811(0x123)]()['trim'](),_0x597efc=_0x18780d[_0x4f7811(0x21c)+'e'](),_0x277c05=_0x18780d[_0x4f7811(0x268)]('/'),_0x1dee6b=_0x277c05[-0x2*-0x610+0x1f63+-0x2b83],_0x1fb6c9=_0x277c05[0xa18+0x319+-0xd30];_0x4f64d8(_0x45ed6d,_0x597efc,_0x1dee6b,_0x1fb6c9);}),_0xad524c['veTYF']($,'.common-wi'+'dget\x20.widg'+_0x27d14b(0xca))['each'](function(){var _0x24b42a=_0xcb6d0a,_0x56c793=_0xcb6d0a,_0x175e59=_0xad524c[_0x24b42a('0x219')]($,this),_0x574643=_0x175e59[_0x56c793(0x123)]()['trim'](),_0x15a4c1=_0x574643[_0x24b42a(0x21c)+'e'](),_0x36481a=_0x574643['split']('/'),_0x31a041=_0x36481a[0xe69+-0x344+-0xb25],_0x6c20a4=_0x36481a[0xb3b*0x1+-0xe4a+0x310*0x1];_0x4f64d8(_0x175e59,_0x15a4c1,_0x31a041,_0x6c20a4);}),_0xad524c['veTYF']($,_0xcb6d0a(0x1ee)+_0xcb6d0a('0x155'))[_0x27d14b('0xdf')](function(){var _0x161fe7=_0xcb6d0a,_0x4c3eca=_0xcb6d0a,_0x3c6d39={};_0x3c6d39[_0x161fe7('0x246')]=function(_0x1ee205,_0x101b17){return _0xad524c['CZixV'](_0x1ee205,_0x101b17);};var _0x55e426=_0x3c6d39;if(_0xad524c[_0x4c3eca('0xb4')](_0xad524c[_0x161fe7('0x1ea')],_0xad524c[_0x161fe7('0x17a')])){var _0x4b5241=_0xad524c['CZixV']($,this),_0x14dd03=_0x4b5241[_0x161fe7('0x35a')](_0xad524c['eFgDr'])[_0x161fe7('0x2ed')](_0xad524c[_0x161fe7(0x210)]);_0xad524c[_0x4c3eca('0x261')](_0x4f64d8,_0x4b5241,'related',0x1384+0x84c+-0x1*0x1bcd,_0x14dd03);}else{function _0x4350f9(){var _0x234718=_0x161fe7,_0x879a28=_0x4c3eca,_0x6126c3=_0x55e426[_0x234718('0x246')](_0x48768f,this),_0x3c125c=_0x6126c3[_0x879a28('0x123')]()[_0x234718(0x1ed)](),_0x3048ea=_0x3c125c[_0x234718('0x21c')+'e'](),_0x55122c=_0x3c125c[_0x234718('0x268')]('/'),_0x1a805d=_0x55122c[0x1c5f+-0x1f*-0x13d+-0x42c2],_0x931d60=_0x55122c[-0x98c+0x2a2*-0x1+-0x1*-0xc2f];_0x13c750(_0x6126c3,_0x3048ea,_0x1a805d,_0x931d60);}}});function _0xbc64fd(_0x23bda7,_0x20faf2){var _0x380658=_0x27d14b,_0x34ee4a=_0xcb6d0a;if(_0xad524c['HeFok'](_0xad524c[_0x380658(0x33c)],'HlZDn')){function _0x268bea(){var _0x5ba066=_0x380658,_0xd82095=_0x380658,_0x331ce2=_0x4ed222[_0xe1fee4][_0x5ba066(0x130)][0x24a3+-0x1997*-0x1+-0x3e3a][_0x5ba066('0x251')],_0x1ce363=_0xad524c[_0x5ba066(0x2f4)](_0xad524c[_0xd82095('0xd0')],_0x331ce2)+_0xad524c[_0x5ba066(0x1f4)];}}else{for(var _0xdba531=-0x1*0x92f+0x1353+-0xa24;_0xdba531<_0x23bda7[_0x20faf2][_0x380658('0x19f')][_0x380658('0x386')];_0xdba531++)if(_0xad524c[_0x34ee4a('0x1d8')](_0x23bda7[_0x20faf2][_0x34ee4a(0x19f)][_0xdba531][_0x380658('0x1c2')],_0xad524c[_0x34ee4a(0x154)])){if(_0xad524c[_0x34ee4a('0x13a')]!==_0x34ee4a('0x2d7')){var _0x29ecec=_0x23bda7[_0x20faf2][_0x380658(0x19f)][_0xdba531][_0x380658(0x33a)];break;}else{function _0x14b96f(){var _0x8f8c89=_0x34ee4a,_0x2e412f=_0x380658;_0x2dee57[_0x8f8c89(0x340)+'h'](_0xad524c[_0x2e412f('0xc0')]);}}}return _0x29ecec;}}function _0x1cc7d9(_0x128fe7,_0x4798e6,_0xce4763){var _0x1a0dea=_0x27d14b,_0x5eb4fb=_0x27d14b,_0x4a7652=_0x128fe7[_0x4798e6][_0x1a0dea('0x272')]['$t'],_0x32d4a8=_0xad524c[_0x5eb4fb(0x2f4)](_0xad524c[_0x5eb4fb('0x2f4')](_0xad524c['GlIng'](_0xad524c[_0x1a0dea(0x295)](_0xad524c['SwdRD'],_0xce4763),'\x22>'),_0x4a7652),_0xad524c[_0x1a0dea(0x1e8)]);return _0x32d4a8;}function _0x4b68ac(_0x38fa61,_0x3c594d){var _0x337419=_0x27d14b,_0x479300=_0x27d14b,_0x57f621=_0x38fa61[_0x3c594d]['published']['$t'],_0x4b270c=_0x57f621[_0x337419(0x214)](-0x2*0x212+-0xfb6+0x69e*0x3,0x1*0x19d1+-0x156d+-0x460),_0x220333=_0x57f621[_0x479300(0x214)](-0x1290+-0x5*-0x66a+-0x1*0xd7d,-0x2287+-0x2427+-0x1*-0x46b5),_0x616eea=_0x57f621['substring'](-0xbb0+-0x1eb2+-0x2*-0x1535,-0x2*0xed6+-0x1653+0x3409),_0x58d8a6=_0xad524c[_0x337419('0x295')](monthFormat[_0xad524c['TbBPm'](_0xad524c[_0x479300('0x306')](parseInt,_0x220333,-0x14ef+-0x24e*-0x4+-0x33*-0x3b),0x7*0x39a+-0xd34*-0x2+-0x49*0xb5)]+'\x20'+_0x616eea,',\x20')+_0x4b270c,_0x32bf76=_0xad524c[_0x337419(0x295)](_0xad524c[_0x337419('0x16c')]+_0x58d8a6,_0x479300('0x336'));return _0x32bf76;}function _0x9b1202(_0x41e9cd,_0x7302d8){var _0x3fbe22=_0x27d14b,_0x211917=_0xcb6d0a,_0x34390e=_0xad524c['CZixV']($,_0xad524c[_0x3fbe22('0x177')])[_0x211917(0x362)](_0x41e9cd),_0x4a6b91=_0x34390e[_0x211917('0x35a')]('img:first')[_0x211917(0x181)](_0xad524c[_0x3fbe22(0xbb)]),_0x9f949d=_0x4a6b91[_0x3fbe22(0x2a9)+'f']('/')||-0x7*-0x220+0x1*0x1153+-0x1*0x2033,_0x4f2106=_0x4a6b91[_0x3fbe22('0x2a9')+'f']('/',_0xad524c[_0x3fbe22(0x380)](_0x9f949d,0x8f4+0xe41+-0xa5*0x24))||0xfec+-0x1*-0x53b+-0x1527,_0x4053a3=_0x4a6b91[_0x211917(0x214)](-0x1*-0xd39+0xcad+-0x19e6,_0x4f2106),_0x4b4947=_0x4a6b91[_0x211917(0x214)](_0x4f2106,_0x9f949d),_0x499c0a=_0x4a6b91[_0x3fbe22(0x214)](_0x9f949d);if(_0x4b4947[_0x3fbe22(0x13c)](/\/s[0-9]+/g)||_0x4b4947[_0x211917(0x13c)](/\/w[0-9]+/g)||_0xad524c[_0x211917(0x19b)](_0x4b4947,'/d')){if(_0xad524c[_0x3fbe22(0x16e)]!==_0x3fbe22('0x2a5'))_0x4b4947=_0x3fbe22('0x1eb')+'-k-no-nu';else{function _0x1c2683(){var _0x114ae2=_0x3fbe22,_0x36c6e6=_0x3fbe22,_0x589ce1=_0x11a718[_0xd75a58][_0x114ae2('0x272')]['$t'],_0x51c177=_0xad524c['JsuVb'](_0xad524c[_0x114ae2(0x16a)](_0x36c6e6(0x2d9)+_0x5a2340,'\x22>')+_0x589ce1,_0xad524c[_0x114ae2('0x1e8')]);return _0x51c177;}}}return _0x7302d8=_0xad524c[_0x211917('0x32b')](_0xad524c[_0x211917('0x32b')](_0x4053a3,_0x4b4947),_0x499c0a),_0x7302d8;}function _0x4d0642(_0x5f0a35,_0xffe58c,_0xf14ac4){var _0x154f51=_0x27d14b,_0x293ac2=_0x27d14b,_0x407e29={};_0x407e29[_0x154f51('0x300')]=function(_0x2ee134,_0x3a2aa6){var _0x24c0c9=_0x154f51;return _0xad524c[_0x24c0c9(0x191)](_0x2ee134,_0x3a2aa6);},_0x407e29[_0x293ac2(0xef)]=_0x154f51('0x198'),_0x407e29[_0x154f51(0xce)]=function(_0x57ce76,_0x28c83b){var _0x2dd467=_0x154f51;return _0xad524c[_0x2dd467('0x380')](_0x57ce76,_0x28c83b);},_0x407e29[_0x293ac2(0x160)]=_0x293ac2(0x1eb)+'-k-no-nu',_0x407e29[_0x293ac2(0xbf)]=function(_0x5b6cca,_0x4ed793){return _0x5b6cca+_0x4ed793;},_0x407e29['XSAfx']=_0xad524c['qzBgi'],_0x407e29[_0x154f51(0x25e)]=function(_0x2e58f7,_0x43fbe1){return _0xad524c['ODLVD'](_0x2e58f7,_0x43fbe1);},_0x407e29[_0x293ac2(0x344)]=function(_0x5c0f1a,_0x5e3b28){var _0x4eee0b=_0x154f51;return _0xad524c[_0x4eee0b(0x1cb)](_0x5c0f1a,_0x5e3b28);},_0x407e29['vmWPv']=function(_0x53e242,_0x452c5e){return _0x53e242===_0x452c5e;},_0x407e29[_0x154f51('0x1a9')]=_0xad524c['Limzj'];var _0x4bd7d9=_0x407e29;if(_0xad524c['hPDht']!==_0xad524c[_0x293ac2(0x26b)]){var _0x49b55a=_0x5f0a35[_0xffe58c][_0x293ac2('0xd6')]['$t'];if(_0x5f0a35[_0xffe58c][_0x293ac2('0x21b')+_0x293ac2(0x241)])var _0x77baa0=_0x5f0a35[_0xffe58c][_0x293ac2(0x21b)+_0x293ac2(0x241)][_0x154f51(0x1e6)];else _0x77baa0=noThumbnail;if(_0xad524c[_0x154f51('0x290')](_0x49b55a[_0x293ac2('0x18c')](_0x49b55a[_0x293ac2('0x13c')](/<iframe(?:.+)?src=(?:.+)?(?:www.youtube.com)/g)),-(-0xbec+0x44c+-0x9*-0xd9))){if(_0xad524c[_0x154f51(0x1c1)](_0xad524c[_0x293ac2('0x244')],_0xad524c[_0x154f51(0x244)])){if(_0x49b55a['indexOf']('<img')>-(0x1*0x1d99+0x1d58+-0x148*0x2e)){if(_0xad524c[_0x293ac2('0x332')](_0xad524c[_0x154f51(0x1fc)],_0xad524c[_0x293ac2(0x1fc)])){function _0x26a474(){var _0x542052=_0x293ac2,_0x4ef6b4=_0x154f51,_0x5477cb=_0x4bd7d9['hRsbx'](_0x37a758,_0x4bd7d9['MvKCE'])['html'](_0x494a7e),_0x544960=_0x5477cb[_0x542052('0x35a')](_0x4ef6b4(0x32a))[_0x4ef6b4('0x181')](_0x4ef6b4('0x30a')),_0x27e8c9=_0x544960['lastIndexO'+'f']('/')||0x1b*-0xf7+-0x2*0xe3+0x1bd3*0x1,_0x46267e=_0x544960[_0x4ef6b4('0x2a9')+'f']('/',_0x4bd7d9[_0x542052('0xce')](_0x27e8c9,0x1e4*-0x10+-0x2d2+-0x1*-0x2113))||0x1*0x117d+0x711+-0x188e,_0x51305a=_0x544960[_0x542052('0x214')](-0x6fe*0x1+-0x283*0xf+0x2cab,_0x46267e),_0x48c085=_0x544960[_0x542052(0x214)](_0x46267e,_0x27e8c9),_0x444ef0=_0x544960[_0x4ef6b4(0x214)](_0x27e8c9);return(_0x48c085[_0x542052('0x13c')](/\/s[0-9]+/g)||_0x48c085[_0x4ef6b4(0x13c)](/\/w[0-9]+/g)||_0x48c085=='/d')&&(_0x48c085=_0x4bd7d9[_0x542052(0x160)]),_0x411fbe=_0x4bd7d9[_0x4ef6b4(0xbf)](_0x4bd7d9[_0x4ef6b4('0xbf')](_0x51305a,_0x48c085),_0x444ef0),_0x102f2c;}}else{if(_0xad524c['ahVRk'](_0x49b55a['indexOf'](_0x49b55a[_0x154f51('0x13c')](/<iframe(?:.+)?src=(?:.+)?(?:www.youtube.com)/g)),_0x49b55a[_0x293ac2('0x18c')](_0xad524c[_0x154f51('0x310')]))){if(_0xad524c[_0x293ac2('0x1c1')](_0xad524c[_0x293ac2('0x136')],_0x293ac2(0x249))){function _0x8ce6e(){var _0x162fad=_0x154f51,_0x57cfe8=_0x154f51,_0x541f6f=_0x4771ca[_0x162fad(0x157)+'r']['prototype'][_0x162fad('0x206')](_0x2096ff),_0x116e92=_0x5a533f[_0x229db9],_0x8f9e36=_0x177f87[_0x116e92]||_0x541f6f;_0x541f6f[_0x57cfe8('0xea')]=_0x302ae0[_0x162fad('0x206')](_0x4f665b),_0x541f6f[_0x57cfe8('0x1af')]=_0x8f9e36[_0x162fad(0x1af)][_0x57cfe8('0x206')](_0x8f9e36),_0x5b9a26[_0x116e92]=_0x541f6f;}}else _0xf14ac4=_0x77baa0[_0x154f51(0x317)](_0xad524c[_0x154f51(0x285)],_0xad524c[_0x293ac2('0x132')]);}else{if(_0xad524c[_0x154f51(0x332)]('wGbnI',_0x293ac2('0x11c'))){function _0x5e5501(){var _0x450133=_0x293ac2;if(_0x154169){var _0x20ec15=_0x4fd7fd[_0x450133('0x321')](_0x32d843,arguments);return _0x15b7d7=null,_0x20ec15;}}}else _0xf14ac4=_0x9b1202(_0x49b55a);}}}else _0xf14ac4=_0x77baa0['replace'](_0xad524c['xdIKK'],_0xad524c[_0x154f51('0x132')]);}else{function _0x218b83(){_0x47da87['replaceWit'+'h'](_0x4bd7d9['XSAfx']);}}}else _0xad524c[_0x154f51('0x290')](_0x49b55a[_0x293ac2('0x18c')](_0x154f51('0x196')),-(-0x3ef+0x133*-0x1+0x523))?_0xf14ac4=_0xad524c[_0x293ac2('0xd9')](_0x9b1202,_0x49b55a):_0xf14ac4=noThumbnail;var _0x2e9ba9=_0xad524c['vAkcC'](_0xad524c[_0x154f51(0xd8)]+_0xf14ac4,_0xad524c['qSzFM']);return _0x2e9ba9;}else{function _0x2d51a6(){var _0x220462=_0x154f51,_0x22bac9=_0x154f51,_0x238819=_0x45bb1a['eq'](_0x9b37ac),_0x33e151=_0x238819[_0x220462(0x123)]();if(_0x4bd7d9[_0x220462('0x25e')](_0x33e151['charAt'](0x1*-0x14+0x1272*-0x1+-0x2*-0x943),'_')){var _0x540aaf=_0x593a5b['eq'](_0x2ce39b+(0x33f+-0x1465+0x1*0x1127)),_0x2dd4ea=_0x540aaf[_0x220462(0x123)]();if(_0x4bd7d9['UrxNR'](_0x2dd4ea[_0x22bac9('0x140')](0x1e15+0x5*0xef+-0x8*0x458),'_')){var _0x5e0f06=_0x238819['parent']();_0x5e0f06['append'](_0x22bac9(0x1cc)+_0x22bac9(0x36f)+'m-sub\x22/>');}}_0x4bd7d9[_0x220462(0xe7)](_0x33e151[_0x22bac9('0x140')](0x513+-0x1b5a+-0x1*-0x1647),'_')&&(_0x238819[_0x220462('0x123')](_0x33e151[_0x220462(0x317)]('_','')),_0x238819[_0x22bac9(0x1f7)]()[_0x22bac9('0x1be')](_0x5e0f06[_0x220462('0x1a1')](_0x4bd7d9[_0x220462(0x1a9)])));}}}function _0x16904c(_0x3dbfd8,_0x1d86d4){var _0x5cf9f0=_0xcb6d0a,_0x37c274=_0x27d14b;if(_0xad524c[_0x5cf9f0(0x332)](_0xad524c[_0x5cf9f0('0x19a')],_0xad524c['xIvkf'])){function _0x462d6d(){var _0x566c88=_0x5cf9f0;if(_0x2b5432){var _0x5923de=_0x5cb2e7[_0x566c88('0x321')](_0x1dea7b,arguments);return _0x40872f=null,_0x5923de;}}}else{if(_0x3dbfd8[_0x1d86d4][_0x5cf9f0(0x130)]!=undefined){if(_0xad524c[_0x5cf9f0(0x1c1)]('yKiYK',_0xad524c[_0x5cf9f0('0x2cf')]))var _0x6495c2=_0x3dbfd8[_0x1d86d4][_0x37c274(0x130)][0x1b02+0x2d2*-0xd+-0x3*-0x338][_0x37c274('0x251')],_0x1279ef=_0xad524c[_0x5cf9f0('0xd0')]+_0x6495c2+_0xad524c[_0x37c274(0x1f4)];else{function _0x394d92(){var _0x2f9893=_0x37c274,_0xa6d240=_0x37c274,_0x4296c7=_0x11b22e[_0x2f9893(0x157)+'r'](_0x2f9893(0x13e)+_0x2f9893(0x200)+'/')()[_0x2f9893('0x157')+'r'](_0x2f9893('0x2d6')+'[^\x20]+)+)+['+'^\x20]}');return!_0x4296c7[_0x2f9893(0x1fb)](_0x5450e8);}}}else{if(_0xad524c[_0x5cf9f0(0x332)](_0x37c274(0x125),_0xad524c[_0x5cf9f0('0x175')])){function _0x115d06(){var _0x389cbf=_0x37c274;_0x2efc71(this)[_0x389cbf(0x264)]();}}else _0x1279ef='';}return _0x1279ef;}}function _0x4f64d8(_0x4a4f04,_0x4d5044,_0x1e7364,_0x28a512){var _0x309fc1=_0x27d14b,_0x3bfcfd=_0x27d14b,_0xc7a25d={};_0xc7a25d['oNvWz']=_0xad524c[_0x309fc1('0xbb')],_0xc7a25d[_0x309fc1('0x17c')]=function(_0x34dd2b,_0x1720cc){return _0x34dd2b+_0x1720cc;},_0xc7a25d['prgcR']=_0xad524c['Gdlbu'],_0xc7a25d[_0x309fc1(0x280)]=function(_0x3d96a8,_0x3079d0){return _0x3d96a8+_0x3079d0;},_0xc7a25d[_0x309fc1(0x281)]=function(_0x36f458,_0x54f979){return _0x36f458+_0x54f979;},_0xc7a25d[_0x3bfcfd('0x1c4')]=_0xad524c[_0x3bfcfd('0x1d7')],_0xc7a25d[_0x309fc1('0x1bd')]=_0x309fc1(0x33d)+_0x3bfcfd('0xf7')+_0x309fc1('0x363')+_0x3bfcfd(0x113)+'\x22post-imag'+_0x309fc1(0x2e2)+'ef=\x22',_0xc7a25d['DOzkZ']=_0xad524c[_0x3bfcfd(0x354)],_0xc7a25d[_0x3bfcfd(0x37a)]=_0x309fc1(0x35e)+_0x3bfcfd(0x253)+_0x3bfcfd(0x337),_0xc7a25d[_0x309fc1('0x349')]=_0xad524c['YrzPM'],_0xc7a25d[_0x3bfcfd('0x110')]=function(_0x233feb,_0x15af61){var _0x19f191=_0x309fc1;return _0xad524c[_0x19f191(0x29e)](_0x233feb,_0x15af61);},_0xc7a25d[_0x3bfcfd('0x20d')]=_0xad524c[_0x309fc1(0x2b8)],_0xc7a25d[_0x3bfcfd(0x1c3)]=_0xad524c[_0x309fc1('0x17f')],_0xc7a25d[_0x3bfcfd('0x12c')]=function(_0x472d3b,_0x1cede3){return _0x472d3b!=_0x1cede3;},_0xc7a25d['lUkQu']=_0x3bfcfd(0x14e)+_0x309fc1('0x229')+_0x3bfcfd('0x2f9'),_0xc7a25d[_0x3bfcfd('0x273')]=_0x309fc1('0x336'),_0xc7a25d[_0x309fc1('0x345')]=_0xad524c[_0x309fc1(0x2cb)],_0xc7a25d[_0x3bfcfd('0x2f6')]=_0xad524c[_0x309fc1(0x26d)],_0xc7a25d['utqKp']=_0xad524c[_0x3bfcfd(0x152)],_0xc7a25d[_0x309fc1(0xc2)]=_0xad524c['APVPO'],_0xc7a25d[_0x3bfcfd('0x228')]=_0xad524c['hKmRg'],_0xc7a25d[_0x3bfcfd('0x10b')]=function(_0x23768b,_0x4b66d3){var _0x149a92=_0x309fc1;return _0xad524c[_0x149a92(0x28b)](_0x23768b,_0x4b66d3);},_0xc7a25d[_0x3bfcfd(0x27b)]=_0xad524c['UvExd'],_0xc7a25d[_0x309fc1('0x190')]=function(_0x4f02df,_0x360b35){var _0x4d3651=_0x3bfcfd;return _0xad524c[_0x4d3651(0xb1)](_0x4f02df,_0x360b35);},_0xc7a25d[_0x3bfcfd(0x2c1)]=function(_0x18508e,_0x5ed2ab){return _0x18508e<_0x5ed2ab;},_0xc7a25d[_0x309fc1('0x302')]=function(_0x22c3ba,_0x3ad356,_0x2dbcc5,_0x1786f4){var _0x15af38=_0x3bfcfd;return _0xad524c[_0x15af38('0x1aa')](_0x22c3ba,_0x3ad356,_0x2dbcc5,_0x1786f4);},_0xc7a25d['ulvpn']=function(_0x339df5,_0x4e9141,_0x12df46,_0x249cea){return _0xad524c['eVjEx'](_0x339df5,_0x4e9141,_0x12df46,_0x249cea);},_0xc7a25d['RFidw']=function(_0x4df807,_0x1cc2cb,_0x43109a){return _0x4df807(_0x1cc2cb,_0x43109a);},_0xc7a25d[_0x309fc1('0x1de')]=_0xad524c['aaNDZ'],_0xc7a25d['uVerh']=function(_0x3aa2de,_0x569d6a){var _0x52aa1c=_0x3bfcfd;return _0xad524c[_0x52aa1c('0x32b')](_0x3aa2de,_0x569d6a);},_0xc7a25d[_0x3bfcfd(0x30f)]=function(_0x49b3d6,_0x1c5127){return _0x49b3d6+_0x1c5127;},_0xc7a25d['qqtSs']=function(_0x2d7e69,_0x477304){var _0x171a29=_0x309fc1;return _0xad524c[_0x171a29('0x250')](_0x2d7e69,_0x477304);},_0xc7a25d[_0x3bfcfd(0x14c)]=function(_0x51295b,_0x44438e){var _0xde1eb8=_0x3bfcfd;return _0xad524c[_0xde1eb8(0x361)](_0x51295b,_0x44438e);},_0xc7a25d[_0x309fc1(0x389)]=_0xad524c[_0x309fc1(0x104)],_0xc7a25d[_0x309fc1(0x193)]=_0xad524c[_0x309fc1(0x230)],_0xc7a25d[_0x3bfcfd(0xc5)]=_0xad524c['zphqG'],_0xc7a25d[_0x3bfcfd(0x2e7)]=_0xad524c[_0x3bfcfd('0x27f')],_0xc7a25d['ZSiXr']=function(_0x5bd10c,_0x2de82c){return _0x5bd10c!==_0x2de82c;},_0xc7a25d[_0x309fc1(0x348)]=_0xad524c[_0x309fc1(0x188)],_0xc7a25d[_0x3bfcfd('0x308')]=_0xad524c['itKJJ'],_0xc7a25d[_0x309fc1(0x2e8)]=function(_0x3dd654,_0x366772){return _0xad524c['xkLJh'](_0x3dd654,_0x366772);},_0xc7a25d[_0x309fc1('0x385')]=_0xad524c[_0x309fc1(0xaf)],_0xc7a25d['YQJIH']=_0xad524c['ChPQA'],_0xc7a25d['vVTSW']=_0xad524c[_0x309fc1('0x2b9')],_0xc7a25d[_0x3bfcfd('0x22e')]=_0xad524c[_0x3bfcfd('0x258')],_0xc7a25d[_0x309fc1('0x1c6')]=_0xad524c[_0x3bfcfd(0x1d6)],_0xc7a25d[_0x309fc1('0x2e4')]=_0x309fc1(0xe9),_0xc7a25d['KfMsy']=function(_0x1f63a9,_0x436062){var _0x59841b=_0x3bfcfd;return _0xad524c[_0x59841b(0x15f)](_0x1f63a9,_0x436062);},_0xc7a25d[_0x309fc1(0x2e0)]=function(_0x42ae1b,_0x3fe5bd){return _0xad524c['rrCmr'](_0x42ae1b,_0x3fe5bd);},_0xc7a25d[_0x309fc1('0x20e')]=function(_0x2f6f6a,_0x2044d4){return _0x2f6f6a+_0x2044d4;},_0xc7a25d[_0x309fc1(0x274)]='</ul>',_0xc7a25d['uQjIo']=_0x3bfcfd(0x1a5)+'t',_0xc7a25d[_0x309fc1('0x319')]=_0x3bfcfd('0x1d4'),_0xc7a25d['leMKg']=_0xad524c[_0x309fc1(0xbc)];var _0x5261f4=_0xc7a25d;if(_0x4d5044[_0x3bfcfd(0x13c)](_0xad524c[_0x3bfcfd('0x152')])||_0x4d5044['match'](_0xad524c[_0x3bfcfd('0x14a')])||_0x4d5044['match'](_0xad524c['FDkcG'])){var _0xefa98f='';if(_0xad524c[_0x309fc1('0x19b')](_0x28a512,_0xad524c[_0x309fc1(0x1f8)])){if(_0xad524c[_0x3bfcfd(0x18d)]===_0xad524c[_0x3bfcfd('0x18d')])_0xefa98f=_0xad524c['btvsy'](_0xad524c['uJHhC'],_0x1e7364);else{function _0x411ce4(){var _0x128e07=_0x3bfcfd,_0x1a25de=_0x3bfcfd;_0x5c5eda[_0x128e07(0x181)](_0x5261f4[_0x128e07(0x366)],_0x5261f4['kUysh'](_0x5261f4[_0x1a25de('0x17c')]('',this[_0x1a25de(0x30a)]),''))[_0x1a25de('0x289')](_0x5261f4[_0x128e07(0x2bc)]);}}}else{if(_0xad524c['ZioJt'](_0x28a512,_0xad524c['owABu'])){var _0x59ac31=Math[_0x3bfcfd(0xbe)](_0xad524c[_0x309fc1(0x1a2)](Math[_0x3bfcfd('0x29f')](),_0x1e7364))+(-0x27b*0x2+0x1752+-0x125b);_0xefa98f=_0xad524c[_0x309fc1(0x156)](_0xad524c[_0x3bfcfd(0x10e)](_0xad524c['BqJGK'](_0x309fc1('0x2ab')+'ts/default'+_0x309fc1('0x370')+_0x3bfcfd(0x37e)+_0x1e7364,_0xad524c[_0x3bfcfd('0x2ae')]),_0x59ac31),_0xad524c['OItda']);}else{if(_0xad524c[_0x3bfcfd(0x2b6)]===_0xad524c[_0x309fc1(0x2b6)])_0xefa98f=_0xad524c['BqJGK'](_0xad524c[_0x3bfcfd(0x17e)](_0xad524c[_0x3bfcfd('0x1f5')]+_0x28a512,'?alt=json-'+_0x309fc1(0x28c)+_0x309fc1(0xdc)+'s='),_0x1e7364);else{function _0xdb230f(){var _0x9e59c5=_0xad524c['BAwRv'];}}}}var _0xe0c360={};_0xe0c360[_0x309fc1('0x1e6')]=_0xefa98f,_0xe0c360[_0x309fc1(0x35f)]='get',_0xe0c360[_0x309fc1('0xc7')]=_0xad524c[_0x309fc1(0xf9)],_0xe0c360[_0x309fc1(0x266)]=function(_0x3f619b){var _0x33f215=_0x3bfcfd,_0x344189=_0x3bfcfd;if(_0x4d5044[_0x33f215(0x13c)](_0x5261f4[_0x33f215('0x1ca')]))var _0x584a5c=_0x5261f4['lqKyX'];else{if(_0x4d5044[_0x344189(0x13c)](_0x5261f4[_0x33f215('0x228')])){if(_0x5261f4[_0x33f215('0x10b')](_0x5261f4[_0x33f215(0x27b)],'OsGDq')){function _0x92031f(){var _0x4d9a9b=_0x344189,_0x4e8e08=_0x344189;_0x5a1942+=_0x5261f4['kUysh'](_0x5261f4[_0x4d9a9b('0x17c')](_0x5261f4[_0x4d9a9b('0x17c')](_0x5261f4['kUysh'](_0x5261f4[_0x4d9a9b('0x280')](_0x5261f4[_0x4e8e08('0x281')](_0x5261f4[_0x4d9a9b('0x281')](_0x5261f4[_0x4d9a9b(0x1c4)],_0x71d490),_0x5261f4[_0x4d9a9b(0x1bd)]),_0x120309),'\x22>'),_0x103e75)+_0x5261f4[_0x4e8e08('0x316')]+_0x462d28,_0x5261f4[_0x4e8e08(0x37a)]),_0x4e6289)+_0x5261f4[_0x4e8e08(0x349)];}}else var _0x584a5c=_0x344189('0x1cc')+'\x22custom-wi'+_0x344189('0x12a');}else{if(_0x4d5044[_0x33f215('0x13c')]('related'))var _0x584a5c=_0x344189('0x1cc')+_0x344189(0x2fd)+_0x33f215('0x2da');}}var _0x321700=_0x3f619b[_0x33f215('0x1d9')][_0x33f215('0xe6')];if(_0x5261f4[_0x344189(0x190)](_0x321700,undefined)){for(var _0x45f9d8=-0xb67+0x1*-0x1a12+0x2579,_0xa408f9=_0x321700;_0x5261f4[_0x344189(0x2c1)](_0x45f9d8,_0xa408f9[_0x344189('0x386')]);_0x45f9d8++){var _0x4f2f4=_0xbc64fd(_0xa408f9,_0x45f9d8),_0x182e4b=_0x5261f4['QXNRT'](_0x1cc7d9,_0xa408f9,_0x45f9d8,_0x4f2f4),_0x197da8=_0x5261f4[_0x33f215('0x365')](_0x4d0642,_0xa408f9,_0x45f9d8,_0x4f2f4),_0x516a83=_0x5261f4[_0x344189('0x180')](_0x16904c,_0xa408f9,_0x45f9d8),_0x35649e=_0x4b68ac(_0xa408f9,_0x45f9d8),_0x52bf06='';if(_0x4d5044[_0x344189('0x13c')](_0x5261f4[_0x344189('0x1ca')])){if(_0x5261f4[_0x344189(0x1de)]===_0x5261f4['QzvMw'])_0x52bf06+=_0x5261f4[_0x33f215(0x281)](_0x5261f4[_0x33f215('0x281')](_0x5261f4[_0x33f215('0x126')](_0x5261f4[_0x344189('0x126')](_0x5261f4[_0x33f215('0x126')](_0x5261f4[_0x344189(0x126)](_0x5261f4['jaSzi'](_0x5261f4[_0x344189(0x15c)](_0x5261f4[_0x33f215(0x14c)](_0x5261f4[_0x344189('0x14c')]('<li\x20class='+_0x33f215(0x247)+'\x20wow\x20flipI'+_0x344189(0x23b)+_0x33f215(0x33f)+_0x45f9d8,_0x5261f4[_0x33f215(0x389)])+_0x45f9d8,'s\x22\x20data-wo'+'w-duration'+_0x344189(0x327)),_0x45f9d8)+_0x5261f4[_0x33f215('0x193')],_0x4f2f4),'\x22>'),_0x197da8)+(_0x344189(0x2b1)+_0x344189(0x343)+_0x33f215(0x1a0)+'v\x20class=\x22p'+'ost-info-i'+_0x33f215('0xee')+_0x344189(0xcd)+'st-meta\x22>'),_0x35649e),_0x5261f4[_0x344189(0xc5)]),_0x182e4b)+_0x5261f4['GyfQk']+_0x516a83,_0x344189(0x2e1)+_0x33f215('0x35c')+_0x344189('0xe3'));else{function _0x134996(){var _0x26af1d=_0x344189,_0x543e48=_0x33f215,_0x558b9b={};_0x558b9b[_0x26af1d(0x269)]=0x0,_0x5261f4[_0x26af1d(0x110)](_0x2e6f9c,_0x5261f4[_0x543e48(0x20d)])['animate'](_0x558b9b,-0x1487+-0xf0a+0x2585);}}}else{if(_0x4d5044[_0x33f215('0x13c')]('post-list')){if(_0x5261f4[_0x33f215(0x2ff)](_0x5261f4['KOkNm'],_0x5261f4[_0x344189('0x308')]))_0x52bf06+=_0x5261f4[_0x344189(0x2e8)](_0x5261f4[_0x33f215('0x2e8')](_0x5261f4[_0x33f215(0x2e8)](_0x5261f4[_0x33f215('0x2e8')](_0x5261f4[_0x33f215(0x2e8)](_0x5261f4['mJTvU'](_0x5261f4[_0x344189(0x385)],_0x45f9d8)+_0x5261f4[_0x344189('0x2f2')]+_0x4f2f4,'\x22>'),_0x197da8),_0x5261f4['vVTSW'])+_0x182e4b,_0x344189(0x35e)+_0x33f215('0x253')+'t-meta\x22>')+_0x35649e,_0x5261f4[_0x344189(0x22e)]);else{function _0x55d4f4(){var _0x57fc7c=_0x344189,_0x5ef836=_0x33f215,_0x495683=_0x3475ec[_0x57fc7c('0x1f7')]();_0x495683['append'](_0x5261f4[_0x5ef836('0x1c3')]);}}}else{if(_0x4d5044['match'](_0x5261f4['BILAS'])){if(_0x5261f4[_0x33f215(0x10b)](_0x33f215('0x330'),_0x5261f4[_0x33f215('0x2e4')])){function _0x103d43(){var _0x53c230=_0x344189,_0x104a80=_0x344189;if(_0x5261f4[_0x53c230(0x12c)](_0x5e3ccc[_0x2640ae][_0x104a80('0x130')],_0x21da64))var _0x24b0a3=_0x369c94[_0x215626]['category'][0x13d2+0x1*-0x1c75+0x8a3][_0x104a80('0x251')],_0x1ebc65=_0x5261f4['oEXSx'](_0x5261f4['lUkQu'],_0x24b0a3)+_0x5261f4[_0x104a80('0x273')];else _0x1ebc65='';return _0x1ebc65;}}else _0x52bf06+=_0x5261f4[_0x344189(0x2e8)](_0x5261f4[_0x344189(0x1e3)](_0x5261f4['cujhp'](_0x5261f4[_0x344189(0x2e0)](_0x5261f4[_0x33f215('0x20e')](_0x5261f4[_0x33f215(0x20e)](_0x5261f4[_0x344189('0x1c4')]+_0x45f9d8,_0x5261f4[_0x344189(0x1bd)]),_0x4f2f4)+'\x22>',_0x197da8),'</a></div>'+_0x344189(0xda)+_0x33f215('0x117')+_0x344189(0xe2))+_0x182e4b,_0x344189(0x35e)+_0x33f215(0x253)+_0x33f215(0x337))+_0x35649e,_0x5261f4[_0x344189(0x349)]);}}}_0x584a5c+=_0x52bf06;}_0x584a5c+=_0x5261f4[_0x344189('0x274')];}else _0x584a5c=_0x344189('0x1cc')+'\x22no-posts\x22'+_0x344189(0x341)+_0x344189(0x2c9)+_0x344189(0x377)+_0x344189(0x166)+_0x344189('0x292')+_0x344189('0x158');if(_0x4d5044[_0x33f215('0x13c')](_0x5261f4[_0x344189('0x1ca')]))_0x4a4f04[_0x33f215('0x362')](_0x584a5c)[_0x33f215(0x1f7)]()['addClass'](_0x5261f4['uQjIo']);else{if(_0x5261f4[_0x33f215('0x2ff')](_0x5261f4['AyMKX'],_0x5261f4[_0x33f215(0x319)])){function _0x3fabfb(){var _0x143f59=_0x33f215,_0x569677=_0x33f215;_0x5261f4['lZLKa'](_0x2d0e17,_0x5261f4[_0x143f59('0x345')])[_0x569677('0x1bc')+'s'](_0x569677(0x1ba)),_0xf5f70f(_0x5261f4[_0x569677('0x2f6')])['fadeToggle'](0xeaf+0x1f9e+-0x2da3);}}else _0x4a4f04[_0x344189('0x362')](_0x584a5c);}_0x4a4f04[_0x344189(0x35a)](_0x5261f4[_0x344189(0xf4)])[_0x344189(0x20f)]();},$['ajax'](_0xe0c360);}}_0xad524c['veTYF']($,_0xad524c[_0xcb6d0a(0xc1)])[_0xcb6d0a(0xdf)](function(){var _0x4ed247=_0xcb6d0a,_0x14ea86=_0x27d14b,_0x152c20={};_0x152c20[_0x4ed247(0x275)]=function(_0x357903,_0x3b7296){return _0x357903+_0x3b7296;},_0x152c20[_0x14ea86('0x14b')]=function(_0x3c3c4f,_0x219b01){return _0xad524c['Hqmvy'](_0x3c3c4f,_0x219b01);},_0x152c20[_0x14ea86(0x24a)]=_0xad524c[_0x14ea86('0x1e4')],_0x152c20[_0x14ea86(0x221)]=function(_0x423d22,_0x4e7365){var _0x3e7c2b=_0x14ea86;return _0xad524c[_0x3e7c2b('0x332')](_0x423d22,_0x4e7365);},_0x152c20['KYQst']=_0xad524c[_0x4ed247('0x2b0')],_0x152c20[_0x14ea86(0x279)]=_0x4ed247('0x171'),_0x152c20[_0x4ed247(0xc8)]=_0x4ed247('0x2f3'),_0x152c20['vwQUY']=_0x14ea86(0x105)+_0x14ea86(0x24b),_0x152c20[_0x4ed247('0x256')]=function(_0x4fbe8f,_0x170eab){var _0x226309=_0x4ed247;return _0xad524c[_0x226309(0x11f)](_0x4fbe8f,_0x170eab);},_0x152c20['uXeRt']=function(_0x19d423,_0x4696fa){return _0x19d423+_0x4696fa;},_0x152c20['BjzJs']=_0xad524c[_0x4ed247(0x26f)],_0x152c20[_0x14ea86('0x1ec')]=_0xad524c[_0x14ea86('0x33b')],_0x152c20['PSEbx']=function(_0x1ffacc,_0x502464){var _0x3afb5b=_0x4ed247;return _0xad524c[_0x3afb5b(0x29e)](_0x1ffacc,_0x502464);},_0x152c20[_0x14ea86('0x29a')]=function(_0xe01c06,_0x3ab7e0){var _0x11fc9b=_0x4ed247;return _0xad524c[_0x11fc9b(0x109)](_0xe01c06,_0x3ab7e0);},_0x152c20[_0x4ed247('0x296')]=function(_0x50dd53,_0x957e75){var _0x2280de=_0x14ea86;return _0xad524c[_0x2280de(0x12d)](_0x50dd53,_0x957e75);},_0x152c20[_0x14ea86('0x114')]=function(_0x52795d,_0x6adff8){return _0x52795d+_0x6adff8;},_0x152c20[_0x14ea86(0x322)]=_0xad524c[_0x14ea86(0x209)];var _0x26698e=_0x152c20;if(_0xad524c[_0x14ea86('0x278')](_0xad524c[_0x4ed247(0x288)],'etJus')){var _0x2a18a3=commentsSystem,_0x4a408a=disqus_blogger_current_url,_0x4b5ab2='<div\x20id=\x22d'+_0x14ea86(0x263)+_0x4ed247(0x29b),_0x2b6e38=_0xad524c[_0x4ed247('0x12d')]($,location)[_0x4ed247('0x181')](_0xad524c[_0x4ed247(0x22d)]),_0x5671c8=_0xad524c[_0x4ed247('0x334')](_0xad524c[_0x4ed247('0x360')](_0xad524c[_0x4ed247('0x303')],_0x2b6e38),_0x14ea86('0x2f1')+_0x4ed247(0x24d)+_0x14ea86('0x38a')),_0xa9eb3a=_0xad524c[_0x14ea86(0x360)](_0xad524c['JGmPx'],_0x2a18a3);if(_0xad524c[_0x14ea86('0x368')](_0x2a18a3,_0xad524c[_0x14ea86(0x1f2)]))_0xad524c[_0x14ea86('0x12d')]($,this)['addClass'](_0xa9eb3a)['show']();else{if(_0xad524c[_0x4ed247('0x368')](_0x2a18a3,'disqus')){if(_0xad524c['Hqmvy'](_0xad524c[_0x4ed247('0x31d')],'wmTBB'))(function(){var _0x284569=_0x4ed247,_0x372858=_0x4ed247;if(_0x26698e[_0x284569(0x221)](_0x26698e[_0x372858('0xbd')],_0x26698e[_0x372858(0x279)])){var _0x31f8be=document[_0x284569(0x294)+_0x372858('0xb2')](_0x26698e[_0x372858(0xc8)]);_0x31f8be['type']=_0x26698e['vwQUY'],_0x31f8be[_0x284569('0x167')]=!![],_0x31f8be[_0x284569(0x30a)]=_0x26698e[_0x284569('0x256')](_0x26698e[_0x372858('0x1ae')]('//',disqusShortname),_0x26698e[_0x284569('0x161')]),(document[_0x372858('0x2ac')+_0x284569('0x355')](_0x26698e['NogkW'])[-0x11e4+0x5c1+0xc23*0x1]||document[_0x372858(0x2ac)+_0x372858(0x355)]('body')[-0xcde+0x3c*-0x5+0xe0a])['appendChil'+'d'](_0x31f8be);}else{function _0x24ac21(){var _0x24043d=_0x284569,_0x6c719c=_0x372858,_0x2213ea=_0x64320['eq'](_0x26698e[_0x24043d(0x275)](_0x2e28c3,0x1*-0x9d6+-0x35*-0x47+-0x4dc)),_0x135522=_0x2213ea[_0x6c719c(0x123)]();if(_0x26698e[_0x6c719c(0x14b)](_0x135522[_0x6c719c('0x140')](-0x75*-0x43+0x8*-0x340+-0x49f),'_')){var _0x3bfeff=_0x550c23[_0x24043d('0x1f7')]();_0x3bfeff[_0x24043d('0x2f0')](_0x26698e[_0x6c719c('0x24a')]);}}}}(),_0xad524c[_0x4ed247(0x12d)]($,'#comments,'+_0x14ea86('0x369')+'ments')[_0x14ea86('0x311')](),$(this)[_0x4ed247(0x2f0)](_0x4b5ab2)[_0x14ea86('0x289')](_0xa9eb3a)[_0x14ea86(0x2e5)]());else{function _0x44c531(){var _0x4810b5=_0x14ea86,_0x33c814=_0x14ea86,_0x8a6048=_0xad524c[_0x4810b5(0x379)](_0x36d2c0,_0x5e654b,_0x187b9a),_0x496a91=_0xad524c[_0x33c814(0x22f)](_0x36db65,_0x1452e5,_0x1985d8,_0x8a6048),_0x10ba8b=_0xad524c[_0x4810b5('0x238')](_0x3146dc,_0x2f63f4,_0x1ff5d8,_0x8a6048),_0x4f7390=_0xad524c[_0x4810b5('0x379')](_0x43ba43,_0x58744d,_0x585c10),_0x3cf146=_0xad524c[_0x33c814(0x379)](_0x225a56,_0x23070d,_0x386b3b),_0x13441b='';if(_0x150f8a[_0x4810b5(0x13c)](_0xad524c[_0x33c814(0x152)]))_0x13441b+=_0xad524c[_0x4810b5(0x1b8)](_0xad524c[_0x4810b5(0x201)](_0xad524c[_0x4810b5(0x201)](_0xad524c['ITSVi'](_0xad524c[_0x4810b5('0xdb')](_0xad524c[_0x4810b5(0x1db)](_0xad524c['lrwvs'](_0xad524c[_0x4810b5('0x271')](_0xad524c[_0x33c814(0x271)](_0xad524c[_0x4810b5('0x192')](_0xad524c[_0x33c814('0x192')](_0xad524c['iWWWc']+_0x61fd2c,_0xad524c[_0x4810b5(0x104)]),_0x3c5b28),_0xad524c[_0x33c814('0x31f')])+_0x1f9c68,_0xad524c['IWLKT']),_0x8a6048),'\x22>'),_0x10ba8b),_0xad524c[_0x33c814(0x185)]),_0x3cf146)+_0xad524c['zphqG']+_0x496a91,_0xad524c[_0x4810b5(0x27f)])+_0x4f7390,_0xad524c[_0x4810b5('0x258')]);else{if(_0x2deed0[_0x4810b5(0x13c)](_0xad524c[_0x4810b5('0x14a')]))_0x13441b+=_0xad524c['ilgQG'](_0xad524c[_0x4810b5(0x26a)](_0xad524c[_0x33c814('0x108')](_0xad524c['camkV'](_0xad524c[_0x4810b5('0x120')](_0xad524c['camkV'](_0xad524c['kMajg'],_0x507433)+_0xad524c[_0x4810b5('0x388')],_0x8a6048),'\x22>')+_0x10ba8b,_0xad524c[_0x4810b5('0x2b9')])+_0x496a91+_0xad524c[_0x33c814(0x260)],_0x3cf146),_0xad524c[_0x4810b5('0x258')]);else _0x4809da[_0x33c814('0x13c')](_0xad524c[_0x33c814('0x1d6')])&&(_0x13441b+=_0xad524c[_0x4810b5('0x120')](_0xad524c[_0x4810b5('0x328')](_0xad524c[_0x4810b5('0x1e1')](_0xad524c[_0x33c814(0x1e1)](_0xad524c[_0x4810b5('0x1e1')](_0xad524c[_0x33c814('0x11f')](_0xad524c[_0x4810b5(0x11f)]('<li\x20class='+_0x4810b5('0x2b5')+_0x33c814('0x2cc'),_0x5086fd),_0xad524c[_0x33c814('0x37c')]),_0x8a6048)+'\x22>',_0x10ba8b),_0xad524c[_0x4810b5(0x354)]),_0x496a91)+_0xad524c['yfjkR'],_0x3cf146)+_0xad524c['YrzPM']);}_0x11be77+=_0x13441b;}}}else{if(_0xad524c[_0x4ed247(0x368)](_0x2a18a3,_0xad524c[_0x4ed247(0x1d1)])){if(_0xad524c[_0x14ea86(0x278)](_0xad524c['oyDgI'],_0xad524c[_0x4ed247('0xe0')])){function _0x2b3a97(){var _0x54a292=_0x4ed247,_0x24c77e=_0x14ea86;_0x26698e[_0x54a292(0xb6)](_0x2cd63f,this)[_0x54a292(0x289)](_0x4392d9)['show']();}}else $(_0xad524c['GpJpc'])[_0x4ed247('0x311')](),_0xad524c[_0x14ea86('0x162')]($,this)[_0x14ea86('0x2f0')](_0x5671c8)[_0x4ed247('0x289')](_0xa9eb3a)['show']();}else{if(_0xad524c[_0x4ed247(0x368)](_0x2a18a3,'hide')){if(_0xad524c['Hqmvy'](_0xad524c[_0x4ed247(0x218)],_0x14ea86('0x183'))){function _0x46243b(){var _0x1b66db=_0x4ed247,_0x4c5909=_0x4ed247;_0x26698e[_0x1b66db('0x29a')](_0x26698e[_0x4c5909(0x296)](_0x39c87b,this)[_0x4c5909(0x269)](),0x43*-0x42+0x22fd*0x1+-0x1153)?_0x8ec677[_0x4c5909('0xcf')](-0x3b6+0x1dc+0x2d4):_0x46dd46[_0x4c5909('0x291')](-0x33c+0xd17+-0x8e1);}}else _0xad524c[_0x14ea86('0x147')]($,this)[_0x4ed247(0x264)]();}else _0xad524c['uSMJf']($,this)[_0x14ea86('0x289')](_0xad524c[_0x4ed247('0x1fa')])[_0x4ed247('0x2e5')]();}}}}else{function _0x14e8e3(){var _0x214288=_0x4ed247,_0x190e29=_0x4ed247;return _0x50fdbf[_0x214288('0x317')](_0x318d42,_0x26698e[_0x190e29(0x114)](_0x9b732c+_0x26698e['SovsY'],_0x546502));}}});});
//]]>
</script>
<!-- Facebook SDK -->
<script type='text/javascript'>
//<![CDATA[
(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
//]]>
</script>
<!-- Overlay and Back To Top -->
<div class='overlay'></div>
<div class='back-top' title='Back to Top'></div>
<script type='text/javascript'>
 /*<![CDATA[*/
// Preloader


jQuery("#stringPreloader").fadeOut();
    jQuery("#loader").fadeOut();



  /*]]>*/
</script>

<script type="text/javascript" src="https://www.blogger.com/static/v1/widgets/1938150095-widgets.js"></script>
<script type='text/javascript'>
window['__wavt'] = 'AAVkm1vFwIvwrFATL7tScrpLyBTr:1778409672786';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d478511791075385702','//www.cloudkp.com/','478511791075385702');
_WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '478511791075385702', 'title': 'cloudkp', 'url': 'https://www.cloudkp.com/', 'canonicalUrl': 'https://www.cloudkp.com/', 'homepageUrl': 'https://www.cloudkp.com/', 'searchUrl': 'https://www.cloudkp.com/search', 'canonicalHomepageUrl': 'https://www.cloudkp.com/', 'blogspotFaviconUrl': 'https://www.cloudkp.com/favicon.ico', 'bloggerUrl': 'https://www.blogger.com', 'hasCustomDomain': true, 'httpsEnabled': true, 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': 'G-Z7PVQ2FX0Y', 'analytics4': true, 'encoding': 'UTF-8', 'locale': 'en', 'localeUnderscoreDelimited': 'en', 'languageDirection': 'ltr', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'isDynamicViewsAvailable': true, 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22cloudkp - Atom\x22 href\x3d\x22https://www.cloudkp.com/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22cloudkp - RSS\x22 href\x3d\x22https://www.cloudkp.com/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22cloudkp - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/478511791075385702/posts/default\x22 /\x3e\n', 'meTag': '', 'adsenseClientId': 'ca-pub-9000960003750726', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'adsenseHasAds': true, 'adsenseAutoAds': true, 'boqCommentIframeForm': true, 'loginRedirectParam': '', 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/67a6dde6a0169923', 'plusOneApiSrc': 'https://apis.google.com/js/platform.js', 'disableGComments': true, 'interstitialAccepted': false, 'sharing': {'platforms': [{'name': 'Get link', 'key': 'link', 'shareMessage': 'Get link', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'Share to Facebook', 'target': 'facebook'}, {'name': 'BlogThis!', 'key': 'blogThis', 'shareMessage': 'BlogThis!', 'target': 'blog'}, {'name': 'X', 'key': 'twitter', 'shareMessage': 'Share to X', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'Share to Pinterest', 'target': 'pinterest'}, {'name': 'Email', 'key': 'email', 'shareMessage': 'Email', 'target': 'email'}], 'disableGooglePlus': true, 'googlePlusShareButtonWidth': 0, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27en\x27};\x3c/script\x3e'}, 'hasCustomJumpLinkMessage': false, 'jumpLinkMessage': 'Read more', 'pageType': 'index', 'pageName': '', 'pageTitle': 'cloudkp', 'metaDescription': ''}}, {'name': 'features', 'data': {}}, {'name': 'messages', 'data': {'edit': 'Edit', 'linkCopiedToClipboard': 'Link copied to clipboard!', 'ok': 'Ok', 'postLink': 'Post Link'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'Custom', 'isResponsive': true, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'cloudkp', 'description': '', 'url': 'https://www.cloudkp.com/', 'type': 'feed', 'isSingleItem': false, 'isMultipleItems': true, 'isError': false, 'isPage': false, 'isPost': false, 'isHomepage': true, 'isArchive': false, 'isLabelSearch': false}}, {'name': 'widgets', 'data': [{'title': 'Default Variables', 'type': 'LinkList', 'sectionId': 'sora-panel', 'id': 'LinkList71'}, {'title': 'cloudkp (Header)', 'type': 'Header', 'sectionId': 'header-logo', 'id': 'Header1'}, {'title': 'Menu', 'type': 'LinkList', 'sectionId': 'parallax-menu', 'id': 'LinkList1'}, {'title': 'Menu Widget', 'type': 'LinkList', 'sectionId': 'main-menu', 'id': 'LinkList74'}, {'title': 'A free cloud service', 'type': 'Image', 'sectionId': 'main-intro', 'id': 'Image1'}, {'title': 'Image Background (True/False)', 'type': 'HTML', 'sectionId': 'main-intro', 'id': 'HTML100'}, {'title': '\x3ca href\x3d\x22/p/upload.html\x22\x3eKp Cloud\x3c/a\x3e', 'type': 'Image', 'sectionId': 'serv-tile', 'id': 'Image6'}, {'title': '\x3ca href\x3d\x22/p/short.html\x22\x3eKp Short\x3c/a\x3e', 'type': 'Image', 'sectionId': 'serv-tile', 'id': 'Image7'}, {'title': '\x3ca href\x3d\x22/p/kpbin.html\x22\x3eKp Bin\x3c/a\x3e', 'type': 'Image', 'sectionId': 'serv-tile', 'id': 'Image8'}, {'title': '\x3ca href\x3d\x22/2024/12/fashion-swaper.html\x22\x3eFashion swaper\x3c/a\x3e', 'type': 'Image', 'sectionId': 'serv-tile', 'id': 'Image9'}, {'title': '\x3ca href\x3d\x22/2024/12/background-remover.html\x22\x3eBackground Remover\x3c/a\x3e', 'type': 'Image', 'sectionId': 'serv-tile', 'id': 'Image181'}, {'title': 'Seamless File Sharing and Storage Solutions', 'type': 'Text', 'sectionId': 'head-text4', 'id': 'Text4'}, {'title': '10', 'type': 'Image', 'sectionId': 'counter-bar-nav', 'id': 'Image10'}, {'title': '10098', 'type': 'Image', 'sectionId': 'counter-bar-nav', 'id': 'Image12'}, {'title': 'Since', 'type': 'Image', 'sectionId': 'counter-image-nav', 'id': 'Image13'}, {'title': 'Recent Blog Posts', 'type': 'Text', 'sectionId': 'head-text1', 'id': 'Text1'}, {'title': 'Blog Posts', 'type': 'Blog', 'sectionId': 'main', 'id': 'Blog1', 'posts': [{'id': '6561758987869087355', 'title': 'Background Remover', 'featuredImage': 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjmsS1Zv4fhK007W4GtzGkdJ8lXOIne9dmLo0HXcGzKuMRGHuzxRFmiOXuYrvxjui4k-VbQtuSpvfQKkNlUGEwdO0cPXsiNPs6KYFRKTKGsopf2LoEObqgKvoQETbJ5uv6U4kQF46QOXs6D2h6f-PpkvSM1MwlYhEFau9lGXNp_c_h51k9MVi2MpnpgKuTt/s16000/bbbb.jpg', 'showInlineAds': false}, {'id': '4242200870450100370', 'title': 'Fashion swaper', 'featuredImage': 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhNTpzdD9BQx3OVL2kTTmoXyhLZXdtilYYoiW5GwbUGMJVm1bViDjFmln4bRGJOR0LZsdnugYtojnszqljnjEhUc_UePgAA7uiLJ2KBrsHMxiK38rFzlJfMKc_yS3IIj9yx3uSaw8FgqHsb-_Ih6eVgxKoVARiVQ7IzZesD73faXUamKxgFZim0sekYSuI2/w640-h360/maxresdefault.jpg', 'showInlineAds': false}], 'headerByline': {'regionName': 'header1', 'items': [{'name': 'share', 'label': ''}, {'name': 'author', 'label': 'by'}, {'name': 'timestamp', 'label': ''}]}, 'footerBylines': [{'regionName': 'footer1', 'items': [{'name': 'comments', 'label': 'Comments'}]}, {'regionName': 'footer2', 'items': [{'name': 'labels', 'label': 'telegram'}]}], 'allBylineItems': [{'name': 'share', 'label': ''}, {'name': 'author', 'label': 'by'}, {'name': 'timestamp', 'label': ''}, {'name': 'comments', 'label': 'Comments'}, {'name': 'labels', 'label': 'telegram'}]}, {'title': 'Total Pageviews', 'type': 'Stats', 'sectionId': 'sidebar', 'id': 'Stats1'}, {'title': 'Tags', 'type': 'Label', 'sectionId': 'sidebar', 'id': 'Label2'}, {'title': '', 'type': 'HTML', 'sectionId': 'sidebar', 'id': 'HTML4'}, {'title': 'Popular Posts', 'type': 'PopularPosts', 'sectionId': 'sidebar', 'id': 'PopularPosts1', 'posts': [{'title': 'File to link telegram bot', 'id': 4442174971029999603}, {'title': 'Upload files to kpcloud using api', 'id': 5503989720716712594}, {'title': 'Upload youtube video using telegram bot ', 'id': 2325201164237818893}, {'title': 'Upload Files to Google Drive Using a Telegram Bot', 'id': 3386112632116485432}, {'title': 'Google Bard Telegram BOT', 'id': 1738809961146985972}]}, {'title': '', 'type': 'HTML', 'sectionId': 'top-bar-social', 'id': 'HTML14'}, {'title': '', 'type': 'Text', 'sectionId': 'contact-left', 'id': 'Text3'}, {'title': 'Link List', 'type': 'LinkList', 'sectionId': 'top-bar-nav', 'id': 'LinkList72'}]}]);
_WidgetManager._RegisterWidget('_LinkListView', new _WidgetInfo('LinkList71', 'sora-panel', document.getElementById('LinkList71'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HeaderView', new _WidgetInfo('Header1', 'header-logo', document.getElementById('Header1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_LinkListView', new _WidgetInfo('LinkList1', 'parallax-menu', document.getElementById('LinkList1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_LinkListView', new _WidgetInfo('LinkList74', 'main-menu', document.getElementById('LinkList74'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image1', 'main-intro', document.getElementById('Image1'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML100', 'main-intro', document.getElementById('HTML100'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image6', 'serv-tile', document.getElementById('Image6'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image7', 'serv-tile', document.getElementById('Image7'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image8', 'serv-tile', document.getElementById('Image8'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image9', 'serv-tile', document.getElementById('Image9'), {'resize': true}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image181', 'serv-tile', document.getElementById('Image181'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_TextView', new _WidgetInfo('Text4', 'head-text4', document.getElementById('Text4'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image10', 'counter-bar-nav', document.getElementById('Image10'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image12', 'counter-bar-nav', document.getElementById('Image12'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image13', 'counter-image-nav', document.getElementById('Image13'), {'resize': false}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_TextView', new _WidgetInfo('Text1', 'head-text1', document.getElementById('Text1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_BlogView', new _WidgetInfo('Blog1', 'main', document.getElementById('Blog1'), {'cmtInteractionsEnabled': false, 'lightboxEnabled': true, 'lightboxModuleUrl': 'https://www.blogger.com/static/v1/jsbin/1053750561-lbx.js', 'lightboxCssUrl': 'https://www.blogger.com/static/v1/v-css/828616780-lightbox_bundle.css'}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_StatsView', new _WidgetInfo('Stats1', 'sidebar', document.getElementById('Stats1'), {'title': 'Total Pageviews', 'showGraphicalCounter': true, 'showAnimatedCounter': true, 'showSparkline': true, 'statsUrl': '//www.cloudkp.com/b/stats?style\x3dBLACK_TRANSPARENT\x26timeRange\x3dALL_TIME\x26token\x3dAAfhxX3-O4LvzslCpJ4fAekEiODvgjTZmOPewB6d32dxitA0xC8kq1vGOL2V0jjQhQ1CnHdqAVCJYSz3iPl7TA'}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_LabelView', new _WidgetInfo('Label2', 'sidebar', document.getElementById('Label2'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML4', 'sidebar', document.getElementById('HTML4'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_PopularPostsView', new _WidgetInfo('PopularPosts1', 'sidebar', document.getElementById('PopularPosts1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML14', 'top-bar-social', document.getElementById('HTML14'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_TextView', new _WidgetInfo('Text3', 'contact-left', document.getElementById('Text3'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_LinkListView', new _WidgetInfo('LinkList72', 'top-bar-nav', document.getElementById('LinkList72'), {}, 'displayModeFull'));
</script>
</body>
</html>